import { Book, Category, AudienceGroup, LibraryUserData, ReadingHistoryItem } from '../types/library';
import { INITIAL_BOOKS, INITIAL_CATEGORIES, INITIAL_AUDIENCES } from '../data/initialData';

const STORAGE_KEYS = {
  BOOKS: 'lien_chau_library_books_v3',
  CATEGORIES: 'lien_chau_library_categories_v1',
  AUDIENCES: 'lien_chau_library_audiences_v1',
  USER_DATA: 'lien_chau_library_user_data_v1',
  SENIOR_MODE: 'lien_chau_senior_mode_v1',
};

export const getStoredBooks = (): Book[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.BOOKS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.BOOKS, JSON.stringify(INITIAL_BOOKS));
      return INITIAL_BOOKS;
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) && parsed.length > 0 ? parsed : INITIAL_BOOKS;
  } catch (e) {
    console.error('Error reading books from storage:', e);
    return INITIAL_BOOKS;
  }
};

export const saveBooks = (books: Book[]) => {
  try {
    localStorage.setItem(STORAGE_KEYS.BOOKS, JSON.stringify(books));
  } catch (e) {
    console.error('Error saving books:', e);
  }
};

export const getStoredCategories = (): Category[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.CATEGORIES);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(INITIAL_CATEGORIES));
      return INITIAL_CATEGORIES;
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) && parsed.length > 0 ? parsed : INITIAL_CATEGORIES;
  } catch (e) {
    return INITIAL_CATEGORIES;
  }
};

export const saveCategories = (categories: Category[]) => {
  try {
    localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(categories));
  } catch (e) {
    console.error('Error saving categories:', e);
  }
};

export const getStoredAudiences = (): AudienceGroup[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.AUDIENCES);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.AUDIENCES, JSON.stringify(INITIAL_AUDIENCES));
      return INITIAL_AUDIENCES;
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) && parsed.length > 0 ? parsed : INITIAL_AUDIENCES;
  } catch (e) {
    return INITIAL_AUDIENCES;
  }
};

export const getStoredUserData = (): LibraryUserData => {
  const defaultUserData: LibraryUserData = {
    favorites: ['book-001', 'book-004'],
    readingHistory: [
      {
        bookId: 'book-001',
        lastReadPage: 12,
        progressPercent: 19,
        lastReadTime: new Date().toISOString(),
        totalTimeSpentMinutes: 35,
      },
    ],
    finishedBooks: [],
    bookmarks: [
      { bookId: 'book-001', page: 12, note: 'Cách ủ men vi sinh bằng rơm rạ', createdAt: new Date().toISOString() },
    ],
    wantToRead: ['book-002', 'book-006'],
    likedBooks: ['book-001'],
  };

  try {
    const raw = localStorage.getItem(STORAGE_KEYS.USER_DATA);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.USER_DATA, JSON.stringify(defaultUserData));
      return defaultUserData;
    }
    return JSON.parse(raw);
  } catch (e) {
    return defaultUserData;
  }
};

export const saveUserData = (data: LibraryUserData) => {
  try {
    localStorage.setItem(STORAGE_KEYS.USER_DATA, JSON.stringify(data));
  } catch (e) {
    console.error('Error saving user data:', e);
  }
};

export const recordBookView = (bookId: string): number => {
  const books = getStoredBooks();
  const index = books.findIndex((b) => b.id === bookId);
  if (index !== -1) {
    books[index].views = (books[index].views || 0) + 1;
    saveBooks(books);
    return books[index].views;
  }
  return 0;
};

export const toggleFavoriteBook = (bookId: string): boolean => {
  const userData = getStoredUserData();
  const isFav = userData.favorites.includes(bookId);
  if (isFav) {
    userData.favorites = userData.favorites.filter((id) => id !== bookId);
  } else {
    userData.favorites.push(bookId);
  }
  saveUserData(userData);
  return !isFav;
};

export const toggleLikeBook = (bookId: string): { isLiked: boolean; newLikesCount: number } => {
  const userData = getStoredUserData();
  const books = getStoredBooks();
  const bookIndex = books.findIndex((b) => b.id === bookId);

  const isLiked = userData.likedBooks.includes(bookId);
  if (isLiked) {
    userData.likedBooks = userData.likedBooks.filter((id) => id !== bookId);
    if (bookIndex !== -1 && books[bookIndex].likes > 0) {
      books[bookIndex].likes -= 1;
    }
  } else {
    userData.likedBooks.push(bookId);
    if (bookIndex !== -1) {
      books[bookIndex].likes = (books[bookIndex].likes || 0) + 1;
    }
  }

  saveUserData(userData);
  if (bookIndex !== -1) saveBooks(books);

  return {
    isLiked: !isLiked,
    newLikesCount: bookIndex !== -1 ? books[bookIndex].likes : 0,
  };
};

export const updateReadingProgress = (
  bookId: string,
  pageNumber: number,
  totalPages: number,
  minutesSpent = 2
) => {
  const userData = getStoredUserData();
  const progressPercent = Math.min(100, Math.round((pageNumber / Math.max(1, totalPages)) * 100));

  const existingIndex = userData.readingHistory.findIndex((h) => h.bookId === bookId);
  if (existingIndex !== -1) {
    userData.readingHistory[existingIndex].lastReadPage = pageNumber;
    userData.readingHistory[existingIndex].progressPercent = progressPercent;
    userData.readingHistory[existingIndex].lastReadTime = new Date().toISOString();
    userData.readingHistory[existingIndex].totalTimeSpentMinutes += minutesSpent;
  } else {
    userData.readingHistory.unshift({
      bookId,
      lastReadPage: pageNumber,
      progressPercent,
      lastReadTime: new Date().toISOString(),
      totalTimeSpentMinutes: minutesSpent,
    });
  }

  if (progressPercent >= 95 && !userData.finishedBooks.includes(bookId)) {
    userData.finishedBooks.push(bookId);
  }

  saveUserData(userData);
};

export const getSeniorMode = (): boolean => {
  return localStorage.getItem(STORAGE_KEYS.SENIOR_MODE) === 'true';
};

export const setSeniorMode = (enabled: boolean) => {
  localStorage.setItem(STORAGE_KEYS.SENIOR_MODE, enabled ? 'true' : 'false');
};

// Export entire library data to JSON (Section 29 & 30)
export const exportLibraryToJson = () => {
  const data = {
    library: {
      name: 'Thư viện cộng đồng số xã Liên Châu',
      slogan: 'Kết nối tri thức - Lan tỏa văn hóa đọc',
      unit: 'Trung tâm học tập cộng đồng xã Liên Châu',
      exportedAt: new Date().toISOString(),
      version: '1.0',
    },
    categories: getStoredCategories(),
    audiences: getStoredAudiences(),
    books: getStoredBooks(),
  };

  const jsonStr = JSON.stringify(data, null, 2);
  const blob = new Blob([jsonStr], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `thu_vien_so_lien_chau_backup_${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  URL.revokeObjectURL(url);
};

// Import library data from JSON
export const importLibraryFromJson = (jsonString: string): boolean => {
  try {
    const data = JSON.parse(jsonString);
    if (data.books && Array.isArray(data.books)) {
      saveBooks(data.books);
    }
    if (data.categories && Array.isArray(data.categories)) {
      saveCategories(data.categories);
    }
    return true;
  } catch (err) {
    console.error('Import JSON error:', err);
    return false;
  }
};
