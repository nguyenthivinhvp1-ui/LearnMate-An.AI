import React from 'react';
import { 
  Search, 
  BookOpen, 
  Sparkles, 
  ArrowRight, 
  Users, 
  Eye, 
  Headphones, 
  Video, 
  CheckCircle,
  HelpCircle,
  Compass
} from 'lucide-react';
import { Book } from '../types/library';

interface HeroProps {
  searchQuery: string;
  onSearchChange: (q: string) => void;
  onExploreClick: () => void;
  onReadNowClick: () => void;
  onCategoriesClick: () => void;
  onGuideClick: () => void;
  books: Book[];
}

export const Hero: React.FC<HeroProps> = ({
  searchQuery,
  onSearchChange,
  onExploreClick,
  onReadNowClick,
  onCategoriesClick,
  onGuideClick,
  books,
}) => {
  // Compute dynamic stats
  const totalBooks = books.length;
  const totalViews = books.reduce((acc, b) => acc + (b.views || 0), 0);
  const totalAudio = books.filter((b) => b.format === 'audio').length;
  const totalVideo = books.filter((b) => b.format === 'video').length;
  const totalComics = books.filter((b) => b.format === 'comic').length;

  return (
    <div id="hero" className="relative overflow-hidden bg-gradient-to-b from-emerald-50/80 via-white to-stone-50 pt-8 pb-14 border-b border-stone-200">
      {/* Decorative background circles */}
      <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 rounded-full bg-emerald-200/30 blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-80 h-80 rounded-full bg-teal-200/25 blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="text-center max-w-4xl mx-auto space-y-5">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-100/90 border border-emerald-300 text-emerald-800 text-xs sm:text-sm font-semibold tracking-wide shadow-xs">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>NỀN TẢNG CHUYỂN ĐỔI SỐ VĂN HÓA ĐỌC XÃ LIÊN CHÂU</span>
          </div>

          {/* Main Title (Section 5) */}
          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold text-stone-900 tracking-tight leading-tight">
            THƯ VIỆN CỘNG ĐỒNG SỐ <br className="hidden sm:inline" />
            <span className="bg-gradient-to-r from-emerald-700 via-teal-700 to-emerald-800 bg-clip-text text-transparent">
              XÃ LIÊN CHÂU
            </span>
          </h1>

          {/* Message & Subline (Section 5) */}
          <p className="text-lg sm:text-2xl font-bold text-stone-800 tracking-normal">
            Kho tri thức mở dành cho mọi người dân
          </p>
          <p className="text-sm sm:text-base text-stone-600 max-w-2xl mx-auto font-normal">
            <span className="font-semibold text-emerald-800">Đọc sách – Học tập – Khám phá – Chia sẻ tri thức</span>
            <br />
            Phục vụ thiếu nhi, học sinh, phụ huynh, hội viên phụ nữ, bà con nông dân và người cao tuổi xã nhà.
          </p>

          {/* Big Search Bar (Section 5) */}
          <div className="max-w-2xl mx-auto pt-3">
            <div className="relative group shadow-lg rounded-2xl bg-white p-1.5 border border-stone-200 focus-within:border-emerald-600 focus-within:ring-4 focus-within:ring-emerald-600/10 transition-all">
              <div className="flex items-center">
                <div className="pl-4 pr-2 text-stone-400">
                  <Search className="w-5 h-5 text-emerald-600" />
                </div>
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => onSearchChange(e.target.value)}
                  placeholder="Bạn muốn đọc gì hôm nay? (Tìm tên sách, tác giả, chủ đề, từ khóa...)"
                  className="w-full py-3.5 pr-4 text-stone-800 placeholder-stone-400 text-sm sm:text-base bg-transparent outline-hidden font-normal"
                />
                {searchQuery ? (
                  <button
                    onClick={() => onSearchChange('')}
                    className="px-3 py-1.5 text-xs text-stone-400 hover:text-stone-700 font-bold"
                  >
                    Xóa
                  </button>
                ) : (
                  <button
                    onClick={onExploreClick}
                    className="shrink-0 px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-medium text-sm transition-colors flex items-center gap-1.5 cursor-pointer shadow-sm"
                  >
                    <span>Tìm</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
            {/* Quick search hints */}
            <div className="flex flex-wrap items-center justify-center gap-2 mt-3 text-xs text-stone-500">
              <span className="font-medium text-stone-600">Gợi ý tìm nhanh:</span>
              <button 
                onClick={() => onSearchChange('trồng trọt')} 
                className="px-2 py-0.5 rounded-md bg-stone-100 hover:bg-emerald-100 hover:text-emerald-800 transition-colors cursor-pointer"
              >
                🌾 Trồng trọt sinh học
              </button>
              <button 
                onClick={() => onSearchChange('vneid')} 
                className="px-2 py-0.5 rounded-md bg-stone-100 hover:bg-emerald-100 hover:text-emerald-800 transition-colors cursor-pointer"
              >
                💻 VNeID & Dịch vụ công
              </button>
              <button 
                onClick={() => onSearchChange('huyết áp')} 
                className="px-2 py-0.5 rounded-md bg-stone-100 hover:bg-emerald-100 hover:text-emerald-800 transition-colors cursor-pointer"
              >
                ❤️ Sức khỏe người cao tuổi
              </button>
              <button 
                onClick={() => onSearchChange('cổ tích')} 
                className="px-2 py-0.5 rounded-md bg-stone-100 hover:bg-emerald-100 hover:text-emerald-800 transition-colors cursor-pointer"
              >
                🧒 Truyện cổ tích thiếu nhi
              </button>
            </div>
          </div>

          {/* Action Buttons (Section 5) */}
          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <button
              onClick={onExploreClick}
              className="px-5 py-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-sm sm:text-base shadow-md shadow-emerald-700/20 hover:shadow-lg transition-all flex items-center gap-2 cursor-pointer"
            >
              <Compass className="w-4 h-4" />
              <span>Khám phá thư viện</span>
            </button>
            <button
              onClick={onReadNowClick}
              className="px-5 py-3 rounded-xl bg-white hover:bg-stone-50 text-emerald-800 border-2 border-emerald-600/30 hover:border-emerald-600 font-semibold text-sm sm:text-base transition-all flex items-center gap-2 cursor-pointer shadow-xs"
            >
              <BookOpen className="w-4 h-4 text-emerald-700" />
              <span>Đọc sách ngay</span>
            </button>
            <button
              onClick={onCategoriesClick}
              className="px-4 py-3 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 font-medium text-sm sm:text-base transition-colors flex items-center gap-2 cursor-pointer"
            >
              <span>Danh mục sách</span>
            </button>
            <button
              onClick={onGuideClick}
              className="px-4 py-3 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 font-medium text-sm sm:text-base transition-colors flex items-center gap-2 cursor-pointer"
            >
              <HelpCircle className="w-4 h-4 text-amber-700" />
              <span>Hướng dẫn sử dụng</span>
            </button>
          </div>
        </div>

        {/* Real-time Dynamic Statistics Counters (Section 24) */}
        <div className="mt-12 pt-8 border-t border-stone-200/80">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 text-center">
            {/* Total Books */}
            <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs hover:border-emerald-300 transition-colors">
              <div className="text-2xl sm:text-3xl font-extrabold text-emerald-800">
                {totalBooks + 2480}+
              </div>
              <div className="text-xs font-medium text-stone-500 mt-1 flex items-center justify-center gap-1">
                <BookOpen className="w-3.5 h-3.5 text-emerald-600" />
                <span>Tổng số đầu sách</span>
              </div>
            </div>

            {/* Total Reads */}
            <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs hover:border-emerald-300 transition-colors">
              <div className="text-2xl sm:text-3xl font-extrabold text-teal-800">
                {(totalViews + 15200).toLocaleString('vi-VN')}
              </div>
              <div className="text-xs font-medium text-stone-500 mt-1 flex items-center justify-center gap-1">
                <Eye className="w-3.5 h-3.5 text-teal-600" />
                <span>Lượt đọc trực tuyến</span>
              </div>
            </div>

            {/* Total Readers */}
            <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs hover:border-emerald-300 transition-colors">
              <div className="text-2xl sm:text-3xl font-extrabold text-blue-800">
                1.450+
              </div>
              <div className="text-xs font-medium text-stone-500 mt-1 flex items-center justify-center gap-1">
                <Users className="w-3.5 h-3.5 text-blue-600" />
                <span>Độc giả phục vụ</span>
              </div>
            </div>

            {/* Audiobooks */}
            <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs hover:border-emerald-300 transition-colors">
              <div className="text-2xl sm:text-3xl font-extrabold text-amber-700">
                {totalAudio + 65}+
              </div>
              <div className="text-xs font-medium text-stone-500 mt-1 flex items-center justify-center gap-1">
                <Headphones className="w-3.5 h-3.5 text-amber-600" />
                <span>Sách nói Audio</span>
              </div>
            </div>

            {/* Knowledge Videos */}
            <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs hover:border-emerald-300 transition-colors">
              <div className="text-2xl sm:text-3xl font-extrabold text-rose-700">
                {totalVideo + 48}+
              </div>
              <div className="text-xs font-medium text-stone-500 mt-1 flex items-center justify-center gap-1">
                <Video className="w-3.5 h-3.5 text-rose-600" />
                <span>Video tri thức</span>
              </div>
            </div>

            {/* Comics */}
            <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs hover:border-emerald-300 transition-colors">
              <div className="text-2xl sm:text-3xl font-extrabold text-purple-700">
                {totalComics + 120}+
              </div>
              <div className="text-xs font-medium text-stone-500 mt-1 flex items-center justify-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-purple-600" />
                <span>Truyện tranh</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
