import React, { useState } from 'react';
import { 
  X, 
  Bookmark, 
  Heart, 
  Clock, 
  CheckCircle, 
  BookOpen, 
  Trash2, 
  ListPlus,
  ArrowRight,
  Sparkles
} from 'lucide-react';
import { Book, LibraryUserData } from '../types/library';

interface MyLibraryModalProps {
  isOpen: boolean;
  onClose: () => void;
  userData: LibraryUserData;
  allBooks: Book[];
  onReadBook: (book: Book, startPage?: number) => void;
  onRemoveFavorite: (bookId: string) => void;
  onClearHistory: () => void;
}

export const MyLibraryModal: React.FC<MyLibraryModalProps> = ({
  isOpen,
  onClose,
  userData,
  allBooks,
  onReadBook,
  onRemoveFavorite,
  onClearHistory,
}) => {
  const [activeTab, setActiveTab] = useState<'favorites' | 'reading' | 'history' | 'finished' | 'bookmarks'>('reading');

  if (!isOpen) return null;

  const favoriteBooks = allBooks.filter((b) => userData.favorites.includes(b.id));
  const readingBooks = userData.readingHistory
    .map((item) => {
      const book = allBooks.find((b) => b.id === item.bookId);
      return book ? { ...book, readingMeta: item } : null;
    })
    .filter(Boolean);

  const finishedBooks = allBooks.filter((b) => userData.finishedBooks?.includes(b.id));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-stone-950/70 backdrop-blur-xs overflow-y-auto animate-fade-in">
      <div 
        className="relative w-full max-w-4xl bg-white rounded-3xl shadow-2xl border border-stone-200 overflow-hidden flex flex-col my-auto max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-stone-100 bg-stone-50">
          <div className="flex items-center gap-2">
            <Bookmark className="w-5 h-5 text-emerald-600" />
            <h2 className="text-base sm:text-lg font-bold text-stone-900">
              TỦ SÁCH CỦA TÔI (THƯ VIỆN CÁ NHÂN)
            </h2>
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-stone-200/80 hover:bg-stone-300 text-stone-700 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab selection bar (Section 20) */}
        <div className="px-6 pt-4 border-b border-stone-100 flex items-center gap-2 overflow-x-auto no-scrollbar">
          <button
            onClick={() => setActiveTab('reading')}
            className={`pb-3 px-3 text-xs sm:text-sm font-bold border-b-2 flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'reading'
                ? 'border-emerald-600 text-emerald-800'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>Đang đọc ({readingBooks.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('favorites')}
            className={`pb-3 px-3 text-xs sm:text-sm font-bold border-b-2 flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'favorites'
                ? 'border-emerald-600 text-emerald-800'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            <Heart className="w-4 h-4 text-rose-500" />
            <span>Yêu thích ({favoriteBooks.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('finished')}
            className={`pb-3 px-3 text-xs sm:text-sm font-bold border-b-2 flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'finished'
                ? 'border-emerald-600 text-emerald-800'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            <CheckCircle className="w-4 h-4 text-teal-600" />
            <span>Đã đọc xong ({finishedBooks.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('history')}
            className={`pb-3 px-3 text-xs sm:text-sm font-bold border-b-2 flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'history'
                ? 'border-emerald-600 text-emerald-800'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            <Clock className="w-4 h-4 text-blue-500" />
            <span>Lịch sử đọc</span>
          </button>
        </div>

        {/* Tab content area */}
        <div className="p-6 overflow-y-auto flex-1">
          {/* Tab 1: Đang đọc */}
          {activeTab === 'reading' && (
            <div className="space-y-4">
              {readingBooks.length > 0 ? (
                readingBooks.map((item: any) => (
                  <div
                    key={item.id}
                    className="p-4 rounded-2xl bg-stone-50 border border-stone-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:border-emerald-300 transition-colors"
                  >
                    <div className="flex items-center gap-3.5">
                      <img
                        src={item.cover}
                        alt={item.title}
                        className="w-14 h-18 object-cover rounded-xl shrink-0 shadow-xs"
                      />
                      <div>
                        <h4 className="font-bold text-sm sm:text-base text-stone-900 line-clamp-1">
                          {item.title}
                        </h4>
                        <p className="text-xs text-stone-500">{item.author}</p>
                        
                        {/* Progress */}
                        <div className="mt-2 flex items-center gap-2">
                          <div className="w-32 bg-stone-200 rounded-full h-2 overflow-hidden">
                            <div 
                              className="bg-emerald-600 h-full rounded-full"
                              style={{ width: `${item.readingMeta?.progressPercent || 10}%` }}
                            />
                          </div>
                          <span className="text-xs font-semibold text-emerald-800">
                            {item.readingMeta?.progressPercent || 10}% (Trang {item.readingMeta?.lastReadPage || 1}/{item.pages})
                          </span>
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={() => onReadBook(item, item.readingMeta?.lastReadPage || 1)}
                      className="px-4 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-xs sm:text-sm flex items-center justify-center gap-1.5 cursor-pointer shadow-xs self-end sm:self-auto shrink-0"
                    >
                      <span>Tiếp tục đọc</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                ))
              ) : (
                <div className="text-center py-12 text-stone-500">
                  <BookOpen className="w-12 h-12 text-stone-300 mx-auto mb-2" />
                  <p className="text-sm">Bạn chưa có cuốn sách nào đang đọc dở.</p>
                  <p className="text-xs text-stone-400 mt-1">Hãy mở một cuốn sách bất kỳ để bắt đầu hành trình tri thức!</p>
                </div>
              )}
            </div>
          )}

          {/* Tab 2: Sách Yêu thích */}
          {activeTab === 'favorites' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {favoriteBooks.length > 0 ? (
                favoriteBooks.map((b) => (
                  <div
                    key={b.id}
                    className="p-3.5 rounded-2xl bg-stone-50 border border-stone-200 flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <img src={b.cover} alt={b.title} className="w-12 h-16 object-cover rounded-lg shrink-0" />
                      <div className="min-w-0">
                        <h4 className="font-bold text-xs sm:text-sm text-stone-900 truncate">{b.title}</h4>
                        <p className="text-[11px] text-stone-500 truncate">{b.author}</p>
                        <span className="inline-block mt-1 text-[10px] font-bold text-emerald-700 uppercase">
                          {b.format}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        onClick={() => onReadBook(b)}
                        className="p-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold cursor-pointer"
                        title="Đọc ngay"
                      >
                        <BookOpen className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => onRemoveFavorite(b.id)}
                        className="p-2 rounded-lg bg-stone-200 hover:bg-rose-100 text-stone-600 hover:text-rose-600 text-xs cursor-pointer"
                        title="Bỏ yêu thích"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))
              ) : (
                <div className="col-span-2 text-center py-12 text-stone-500">
                  <Heart className="w-12 h-12 text-stone-300 mx-auto mb-2" />
                  <p className="text-sm">Chưa có cuốn sách nào trong danh sách yêu thích.</p>
                </div>
              )}
            </div>
          )}

          {/* Tab 3: Đã đọc xong */}
          {activeTab === 'finished' && (
            <div className="space-y-3">
              {finishedBooks.length > 0 ? (
                finishedBooks.map((b) => (
                  <div key={b.id} className="p-3 rounded-2xl bg-emerald-50/50 border border-emerald-200 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0" />
                      <div>
                        <h4 className="font-bold text-sm text-stone-900">{b.title}</h4>
                        <p className="text-xs text-stone-500">{b.author}</p>
                      </div>
                    </div>
                    <button
                      onClick={() => onReadBook(b, 1)}
                      className="px-3 py-1.5 rounded-lg bg-emerald-700 text-white text-xs font-semibold cursor-pointer"
                    >
                      Đọc lại
                    </button>
                  </div>
                ))
              ) : (
                <div className="text-center py-12 text-stone-500">
                  <CheckCircle className="w-12 h-12 text-stone-300 mx-auto mb-2" />
                  <p className="text-sm">Bạn chưa hoàn thành cuốn sách nào 100%.</p>
                </div>
              )}
            </div>
          )}

          {/* Tab 4: Lịch sử đọc */}
          {activeTab === 'history' && (
            <div className="space-y-3">
              <div className="flex justify-between items-center pb-2">
                <span className="text-xs text-stone-500">Nhật ký truy cập và đọc tài liệu:</span>
                {userData.readingHistory.length > 0 && (
                  <button
                    onClick={onClearHistory}
                    className="text-xs text-rose-600 hover:underline cursor-pointer"
                  >
                    Xóa lịch sử
                  </button>
                )}
              </div>
              {userData.readingHistory.map((h, idx) => {
                const book = allBooks.find((b) => b.id === h.bookId);
                if (!book) return null;
                return (
                  <div key={idx} className="p-3 bg-stone-50 rounded-xl border border-stone-200 flex items-center justify-between text-xs">
                    <div>
                      <span className="font-bold text-stone-900 block">{book.title}</span>
                      <span className="text-stone-400">
                        Đọc đến trang {h.lastReadPage} • {new Date(h.lastReadTime).toLocaleDateString('vi-VN')}
                      </span>
                    </div>
                    <button
                      onClick={() => onReadBook(book, h.lastReadPage)}
                      className="text-emerald-700 font-bold hover:underline cursor-pointer"
                    >
                      Mở lại →
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
