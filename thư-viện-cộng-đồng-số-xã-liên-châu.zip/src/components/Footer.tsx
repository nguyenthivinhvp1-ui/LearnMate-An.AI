import React from 'react';
import { BookOpen, MapPin, Phone, Mail, Globe, Heart, ShieldCheck } from 'lucide-react';

interface FooterProps {
  onScrollToSection: (id: string) => void;
  onOpenAdmin: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onScrollToSection, onOpenAdmin }) => {
  return (
    <footer className="bg-stone-900 text-stone-300 pt-12 pb-8 border-t-4 border-emerald-700">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 pb-10 border-b border-stone-800 text-xs sm:text-sm">
          {/* Col 1: System info & logo (Section 40) */}
          <div className="lg:col-span-2 space-y-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold">
                <BookOpen className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-extrabold text-white uppercase tracking-tight">
                  THƯ VIỆN CỘNG ĐỒNG SỐ XÃ LIÊN CHÂU
                </h3>
                <p className="text-xs text-emerald-400 font-medium">
                  Trung tâm học tập cộng đồng xã Liên Châu
                </p>
              </div>
            </div>

            <p className="text-stone-400 text-xs leading-relaxed max-w-sm pt-2">
              Không gian số đọc sách, học tập, tra cứu và chia sẻ tri thức mở dành cho toàn thể nhân dân xã nhà. Phục vụ học tập suốt đời và chuyển đổi số nông thôn mới.
            </p>

            <div className="pt-2 text-stone-400 text-xs space-y-1.5">
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-emerald-500 shrink-0" />
                <span>Trụ sở: Nhà Văn hóa Trung tâm Xã Liên Châu</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-emerald-500 shrink-0" />
                <span>Đường dây nóng hỗ trợ đọc sách: 0243.886.xxxx</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-emerald-500 shrink-0" />
                <span>Email: tt_htcd_lienchau@hanoi.gov.vn</span>
              </div>
            </div>
          </div>

          {/* Col 2: Menu Giới thiệu & Danh mục (Section 40) */}
          <div>
            <h4 className="font-bold text-white uppercase tracking-wider text-xs mb-3">
              Khám phá thư viện
            </h4>
            <ul className="space-y-2 text-stone-400 text-xs">
              <li>
                <button 
                  onClick={() => onScrollToSection('hero')} 
                  className="hover:text-emerald-400 cursor-pointer"
                >
                  Giới thiệu thư viện số
                </button>
              </li>
              <li>
                <button 
                  onClick={() => onScrollToSection('kho-sach')} 
                  className="hover:text-emerald-400 cursor-pointer"
                >
                  Danh mục sách điện tử
                </button>
              </li>
              <li>
                <button 
                  onClick={() => onScrollToSection('goc-tre-em')} 
                  className="hover:text-emerald-400 cursor-pointer"
                >
                  Góc truyện tranh thiếu nhi
                </button>
              </li>
              <li>
                <button 
                  onClick={() => onScrollToSection('hoc-tap-suot-doi')} 
                  className="hover:text-emerald-400 cursor-pointer"
                >
                  Góc học tập suốt đời
                </button>
              </li>
              <li>
                <button 
                  onClick={() => onScrollToSection('hoat-dong')} 
                  className="hover:text-emerald-400 cursor-pointer"
                >
                  Hoạt động & Sự kiện văn hóa
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Hướng dẫn & Dịch vụ */}
          <div>
            <h4 className="font-bold text-white uppercase tracking-wider text-xs mb-3">
              Hướng dẫn & Tiện ích
            </h4>
            <ul className="space-y-2 text-stone-400 text-xs">
              <li>
                <button 
                  onClick={() => onScrollToSection('huong-dan')} 
                  className="hover:text-emerald-400 cursor-pointer"
                >
                  Hướng dẫn đọc sách lật 3D
                </button>
              </li>
              <li>
                <button 
                  onClick={() => onScrollToSection('huong-dan')} 
                  className="hover:text-emerald-400 cursor-pointer"
                >
                  Cách nghe sách nói Audio
                </button>
              </li>
              <li>
                <button 
                  onClick={() => onScrollToSection('huong-dan')} 
                  className="hover:text-emerald-400 cursor-pointer"
                >
                  Chế độ Dễ đọc cho Người cao tuổi
                </button>
              </li>
              <li>
                <button 
                  onClick={() => onScrollToSection('huong-dan')} 
                  className="hover:text-emerald-400 cursor-pointer"
                >
                  Tạo và in mã QR sách
                </button>
              </li>
              <li>
                <button 
                  onClick={onOpenAdmin} 
                  className="hover:text-emerald-400 flex items-center gap-1 cursor-pointer"
                >
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Cán bộ quản trị thư viện</span>
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Điều khoản & Chính sách (Section 40) */}
          <div>
            <h4 className="font-bold text-white uppercase tracking-wider text-xs mb-3">
              Chính sách & Pháp lý
            </h4>
            <ul className="space-y-2 text-stone-400 text-xs">
              <li>
                <span className="hover:text-white cursor-pointer">Điều khoản dịch vụ số</span>
              </li>
              <li>
                <span className="hover:text-white cursor-pointer">Chính sách bảo mật thông tin</span>
              </li>
              <li>
                <span className="hover:text-white cursor-pointer">Bản quyền & Giấy phép tài liệu</span>
              </li>
              <li>
                <span className="hover:text-white cursor-pointer">Quy chế hoạt động thư viện</span>
              </li>
              <li>
                <span className="hover:text-white cursor-pointer">Liên hệ đóng góp sách</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar with Mandatory Slogan (Section 40) */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-stone-500">
          <div className="text-center sm:text-left">
            © 2026 Trung tâm Học tập Cộng đồng Xã Liên Châu. Bảo lưu mọi quyền.
          </div>

          {/* Section 40 ending message */}
          <div className="text-emerald-400 font-bold text-sm tracking-wide text-center">
            "Mỗi ngày một trang sách – Mỗi ngày thêm một điều hay."
          </div>
        </div>
      </div>
    </footer>
  );
};
