import React, { useState, useRef, useEffect } from 'react';
import { 
  X, 
  Send, 
  Sparkles, 
  BookOpen, 
  Bot, 
  User, 
  ExternalLink, 
  Volume2, 
  VolumeX, 
  RotateCcw,
  Loader2,
  Compass
} from 'lucide-react';
import { Book } from '../types/library';

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  sources?: Array<{ title: string; uri: string }>;
  suggestedBookId?: string;
  timestamp: string;
}

interface LibrarianChatbotProps {
  isOpen: boolean;
  onClose: () => void;
  books: Book[];
  onOpenBook: (book: Book) => void;
}

export const LibrarianChatbot: React.FC<LibrarianChatbotProps> = ({
  isOpen,
  onClose,
  books,
  onOpenBook,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'init-1',
      role: 'assistant',
      content: 'Kính chào bà con và các bạn độc giả! Tôi là Trợ lý Thủ thư số của Thư viện Cộng đồng số Xã Liên Châu. Tôi có thể tư vấn chọn sách theo lứa tuổi, giải đáp thắc mắc về kỹ thuật nông nghiệp, kỹ năng số (VNeID), sức khỏe người cao tuổi hoặc hướng dẫn tra cứu học liệu. Bạn cần tìm hiểu nội dung gì hôm nay?',
      timestamp: new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [inputPrompt, setInputPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [speakingMsgId, setSpeakingMsgId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [messages, isOpen]);

  if (!isOpen) return null;

  const quickPrompts = [
    '🌾 Gợi ý tài liệu trồng trọt, phân bón sinh học',
    '💻 Chỉ tôi cách đăng ký VNeID và dịch vụ công',
    '❤️ Cách ổn định huyết áp cho người cao tuổi',
    '🧒 Tìm truyện tranh an toàn giao thông cho bé',
    '📖 Hướng dẫn đọc sách lật Flipbook 3D',
  ];

  const handleSendMessage = async (textToSend?: string) => {
    const query = textToSend || inputPrompt.trim();
    if (!query || isLoading) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: query,
      timestamp: new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }),
    };

    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    setInputPrompt('');
    setIsLoading(true);

    try {
      // Find matching books in local catalog to inject as context
      const matchedBooks = books.filter((b) =>
        b.keywords.some((kw) => query.toLowerCase().includes(kw.toLowerCase())) ||
        b.title.toLowerCase().includes(query.toLowerCase())
      ).slice(0, 3);

      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: newMessages.map((m) => ({
            role: m.role === 'assistant' ? 'model' : 'user',
            content: m.content,
          })),
          contextInfo: {
            libraryName: 'Thư viện cộng đồng số xã Liên Châu',
            totalCatalogCount: books.length,
            matchingBooks: matchedBooks.map((b) => ({
              id: b.id,
              title: b.title,
              author: b.author,
              format: b.format,
            })),
          },
        }),
      });

      const data = await response.json();
      
      const assistantMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: data.reply || 'Cảm ơn bạn đã hỏi. Tôi sẵn sàng hỗ trợ tìm sách và thông tin!',
        sources: data.sources || [],
        suggestedBookId: matchedBooks[0]?.id,
        timestamp: new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, assistantMsg]);
    } catch (err) {
      console.error('Chat error:', err);
      setMessages((prev) => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          role: 'assistant',
          content: 'Xin lỗi, kết nối tới máy chủ AI gặp chút trục trặc. Bạn vẫn có thể dùng thanh tìm kiếm trực tiếp trên trang chủ để tra cứu sách bất kỳ nhé!',
          timestamp: new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSpeakMessage = (msg: ChatMessage) => {
    if (!('speechSynthesis' in window)) return;

    if (speakingMsgId === msg.id) {
      window.speechSynthesis.cancel();
      setSpeakingMsgId(null);
      return;
    }

    window.speechSynthesis.cancel();
    const utter = new SpeechSynthesisUtterance(msg.content);
    utter.lang = 'vi-VN';
    utter.rate = 0.95;
    utter.onend = () => setSpeakingMsgId(null);
    utter.onerror = () => setSpeakingMsgId(null);
    window.speechSynthesis.speak(utter);
    setSpeakingMsgId(msg.id);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-end sm:justify-center p-0 sm:p-4 bg-stone-950/60 backdrop-blur-xs animate-fade-in">
      <div 
        className="relative w-full sm:max-w-xl h-[88vh] sm:h-[650px] bg-white rounded-t-3xl sm:rounded-3xl shadow-2xl border border-stone-200 overflow-hidden flex flex-col my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-800 via-teal-800 to-emerald-900 text-white p-4 flex items-center justify-between shrink-0 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/10 backdrop-blur-xs flex items-center justify-center border border-white/20">
              <Bot className="w-6 h-6 text-yellow-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-sm sm:text-base leading-tight">
                  Thủ Thư Số Thông Minh
                </h3>
                <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-yellow-400 text-stone-950">
                  Search Grounded AI
                </span>
              </div>
              <p className="text-[11px] text-emerald-200">
                Thư viện Cộng đồng số Xã Liên Châu
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              if (speakingMsgId) window.speechSynthesis.cancel();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Messages Thread */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-stone-50/70">
          {messages.map((m) => {
            const isUser = m.role === 'user';
            const suggestedBook = m.suggestedBookId ? books.find((b) => b.id === m.suggestedBookId) : null;

            return (
              <div
                key={m.id}
                className={`flex gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}
              >
                {!isUser && (
                  <div className="w-8 h-8 rounded-full bg-emerald-700 text-white flex items-center justify-center shrink-0 shadow-xs mt-1">
                    <Bot className="w-4 h-4" />
                  </div>
                )}

                <div className={`max-w-[85%] space-y-2 ${isUser ? 'items-end' : 'items-start'}`}>
                  <div
                    className={`p-3.5 rounded-2xl text-xs sm:text-sm leading-relaxed shadow-xs ${
                      isUser
                        ? 'bg-emerald-700 text-white rounded-tr-xs'
                        : 'bg-white text-stone-800 border border-stone-200/90 rounded-tl-xs'
                    }`}
                  >
                    <div className="whitespace-pre-line">{m.content}</div>

                    {/* Google Search Grounding Sources */}
                    {m.sources && m.sources.length > 0 && (
                      <div className="mt-2.5 pt-2.5 border-t border-stone-200/60 text-[11px] space-y-1">
                        <span className="font-semibold text-stone-500 block">Nguồn tham khảo Google:</span>
                        <div className="flex flex-wrap gap-1">
                          {m.sources.slice(0, 3).map((src, i) => (
                            <a
                              key={i}
                              href={src.uri}
                              target="_blank"
                              rel="noreferrer"
                              className="px-2 py-0.5 rounded-md bg-stone-100 hover:bg-emerald-50 text-emerald-800 hover:underline inline-flex items-center gap-1 truncate max-w-[200px]"
                            >
                              <span>{src.title}</span>
                              <ExternalLink className="w-3 h-3 shrink-0" />
                            </a>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Book recommendation card if mentioned */}
                  {suggestedBook && (
                    <div 
                      onClick={() => onOpenBook(suggestedBook)}
                      className="p-2.5 bg-emerald-50/80 hover:bg-emerald-100 rounded-xl border border-emerald-200 flex items-center justify-between gap-2 cursor-pointer transition-colors"
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        <img src={suggestedBook.cover} alt={suggestedBook.title} className="w-9 h-12 object-cover rounded-md shrink-0" />
                        <div className="min-w-0">
                          <span className="text-[10px] font-bold text-emerald-800 uppercase block">Gợi ý đọc trong thư viện:</span>
                          <h5 className="text-xs font-bold text-stone-900 truncate">{suggestedBook.title}</h5>
                          <span className="text-[10px] text-stone-500">{suggestedBook.author}</span>
                        </div>
                      </div>
                      <span className="text-xs font-bold text-emerald-700 shrink-0">Mở đọc →</span>
                    </div>
                  )}

                  {/* Footer of message */}
                  <div className="flex items-center gap-2 text-[10px] text-stone-400 px-1">
                    <span>{m.timestamp}</span>
                    {!isUser && (
                      <button
                        onClick={() => handleSpeakMessage(m)}
                        className="hover:text-emerald-700 cursor-pointer flex items-center gap-1"
                        title="Đọc to câu trả lời"
                      >
                        {speakingMsgId === m.id ? (
                          <VolumeX className="w-3 h-3 text-rose-600" />
                        ) : (
                          <Volume2 className="w-3 h-3" />
                        )}
                        <span>{speakingMsgId === m.id ? 'Dừng đọc' : 'Nghe đọc'}</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}

          {isLoading && (
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-emerald-700 text-white flex items-center justify-center shrink-0">
                <Bot className="w-4 h-4" />
              </div>
              <div className="bg-white p-3 rounded-2xl border border-stone-200 flex items-center gap-2 text-xs text-stone-500 shadow-xs">
                <Loader2 className="w-4 h-4 animate-spin text-emerald-600" />
                <span>Thủ thư số đang tra cứu và tìm kiếm thông tin...</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick prompt suggestions */}
        <div className="p-2 border-t border-stone-200 bg-stone-100 overflow-x-auto no-scrollbar flex gap-1.5 shrink-0 text-xs">
          {quickPrompts.map((p, idx) => (
            <button
              key={idx}
              onClick={() => handleSendMessage(p)}
              disabled={isLoading}
              className="px-2.5 py-1 rounded-full bg-white hover:bg-emerald-50 text-stone-700 hover:text-emerald-800 border border-stone-200 hover:border-emerald-300 font-medium whitespace-nowrap cursor-pointer transition-colors shadow-2xs"
            >
              {p}
            </button>
          ))}
        </div>

        {/* Input box */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="p-3 bg-white border-t border-stone-200 flex items-center gap-2 shrink-0"
        >
          <input
            type="text"
            value={inputPrompt}
            onChange={(e) => setInputPrompt(e.target.value)}
            placeholder="Hỏi về sách, nông nghiệp, kỹ năng số, sức khỏe..."
            className="flex-1 py-2.5 px-4 bg-stone-100 rounded-full border border-stone-200 text-xs sm:text-sm text-stone-800 placeholder-stone-400 outline-hidden focus:border-emerald-600 focus:bg-white transition-all"
          />
          <button
            type="submit"
            disabled={!inputPrompt.trim() || isLoading}
            className="w-10 h-10 rounded-full bg-emerald-700 hover:bg-emerald-800 disabled:opacity-40 text-white flex items-center justify-center transition-colors cursor-pointer shadow-sm shrink-0"
          >
            <Send className="w-4 h-4 ml-0.5" />
          </button>
        </form>
      </div>
    </div>
  );
};
