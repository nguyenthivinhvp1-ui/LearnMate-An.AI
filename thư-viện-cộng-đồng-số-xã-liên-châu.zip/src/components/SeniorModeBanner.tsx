import React, { useState } from 'react';
import { Eye, Volume2, VolumeX, X, HelpCircle, Heart, Phone, Sparkles } from 'lucide-react';

interface SeniorModeBannerProps {
  isEnabled: boolean;
  onToggle: () => void;
}

export const SeniorModeBanner: React.FC<SeniorModeBannerProps> = ({ isEnabled, onToggle }) => {
  const [isSpeakingGuide, setIsSpeakingGuide] = useState(false);

  if (!isEnabled) return null;

  const handleSpeakInstructions = () => {
    if (!('speechSynthesis' in window)) {
      alert('Trình duyệt chưa hỗ trợ Text-to-Speech');
      return;
    }

    if (isSpeakingGuide) {
      window.speechSynthesis.cancel();
      setIsSpeakingGuide(false);
      return;
    }

    window.speechSynthesis.cancel();
    const text = 'Chào các bác và các cô chú! Chế độ Dễ Đọc của Thư viện cộng đồng số xã Liên Châu đã được bật. Cỡ chữ đã được phóng to, độ tương phản cao rõ ràng. Bác chỉ cần bấm vào cuốn sách muốn đọc hoặc bấm nút Nghe để nghe sách nói. Nếu cần trợ giúp, bác có thể bấm vào nút Thủ thư AI ở góc màn hình.';
    const utter = new SpeechSynthesisUtterance(text);
    utter.lang = 'vi-VN';
    utter.rate = 0.9;
    utter.onend = () => setIsSpeakingGuide(false);
    utter.onerror = () => setIsSpeakingGuide(false);
    window.speechSynthesis.speak(utter);
    setIsSpeakingGuide(true);
  };

  return (
    <div className="bg-amber-400 text-stone-950 px-4 py-3 border-b-4 border-amber-600 shadow-md">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-stone-950 text-amber-400 flex items-center justify-center shrink-0">
            <Eye className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-extrabold text-base sm:text-lg tracking-tight">
              ĐANG BẬT CHẾ ĐỘ DỄ ĐỌC (DÀNH CHO NGƯỜI CAO TUỔI)
            </h3>
            <p className="text-xs sm:text-sm font-semibold text-stone-800">
              Chữ to hơn • Tương phản nét • Nút bấm lớn • Hỗ trợ đọc to thành tiếng
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-start md:self-auto">
          {/* Read aloud guide */}
          <button
            onClick={handleSpeakInstructions}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 cursor-pointer transition-colors shadow-xs ${
              isSpeakingGuide
                ? 'bg-rose-600 text-white animate-pulse'
                : 'bg-stone-900 text-white hover:bg-stone-800'
            }`}
          >
            {isSpeakingGuide ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            <span>{isSpeakingGuide ? 'Dừng đọc hướng dẫn' : 'Đọc hướng dẫn bằng giọng nói'}</span>
          </button>

          {/* Turn off button */}
          <button
            onClick={onToggle}
            className="px-3 py-2 rounded-xl bg-amber-200 hover:bg-amber-300 text-stone-900 text-xs sm:text-sm font-bold border border-amber-500 cursor-pointer"
          >
            Tắt chế độ này
          </button>
        </div>
      </div>
    </div>
  );
};
