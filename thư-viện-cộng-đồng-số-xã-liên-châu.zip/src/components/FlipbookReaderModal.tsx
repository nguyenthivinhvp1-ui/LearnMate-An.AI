import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  ChevronLeft, 
  ChevronRight, 
  Volume2, 
  VolumeX, 
  Maximize2, 
  Minimize2, 
  Grid, 
  ZoomIn, 
  ZoomOut, 
  FileText, 
  Share2, 
  Bookmark,
  Sparkles,
  BookOpen
} from 'lucide-react';
import { Book } from '../types/library';
import { updateReadingProgress } from '../services/storageService';

interface FlipbookReaderModalProps {
  book: Book | null;
  isOpen: boolean;
  onClose: () => void;
  onSwitchToPdf: () => void;
  onShare: (book: Book) => void;
}

export const FlipbookReaderModal: React.FC<FlipbookReaderModalProps> = ({
  book,
  isOpen,
  onClose,
  onSwitchToPdf,
  onShare,
}) => {
  const [currentPage, setCurrentPage] = useState(1);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [showThumbnails, setShowThumbnails] = useState(false);
  const [isFlipping, setIsFlipping] = useState<'next' | 'prev' | null>(null);
  const [zoomLevel, setZoomLevel] = useState(100);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Play synthetic paper flip sound via Web Audio API (reliable & instant)
  const playPageFlipSound = () => {
    if (!soundEnabled) return;
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const bufferSize = audioCtx.sampleRate * 0.15;
      const buffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
      const data = buffer.getChannelData(0);

      // Create filtered white noise simulating paper rustle
      for (let i = 0; i < bufferSize; i++) {
        const decay = 1 - i / bufferSize;
        data[i] = (Math.random() * 2 - 1) * Math.sin((i / bufferSize) * Math.PI) * decay * 0.15;
      }

      const noise = audioCtx.createBufferSource();
      noise.buffer = buffer;

      const filter = audioCtx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(1200, audioCtx.currentTime);

      noise.connect(filter);
      filter.connect(audioCtx.destination);
      noise.start();
    } catch (e) {
      // AudioContext may be restricted by browser policy
    }
  };

  useEffect(() => {
    if (book && isOpen) {
      updateReadingProgress(book.id, currentPage, book.pages);
    }
  }, [currentPage, book, isOpen]);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isOpen) return;
      if (e.key === 'ArrowRight' || e.key === 'PageDown') {
        handleNext();
      } else if (e.key === 'ArrowLeft' || e.key === 'PageUp') {
        handlePrev();
      } else if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, currentPage]);

  if (!isOpen || !book) return null;

  const totalPages = book.pages || 64;

  const handleNext = () => {
    if (currentPage < totalPages && !isFlipping) {
      setIsFlipping('next');
      playPageFlipSound();
      setTimeout(() => {
        setCurrentPage((p) => Math.min(totalPages, p + 2));
        setIsFlipping(null);
      }, 350);
    }
  };

  const handlePrev = () => {
    if (currentPage > 1 && !isFlipping) {
      setIsFlipping('prev');
      playPageFlipSound();
      setTimeout(() => {
        setCurrentPage((p) => Math.max(1, p - 2));
        setIsFlipping(null);
      }, 350);
    }
  };

  const samplePages = book.contentSample || [];

  const getPageContent = (page: number) => {
    if (page === 1) {
      return (
        <div className="flex flex-col items-center justify-center text-center h-full p-6 bg-gradient-to-br from-emerald-50 via-white to-stone-50">
          <div className="w-16 h-16 rounded-2xl bg-emerald-700 text-white flex items-center justify-center shadow-lg mb-4">
            <BookOpen className="w-8 h-8" />
          </div>
          <span className="text-[11px] font-bold tracking-widest text-emerald-800 uppercase">
            THƯ VIỆN CỘNG ĐỒNG SỐ XÃ LIÊN CHÂU
          </span>
          <h2 className="text-xl sm:text-2xl font-extrabold text-stone-900 mt-2 mb-1">
            {book.title}
          </h2>
          <p className="text-sm font-semibold text-emerald-800 mb-6">
            Tác giả: {book.author}
          </p>
          <div className="text-xs text-stone-500 border-t border-stone-200 pt-4 w-full">
            <p>Nhà xuất bản: {book.publisher}</p>
            <p>Năm xuất bản: {book.year}</p>
            <p className="mt-2 text-emerald-700 font-medium">Bản quyền: {book.copyright}</p>
          </div>
        </div>
      );
    }

    const contentIdx = (page - 2) % Math.max(1, samplePages.length);
    const text = samplePages[contentIdx] || `Nội dung tài liệu trang ${page}: Kiến thức khoa học phổ biến cho cộng đồng.`;

    return (
      <div className="h-full flex flex-col justify-between p-6 sm:p-8 bg-stone-50/70 font-serif">
        <div className="flex items-center justify-between text-[11px] text-stone-400 border-b pb-2">
          <span className="truncate max-w-[200px]">{book.title}</span>
          <span>Trang {page}</span>
        </div>
        <div className="flex-1 my-4 text-xs sm:text-sm text-stone-800 leading-relaxed whitespace-pre-line overflow-y-auto">
          {text}
        </div>
        <div className="text-[10px] text-stone-400 border-t pt-2 flex items-center justify-between">
          <span>Trung tâm Học tập Cộng đồng Xã Liên Châu</span>
          <span>{page} / {totalPages}</span>
        </div>
      </div>
    );
  };

  const leftPageNum = currentPage % 2 === 0 ? currentPage : currentPage > 1 ? currentPage - 1 : 0;
  const rightPageNum = leftPageNum === 0 ? 1 : leftPageNum + 1;

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      containerRef.current?.requestFullscreen?.();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen?.();
      setIsFullscreen(false);
    }
  };

  return (
    <div 
      ref={containerRef}
      className="fixed inset-0 z-50 flex flex-col bg-stone-950/95 text-stone-100 select-none animate-fade-in"
    >
      {/* Top Controls Toolbar */}
      <div className="bg-stone-900 px-4 sm:px-6 py-2.5 flex items-center justify-between border-b border-stone-800 gap-2 shrink-0">
        <div className="flex items-center gap-2 min-w-0">
          <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-amber-500 text-stone-950 uppercase tracking-wider">
            FLIPBOOK 3D
          </span>
          <h3 className="font-bold text-xs sm:text-sm text-stone-200 truncate max-w-[200px] sm:max-w-md">
            {book.title}
          </h3>
        </div>

        {/* Action icons */}
        <div className="flex items-center gap-2">
          {/* Sound Toggle */}
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
              soundEnabled ? 'bg-emerald-950 text-emerald-400 border border-emerald-700/50' : 'bg-stone-800 text-stone-400'
            }`}
            title={soundEnabled ? 'Đang bật âm thanh lật trang' : 'Đã tắt âm thanh lật trang'}
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>

          {/* Thumbnail strip toggle */}
          <button
            onClick={() => setShowThumbnails(!showThumbnails)}
            className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
              showThumbnails ? 'bg-amber-400 text-stone-900 font-bold' : 'bg-stone-800 text-stone-300'
            }`}
            title="Xem danh sách trang (Thumbnails)"
          >
            <Grid className="w-4 h-4" />
          </button>

          {/* Switch to PDF mode (Section 11) */}
          <button
            onClick={onSwitchToPdf}
            className="hidden sm:flex items-center gap-1 px-2.5 py-1 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-medium cursor-pointer"
            title="Chuyển sang chế độ đọc PDF cuộn thông thường"
          >
            <FileText className="w-3.5 h-3.5 text-rose-400" />
            <span>Đọc PDF</span>
          </button>

          {/* Share */}
          <button
            onClick={() => onShare(book)}
            className="p-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-200 cursor-pointer hidden sm:block"
            title="Chia sẻ sách lật"
          >
            <Share2 className="w-4 h-4" />
          </button>

          {/* Fullscreen */}
          <button
            onClick={toggleFullscreen}
            className="p-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-200 cursor-pointer"
            title="Toàn màn hình"
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>

          {/* Close */}
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white cursor-pointer ml-1"
            title="Đóng sách lật"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Flipbook 3D Stage */}
      <div className="flex-1 relative flex items-center justify-center p-4 sm:p-10 overflow-hidden">
        {/* Navigation Arrows */}
        <button
          onClick={handlePrev}
          disabled={currentPage <= 1}
          className="absolute left-3 sm:left-6 z-20 w-11 h-11 sm:w-13 sm:h-13 rounded-full bg-stone-900/80 hover:bg-emerald-700 disabled:opacity-20 text-white flex items-center justify-center shadow-2xl backdrop-blur-xs transition-all cursor-pointer disabled:cursor-not-allowed group"
          title="Trang trước"
        >
          <ChevronLeft className="w-6 h-6 group-hover:-translate-x-0.5 transition-transform" />
        </button>

        <button
          onClick={handleNext}
          disabled={currentPage >= totalPages}
          className="absolute right-3 sm:right-6 z-20 w-11 h-11 sm:w-13 sm:h-13 rounded-full bg-stone-900/80 hover:bg-emerald-700 disabled:opacity-20 text-white flex items-center justify-center shadow-2xl backdrop-blur-xs transition-all cursor-pointer disabled:cursor-not-allowed group"
          title="Trang sau"
        >
          <ChevronRight className="w-6 h-6 group-hover:translate-x-0.5 transition-transform" />
        </button>

        {/* 3D Book Container with Realistic Spine Shadow & Perspective */}
        <div 
          className="relative max-w-5xl w-full aspect-4/3 sm:aspect-16/10 flex rounded-2xl shadow-[0_25px_60px_-15px_rgba(0,0,0,0.7)] overflow-hidden border-2 border-stone-800 bg-[#e9ded0] transition-transform duration-300"
          style={{
            perspective: '1400px',
            transform: `scale(${zoomLevel / 100})`,
          }}
        >
          {/* Left Page */}
          <div className="flex-1 h-full border-r border-stone-300/80 relative shadow-inner bg-stone-100 overflow-hidden">
            {leftPageNum > 0 ? (
              getPageContent(leftPageNum)
            ) : (
              <div className="h-full bg-gradient-to-r from-stone-300 to-stone-200 flex items-center justify-center text-xs text-stone-500 font-serif">
                Bìa trước • Thư viện số Liên Châu
              </div>
            )}
            {/* Page gradient shadow near spine */}
            <div className="absolute top-0 right-0 bottom-0 w-8 bg-gradient-to-l from-stone-950/25 to-transparent pointer-events-none" />
          </div>

          {/* Right Page */}
          <div className={`flex-1 h-full relative shadow-inner bg-white overflow-hidden transition-all duration-300 ${
            isFlipping ? 'opacity-70 scale-98' : 'opacity-100 scale-100'
          }`}>
            {rightPageNum <= totalPages ? (
              getPageContent(rightPageNum)
            ) : (
              <div className="h-full bg-stone-100 flex items-center justify-center text-xs text-stone-400">
                Hết sách
              </div>
            )}
            {/* Page gradient shadow near spine */}
            <div className="absolute top-0 left-0 bottom-0 w-8 bg-gradient-to-r from-stone-950/25 to-transparent pointer-events-none" />
          </div>

          {/* Center Spine Crease */}
          <div className="absolute top-0 bottom-0 left-1/2 -translate-x-1/2 w-1 bg-stone-950/40 pointer-events-none z-10" />
        </div>
      </div>

      {/* Bottom Thumbnail Strip Drawer (Section 11) */}
      {showThumbnails && (
        <div className="bg-stone-900 border-t border-stone-800 p-3 overflow-x-auto flex gap-3 shrink-0 no-scrollbar">
          {Array.from({ length: Math.ceil(totalPages / 2) }).map((_, i) => {
            const pageNum = i * 2 + 1;
            const isCurrent = currentPage === pageNum || currentPage === pageNum + 1;
            return (
              <button
                key={i}
                onClick={() => {
                  setCurrentPage(pageNum);
                  playPageFlipSound();
                }}
                className={`shrink-0 w-20 h-28 rounded-lg border-2 p-1 bg-white text-stone-900 flex flex-col justify-between transition-all cursor-pointer ${
                  isCurrent ? 'border-amber-400 scale-105 shadow-md' : 'border-stone-700 opacity-60 hover:opacity-100'
                }`}
              >
                <div className="text-[9px] font-bold text-stone-600 line-clamp-2">
                  {book.title}
                </div>
                <div className="text-[10px] font-semibold text-center text-emerald-800 border-t pt-0.5">
                  Trang {pageNum}-{pageNum + 1}
                </div>
              </button>
            );
          })}
        </div>
      )}

      {/* Bottom Navigation Status */}
      <div className="bg-stone-900 px-4 py-2 border-t border-stone-800 flex items-center justify-between text-xs text-stone-400">
        <div>
          <span>Đang xem trang <strong>{leftPageNum || 1} - {rightPageNum}</strong> / {totalPages}</span>
        </div>
        <div className="flex items-center gap-2">
          <span>Dùng phím <strong>← / →</strong> để lật sách</span>
        </div>
      </div>
    </div>
  );
};
