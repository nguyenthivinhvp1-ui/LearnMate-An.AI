import React, { useState } from 'react';
import { 
  BookOpen, 
  Search, 
  Eye, 
  Sparkles, 
  Bookmark, 
  ShieldCheck, 
  MessageSquareQuote,
  Menu, 
  X,
  Volume2,
  Calendar,
  Layers,
  Heart
} from 'lucide-react';
import { LibraryUserData } from '../types/library';

interface HeaderProps {
  searchQuery: string;
  onSearchChange: (q: string) => void;
  isSeniorMode: boolean;
  onToggleSeniorMode: () => void;
  onOpenMyLibrary: () => void;
  onOpenAdmin: () => void;
  onOpenChat: () => void;
  onSelectCategory: (catId: string) => void;
  onSelectAudience: (audId: string) => void;
  onScrollToSection: (sectionId: string) => void;
  userData: LibraryUserData;
  activeFilterFormat: string | null;
  onSelectFormat: (format: string | null) => void;
}

export const Header: React.FC<HeaderProps> = ({
  searchQuery,
  onSearchChange,
  isSeniorMode,
  onToggleSeniorMode,
  onOpenMyLibrary,
  onOpenAdmin,
  onOpenChat,
  onScrollToSection,
  userData,
  activeFilterFormat,
  onSelectFormat,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);

  const totalFavorites = userData.favorites.length;
  const totalReading = userData.readingHistory.length;

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-stone-200 shadow-xs transition-colors">
      {/* Top institutional strip */}
      <div className="bg-emerald-800 text-white text-xs py-1.5 px-4">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 font-medium tracking-wide">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span>UBND XÃ LIÊN CHÂU • TRUNG TÂM HỌC TẬP CỘNG ĐỒNG</span>
          </div>
          <div className="flex items-center gap-4 text-emerald-100 text-[11px] font-normal">
            <span className="hidden sm:inline italic">"Kết nối tri thức – Lan tỏa văn hóa đọc"</span>
            <button 
              onClick={() => onScrollToSection('huong-dan')}
              className="hover:text-white underline decoration-emerald-400 cursor-pointer"
            >
              Hướng dẫn sử dụng
            </button>
            <button 
              onClick={() => onScrollToSection('hoat-dong')}
              className="hover:text-white underline decoration-emerald-400 cursor-pointer"
            >
              Hoạt động cộng đồng
            </button>
          </div>
        </div>
      </div>

      {/* Main navigation */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-18 sm:h-20 gap-3">
          {/* Logo & Slogan */}
          <div 
            onClick={() => onScrollToSection('hero')} 
            className="flex items-center gap-3 cursor-pointer group shrink-0"
          >
            <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-xl bg-gradient-to-br from-emerald-600 to-teal-700 text-white flex items-center justify-center shadow-md shadow-emerald-700/20 group-hover:scale-105 transition-transform">
              <BookOpen className="w-6 h-6 sm:w-7 sm:h-7" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-base sm:text-lg font-bold text-stone-900 group-hover:text-emerald-700 transition-colors uppercase tracking-tight">
                  Thư Viện Số Liên Châu
                </span>
                <span className="hidden md:inline-block px-1.5 py-0.5 text-[10px] font-semibold bg-emerald-100 text-emerald-800 rounded">
                  2026
                </span>
              </div>
              <p className="text-xs text-stone-500 hidden sm:block">
                Kho tri thức mở dành cho mọi người dân
              </p>
            </div>
          </div>

          {/* Center search bar (desktop) */}
          <div className="hidden lg:flex items-center flex-1 max-w-md mx-4">
            <div className="relative w-full">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                placeholder="Tìm tên sách, tác giả, nông nghiệp, kỹ năng số..."
                className="w-full pl-10 pr-4 py-2 bg-stone-100/80 hover:bg-stone-100 focus:bg-white text-sm rounded-full border border-stone-200 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-600/20 outline-hidden transition-all text-stone-800 placeholder-stone-400"
              />
              {searchQuery && (
                <button
                  onClick={() => onSearchChange('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600 text-xs font-bold"
                >
                  ✕
                </button>
              )}
            </div>
          </div>

          {/* Quick Action buttons */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Senior Mode Toggle (Section 17) */}
            <button
              onClick={onToggleSeniorMode}
              className={`flex items-center gap-1.5 px-3 py-1.5 sm:px-3.5 sm:py-2 rounded-full font-medium text-xs sm:text-sm transition-all cursor-pointer border ${
                isSeniorMode
                  ? 'bg-amber-400 text-stone-900 border-amber-500 font-bold shadow-md shadow-amber-300/40 ring-2 ring-amber-400'
                  : 'bg-stone-100 text-stone-700 hover:bg-amber-100/60 border-stone-200 hover:border-amber-300'
              }`}
              title="Chế độ Dễ đọc: Chữ to, tương phản cao, hỗ trợ đọc thành tiếng cho Người cao tuổi"
            >
              <Eye className="w-4 h-4 text-amber-700" />
              <span className="hidden xs:inline">Chế độ</span>
              <span>Dễ đọc</span>
            </button>

            {/* AI Librarian Chatbot Trigger */}
            <button
              onClick={onOpenChat}
              className="relative flex items-center gap-1.5 px-3 py-1.5 sm:px-3.5 sm:py-2 rounded-full font-medium text-xs sm:text-sm bg-gradient-to-r from-blue-600 to-indigo-600 text-white hover:from-blue-700 hover:to-indigo-700 shadow-sm transition-all cursor-pointer"
              title="Trợ lý Thủ thư số thông minh"
            >
              <Sparkles className="w-4 h-4 text-yellow-300 animate-spin-slow" />
              <span className="hidden sm:inline">Hỏi</span>
              <span>Thủ thư AI</span>
              <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-sky-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-sky-500"></span>
              </span>
            </button>

            {/* My Library Button (Section 20) */}
            <button
              onClick={onOpenMyLibrary}
              className="flex items-center gap-1.5 px-3 py-1.5 sm:px-3.5 sm:py-2 rounded-full font-medium text-xs sm:text-sm bg-stone-100 hover:bg-stone-200/70 text-stone-800 border border-stone-200 transition-colors cursor-pointer relative"
              title="Tủ sách của tôi: Yêu thích, Đang đọc, Lịch sử, Đánh dấu"
            >
              <Bookmark className="w-4 h-4 text-emerald-600" />
              <span className="hidden md:inline">Tủ sách của tôi</span>
              {(totalFavorites > 0 || totalReading > 0) && (
                <span className="inline-flex items-center justify-center px-1.5 py-0.5 text-[11px] font-bold bg-emerald-600 text-white rounded-full">
                  {totalFavorites + totalReading}
                </span>
              )}
            </button>

            {/* Admin Management (Section 25) */}
            <button
              onClick={onOpenAdmin}
              className="hidden sm:flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-medium text-stone-600 hover:text-stone-900 hover:bg-stone-100 border border-stone-200 transition-colors cursor-pointer"
              title="Bảng Quản trị Thư viện dành cho cán bộ"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-stone-500" />
              <span>Quản trị</span>
            </button>

            {/* Mobile menu toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-stone-600 hover:text-stone-900 rounded-lg hover:bg-stone-100 cursor-pointer"
              aria-label="Mở menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile search bar dropdown */}
        <div className="lg:hidden pb-3">
          <div className="relative w-full">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Tìm kiếm tài liệu, nông nghiệp, pháp luật..."
              className="w-full pl-10 pr-4 py-2 bg-stone-100 text-sm rounded-full border border-stone-200 focus:outline-hidden focus:border-emerald-600 text-stone-800"
            />
          </div>
        </div>

        {/* Quick Format Filter Tabs */}
        <div className="hidden md:flex items-center gap-1.5 py-2 border-t border-stone-100 overflow-x-auto no-scrollbar text-xs">
          <span className="text-stone-400 font-medium mr-1 flex items-center gap-1">
            <Layers className="w-3.5 h-3.5" /> Định dạng:
          </span>
          <button
            onClick={() => onSelectFormat(null)}
            className={`px-3 py-1 rounded-full font-medium transition-colors cursor-pointer ${
              activeFilterFormat === null
                ? 'bg-emerald-700 text-white font-semibold'
                : 'text-stone-600 hover:bg-stone-100'
            }`}
          >
            Tất cả
          </button>
          <button
            onClick={() => onSelectFormat('flipbook')}
            className={`px-3 py-1 rounded-full font-medium transition-colors cursor-pointer flex items-center gap-1 ${
              activeFilterFormat === 'flipbook'
                ? 'bg-emerald-700 text-white font-semibold'
                : 'text-stone-600 hover:bg-stone-100'
            }`}
          >
            📖 Sách lật 3D
          </button>
          <button
            onClick={() => onSelectFormat('pdf')}
            className={`px-3 py-1 rounded-full font-medium transition-colors cursor-pointer flex items-center gap-1 ${
              activeFilterFormat === 'pdf'
                ? 'bg-emerald-700 text-white font-semibold'
                : 'text-stone-600 hover:bg-stone-100'
            }`}
          >
            📄 Sách PDF
          </button>
          <button
            onClick={() => onSelectFormat('comic')}
            className={`px-3 py-1 rounded-full font-medium transition-colors cursor-pointer flex items-center gap-1 ${
              activeFilterFormat === 'comic'
                ? 'bg-emerald-700 text-white font-semibold'
                : 'text-stone-600 hover:bg-stone-100'
            }`}
          >
            🎨 Truyện tranh
          </button>
          <button
            onClick={() => onSelectFormat('audio')}
            className={`px-3 py-1 rounded-full font-medium transition-colors cursor-pointer flex items-center gap-1 ${
              activeFilterFormat === 'audio'
                ? 'bg-emerald-700 text-white font-semibold'
                : 'text-stone-600 hover:bg-stone-100'
            }`}
          >
            🎧 Sách nói
          </button>
          <button
            onClick={() => onSelectFormat('video')}
            className={`px-3 py-1 rounded-full font-medium transition-colors cursor-pointer flex items-center gap-1 ${
              activeFilterFormat === 'video'
                ? 'bg-emerald-700 text-white font-semibold'
                : 'text-stone-600 hover:bg-stone-100'
            }`}
          >
            🎬 Video tri thức
          </button>
          
          <div className="ml-auto flex items-center gap-2">
            <button
              onClick={() => onScrollToSection('goc-tre-em')}
              className="text-amber-700 hover:text-amber-800 font-semibold flex items-center gap-1 hover:underline cursor-pointer"
            >
              🌈 Góc Trẻ Em
            </button>
            <button
              onClick={() => onScrollToSection('hoc-tap-suot-doi')}
              className="text-teal-700 hover:text-teal-800 font-semibold flex items-center gap-1 hover:underline cursor-pointer"
            >
              🌱 Học tập suốt đời
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-stone-200 bg-white px-4 py-4 space-y-3">
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => {
                onScrollToSection('kho-sach');
                setMobileMenuOpen(false);
              }}
              className="p-2.5 rounded-lg bg-emerald-50 text-emerald-800 text-sm font-medium text-left flex items-center gap-2"
            >
              <BookOpen className="w-4 h-4" /> Kho Sách Điện Tử
            </button>
            <button
              onClick={() => {
                onScrollToSection('goc-tre-em');
                setMobileMenuOpen(false);
              }}
              className="p-2.5 rounded-lg bg-amber-50 text-amber-800 text-sm font-medium text-left flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4" /> Góc Trẻ Em
            </button>
            <button
              onClick={() => {
                onScrollToSection('hoat-dong');
                setMobileMenuOpen(false);
              }}
              className="p-2.5 rounded-lg bg-blue-50 text-blue-800 text-sm font-medium text-left flex items-center gap-2"
            >
              <Calendar className="w-4 h-4" /> Hoạt động Thư viện
            </button>
            <button
              onClick={() => {
                onOpenAdmin();
                setMobileMenuOpen(false);
              }}
              className="p-2.5 rounded-lg bg-stone-100 text-stone-800 text-sm font-medium text-left flex items-center gap-2"
            >
              <ShieldCheck className="w-4 h-4" /> Quản trị Thư viện
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
