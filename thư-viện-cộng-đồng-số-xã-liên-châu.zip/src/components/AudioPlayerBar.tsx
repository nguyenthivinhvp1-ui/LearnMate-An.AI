import React, { useState, useEffect, useRef } from 'react';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  RotateCw, 
  Volume2, 
  VolumeX, 
  X, 
  ChevronUp, 
  ChevronDown, 
  Headphones, 
  Sliders, 
  ListMusic,
  Maximize2
} from 'lucide-react';
import { Book } from '../types/library';

interface AudioPlayerBarProps {
  book: Book | null;
  isOpen: boolean;
  onClose: () => void;
  onOpenDetail?: (book: Book) => void;
}

export const AudioPlayerBar: React.FC<AudioPlayerBarProps> = ({
  book,
  isOpen,
  onClose,
  onOpenDetail,
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [playbackRate, setPlaybackRate] = useState<number>(1);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(360); // 6 mins default
  const [volume, setVolume] = useState(0.85);
  const [isMuted, setIsMuted] = useState(false);
  const [currentChapterIdx, setCurrentChapterIdx] = useState(0);
  const [useSpeechEngine, setUseSpeechEngine] = useState(true);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const intervalRef = useRef<any>(null);

  if (!isOpen || !book) return null;

  const chapters = book.chapters || [
    { id: 'ch1', title: 'Phần 1: Giới thiệu cội nguồn và bối cảnh tác phẩm', duration: '08:20' },
    { id: 'ch2', title: 'Phần 2: Những bài học quý giá lưu truyền ngàn đời', duration: '12:45' },
    { id: 'ch3', title: 'Phần 3: Vận dụng tri thức vào đời sống nông thôn mới', duration: '09:15' },
  ];

  const currentChapter = chapters[currentChapterIdx] || chapters[0];

  // Speech synthesis fallback for real voice
  const handleTogglePlay = () => {
    if (isPlaying) {
      setIsPlaying(false);
      if (audioRef.current) audioRef.current.pause();
      if ('speechSynthesis' in window) window.speechSynthesis.cancel();
      clearInterval(intervalRef.current);
    } else {
      setIsPlaying(true);
      // Play real synthesized audio
      if ('speechSynthesis' in window && useSpeechEngine) {
        window.speechSynthesis.cancel();
        const textToRead = `${book.title}. ${currentChapter.title}. ${book.description}. ${(book.contentSample || []).join(' ')}`;
        const utter = new SpeechSynthesisUtterance(textToRead);
        utter.lang = 'vi-VN';
        utter.rate = playbackRate;
        utter.volume = isMuted ? 0 : volume;
        utter.onend = () => setIsPlaying(false);
        utter.onerror = () => setIsPlaying(false);
        window.speechSynthesis.speak(utter);
      } else if (audioRef.current) {
        audioRef.current.play().catch(() => {});
      }

      // Progress counter
      clearInterval(intervalRef.current);
      intervalRef.current = setInterval(() => {
        setCurrentTime((t) => {
          if (t >= duration) {
            setIsPlaying(false);
            return 0;
          }
          return t + 1;
        });
      }, 1000 / playbackRate);
    }
  };

  const handleRewind10 = () => {
    setCurrentTime((t) => Math.max(0, t - 10));
    if (audioRef.current) audioRef.current.currentTime = Math.max(0, audioRef.current.currentTime - 10);
  };

  const handleForward10 = () => {
    setCurrentTime((t) => Math.min(duration, t + 10));
    if (audioRef.current) audioRef.current.currentTime = Math.min(duration, audioRef.current.currentTime + 10);
  };

  const handleRateChange = (newRate: number) => {
    setPlaybackRate(newRate);
    if (audioRef.current) audioRef.current.playbackRate = newRate;
    if (isPlaying && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsPlaying(false);
      setTimeout(() => handleTogglePlay(), 150);
    }
  };

  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${mins}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-stone-900/98 backdrop-blur-md text-white border-t border-stone-800 shadow-2xl transition-all">
      {/* Real audio element */}
      <audio
        ref={audioRef}
        src={book.audio || 'https://actions.google.com/sounds/v1/water/rain_heavy.ogg'}
        onTimeUpdate={(e) => setCurrentTime((e.target as HTMLAudioElement).currentTime)}
        onLoadedMetadata={(e) => setDuration((e.target as HTMLAudioElement).duration || 360)}
      />

      {/* Scrubber track (Section 13) */}
      <div 
        className="w-full bg-stone-800 h-1.5 cursor-pointer relative group"
        onClick={(e) => {
          const rect = e.currentTarget.getBoundingClientRect();
          const pos = (e.clientX - rect.left) / rect.width;
          const newTime = pos * duration;
          setCurrentTime(newTime);
          if (audioRef.current) audioRef.current.currentTime = newTime;
        }}
      >
        <div 
          className="bg-emerald-500 h-full relative"
          style={{ width: `${(currentTime / Math.max(1, duration)) * 100}%` }}
        >
          <span className="absolute right-0 top-1/2 -translate-y-1/2 w-3.5 h-3.5 bg-white rounded-full shadow-md scale-0 group-hover:scale-100 transition-transform" />
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex flex-col md:flex-row md:items-center justify-between gap-3">
        {/* Left: Book Cover and Info */}
        <div className="flex items-center gap-3 min-w-0 md:max-w-sm">
          <div 
            onClick={() => onOpenDetail && onOpenDetail(book)}
            className="w-12 h-12 rounded-xl overflow-hidden bg-stone-800 shrink-0 cursor-pointer shadow-md border border-stone-700"
          >
            <img src={book.cover} alt={book.title} className="w-full h-full object-cover" />
          </div>
          <div className="min-w-0">
            <h4 
              onClick={() => onOpenDetail && onOpenDetail(book)}
              className="text-xs sm:text-sm font-bold text-white truncate hover:text-emerald-400 cursor-pointer"
            >
              {book.title}
            </h4>
            <div className="flex items-center gap-2 text-stone-400 text-xs">
              <span className="truncate">{currentChapter.title}</span>
            </div>
          </div>
        </div>

        {/* Center: Controls (Play, Pause, Tua 10s, Timeline) */}
        <div className="flex flex-col items-center gap-1.5 flex-1 max-w-lg">
          <div className="flex items-center gap-4 sm:gap-6">
            {/* Tua lui 10s */}
            <button
              onClick={handleRewind10}
              className="p-1.5 text-stone-300 hover:text-white hover:bg-stone-800 rounded-full transition-colors cursor-pointer"
              title="Tua lùi 10 giây"
            >
              <RotateCcw className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>

            {/* Play / Pause button */}
            <button
              onClick={handleTogglePlay}
              className="w-11 h-11 sm:w-12 sm:h-12 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white flex items-center justify-center shadow-lg shadow-emerald-700/40 transition-transform hover:scale-105 active:scale-95 cursor-pointer"
              title={isPlaying ? 'Tạm dừng' : 'Phát sách nói'}
            >
              {isPlaying ? <Pause className="w-5 h-5 fill-white" /> : <Play className="w-5 h-5 fill-white ml-0.5" />}
            </button>

            {/* Tua tới 10s */}
            <button
              onClick={handleForward10}
              className="p-1.5 text-stone-300 hover:text-white hover:bg-stone-800 rounded-full transition-colors cursor-pointer"
              title="Tua tới 10 giây"
            >
              <RotateCw className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>
          </div>

          {/* Time display */}
          <div className="text-[11px] text-stone-400 font-mono flex items-center gap-1.5">
            <span>{formatTime(currentTime)}</span>
            <span>/</span>
            <span>{formatTime(duration)}</span>
          </div>
        </div>

        {/* Right: Chapter selector, Speed rates, Volume & Close */}
        <div className="flex items-center justify-end gap-2 sm:gap-3">
          {/* Chapter Selector */}
          <select
            value={currentChapterIdx}
            onChange={(e) => {
              setCurrentChapterIdx(parseInt(e.target.value, 10));
              setCurrentTime(0);
              if (isPlaying) {
                setTimeout(() => handleTogglePlay(), 100);
              }
            }}
            className="bg-stone-800 text-stone-200 text-xs py-1.5 px-2 rounded-lg border border-stone-700 outline-hidden font-medium hidden sm:block max-w-[140px] truncate"
          >
            {chapters.map((ch, idx) => (
              <option key={ch.id || idx} value={idx}>
                {ch.title}
              </option>
            ))}
          </select>

          {/* Speed Selector (0.75x, 1x, 1.25x, 1.5x, 2x) */}
          <div className="flex items-center bg-stone-800 rounded-lg p-0.5 text-xs font-semibold">
            {[0.75, 1, 1.25, 1.5, 2].map((rate) => (
              <button
                key={rate}
                onClick={() => handleRateChange(rate)}
                className={`px-1.5 sm:px-2 py-1 rounded cursor-pointer transition-colors ${
                  playbackRate === rate ? 'bg-emerald-600 text-white font-bold' : 'text-stone-400 hover:text-stone-200'
                }`}
              >
                {rate}x
              </button>
            ))}
          </div>

          {/* Volume Mute */}
          <button
            onClick={() => {
              const muted = !isMuted;
              setIsMuted(muted);
              if (audioRef.current) audioRef.current.muted = muted;
            }}
            className="p-1.5 text-stone-300 hover:text-white rounded-lg hover:bg-stone-800 transition-colors cursor-pointer"
            title={isMuted ? 'Bật âm lượng' : 'Tắt tiếng'}
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4" />}
          </button>

          {/* Close button */}
          <button
            onClick={() => {
              if (isPlaying) handleTogglePlay();
              onClose();
            }}
            className="p-1.5 text-stone-400 hover:text-rose-400 hover:bg-stone-800 rounded-lg transition-colors cursor-pointer ml-1"
            title="Đóng trình phát audio"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
