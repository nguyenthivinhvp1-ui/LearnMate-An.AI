import React, { useState } from 'react';
import { 
  X, 
  ShieldCheck, 
  Plus, 
  Edit3, 
  Trash2, 
  Eye, 
  EyeOff, 
  Download, 
  Upload, 
  Layers, 
  Users, 
  BookOpen, 
  Check, 
  AlertCircle,
  FileSpreadsheet,
  RotateCcw
} from 'lucide-react';
import { Book, Category, AudienceGroup, BookFormat, CopyrightStatus } from '../types/library';
import { exportLibraryToJson, importLibraryFromJson } from '../services/storageService';

interface AdminModalProps {
  isOpen: boolean;
  onClose: () => void;
  books: Book[];
  categories: Category[];
  audiences: AudienceGroup[];
  onSaveBook: (book: Book) => void;
  onDeleteBook: (bookId: string) => void;
  onToggleHideBook: (bookId: string) => void;
  onSaveCategory: (cat: Category) => void;
  onDeleteCategory: (catId: string) => void;
  onReloadData: () => void;
}

export const AdminModal: React.FC<AdminModalProps> = ({
  isOpen,
  onClose,
  books,
  categories,
  audiences,
  onSaveBook,
  onDeleteBook,
  onToggleHideBook,
  onSaveCategory,
  onDeleteCategory,
  onReloadData,
}) => {
  // Passcode verification: Default demo PIN: 123456
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [pinCode, setPinCode] = useState('');
  const [pinError, setPinError] = useState(false);

  const [activeTab, setActiveTab] = useState<'dashboard' | 'books' | 'categories' | 'backup'>('dashboard');

  // Book edit / add state
  const [editingBook, setEditingBook] = useState<Partial<Book> | null>(null);
  const [isAddBookModalOpen, setIsAddBookModalOpen] = useState(false);

  // New category state
  const [newCatName, setNewCatName] = useState('');
  const [newCatDesc, setNewCatDesc] = useState('');

  // Delete confirmation
  const [bookToDelete, setBookToDelete] = useState<Book | null>(null);

  if (!isOpen) return null;

  const handleVerifyPin = (e: React.FormEvent) => {
    e.preventDefault();
    if (pinCode === '123456' || pinCode === 'admin') {
      setIsAuthenticated(true);
      setPinError(false);
    } else {
      setPinError(true);
    }
  };

  const handleOpenAddBook = () => {
    setEditingBook({
      id: `book_${Date.now()}`,
      title: '',
      author: '',
      publisher: 'Trung tâm Học tập Cộng đồng Xã Liên Châu',
      year: 2026,
      categories: [categories[0]?.id || 'nong-nghiep'],
      audiences: ['nong-dan'],
      description: '',
      cover: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=600&q=80',
      format: 'flipbook',
      pages: 48,
      keywords: ['liên châu', 'học tập suốt đời'],
      views: 0,
      likes: 0,
      featured: false,
      copyright: 'Creative Commons',
      allowDownload: true,
      language: 'Tiếng Việt',
      addedAt: new Date().toISOString().slice(0, 10),
    });
    setIsAddBookModalOpen(true);
  };

  const handleSaveBookSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingBook || !editingBook.title) return;
    onSaveBook(editingBook as Book);
    setIsAddBookModalOpen(false);
    setEditingBook(null);
  };

  const handleImportJsonFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const ok = importLibraryFromJson(content);
      if (ok) {
        alert('Phục hồi dữ liệu thư viện từ file JSON thành công!');
        onReloadData();
      } else {
        alert('Định dạng file JSON không hợp lệ.');
      }
    };
    reader.readAsText(file);
  };

  // If not authenticated, show PIN entry modal (Section 25 & 38)
  if (!isAuthenticated) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/75 backdrop-blur-xs animate-fade-in">
        <div 
          className="relative w-full max-w-sm bg-white rounded-3xl shadow-2xl border border-stone-200 p-6 text-center space-y-4"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-800 mx-auto flex items-center justify-center shadow-xs">
            <ShieldCheck className="w-7 h-7" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-stone-900">
              QUẢN TRỊ THƯ VIỆN SỐ
            </h3>
            <p className="text-xs text-stone-500 mt-1">
              Dành riêng cho cán bộ quản lý thư viện xã Liên Châu.
            </p>
          </div>

          <form onSubmit={handleVerifyPin} className="space-y-3">
            <div>
              <input
                type="password"
                value={pinCode}
                onChange={(e) => setPinCode(e.target.value)}
                placeholder="Nhập mã PIN quản trị (Mặc định: 123456)"
                className="w-full py-2.5 px-4 text-center text-sm font-mono tracking-widest bg-stone-100 rounded-xl border border-stone-200 outline-hidden focus:border-emerald-600 focus:bg-white"
                autoFocus
              />
              {pinError && (
                <span className="text-[11px] text-rose-600 font-semibold block mt-1">
                  Mã PIN không đúng. Vui lòng nhập: 123456
                </span>
              )}
            </div>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 py-2 rounded-xl bg-stone-100 text-stone-700 text-xs font-semibold hover:bg-stone-200 cursor-pointer"
              >
                Hủy bỏ
              </button>
              <button
                type="submit"
                className="flex-1 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold transition-colors cursor-pointer shadow-xs"
              >
                Đăng nhập
              </button>
            </div>
          </form>

          <p className="text-[11px] text-stone-400">
            Hệ thống demo quản trị nội bộ xã Liên Châu
          </p>
        </div>
      </div>
    );
  }

  const totalViews = books.reduce((acc, b) => acc + (b.views || 0), 0);
  const totalLikes = books.reduce((acc, b) => acc + (b.likes || 0), 0);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-stone-950/75 backdrop-blur-xs overflow-y-auto animate-fade-in">
      <div 
        className="relative w-full max-w-5xl bg-white rounded-3xl shadow-2xl border border-stone-200 overflow-hidden flex flex-col my-auto max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-stone-100 bg-stone-900 text-white">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <h2 className="text-base sm:text-lg font-bold">
              BẢNG ĐIỀU KHIỂN QUẢN TRỊ VIÊN • THƯ VIỆN SỐ LIÊN CHÂU
            </h2>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-stone-800 hover:bg-stone-700 text-stone-300 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="px-6 pt-3 border-b border-stone-100 bg-stone-50 flex items-center justify-between gap-2 overflow-x-auto no-scrollbar">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`pb-3 px-3 text-xs sm:text-sm font-bold border-b-2 transition-colors cursor-pointer ${
                activeTab === 'dashboard' ? 'border-emerald-600 text-emerald-800' : 'border-transparent text-stone-500'
              }`}
            >
              Tổng quan Dashboard
            </button>
            <button
              onClick={() => setActiveTab('books')}
              className={`pb-3 px-3 text-xs sm:text-sm font-bold border-b-2 transition-colors cursor-pointer ${
                activeTab === 'books' ? 'border-emerald-600 text-emerald-800' : 'border-transparent text-stone-500'
              }`}
            >
              Quản lý Sách ({books.length})
            </button>
            <button
              onClick={() => setActiveTab('categories')}
              className={`pb-3 px-3 text-xs sm:text-sm font-bold border-b-2 transition-colors cursor-pointer ${
                activeTab === 'categories' ? 'border-emerald-600 text-emerald-800' : 'border-transparent text-stone-500'
              }`}
            >
              Quản lý Danh mục ({categories.length})
            </button>
            <button
              onClick={() => setActiveTab('backup')}
              className={`pb-3 px-3 text-xs sm:text-sm font-bold border-b-2 transition-colors cursor-pointer ${
                activeTab === 'backup' ? 'border-emerald-600 text-emerald-800' : 'border-transparent text-stone-500'
              }`}
            >
              Sao lưu & Phục hồi JSON / CSV
            </button>
          </div>

          {activeTab === 'books' && (
            <button
              onClick={handleOpenAddBook}
              className="mb-2 px-3.5 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
            >
              <Plus className="w-4 h-4" />
              <span>Thêm sách mới</span>
            </button>
          )}
        </div>

        {/* Body content */}
        <div className="p-6 overflow-y-auto flex-1">
          {/* Tab 1: Dashboard Overview (Section 25) */}
          {activeTab === 'dashboard' && (
            <div className="space-y-6">
              {/* Stat cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200">
                  <span className="text-xs font-semibold text-emerald-700 block">Tổng số sách & tài liệu:</span>
                  <span className="text-2xl font-extrabold text-emerald-950 mt-1 block">{books.length}</span>
                </div>
                <div className="p-4 rounded-2xl bg-teal-50 border border-teal-200">
                  <span className="text-xs font-semibold text-teal-700 block">Tổng lượt đọc:</span>
                  <span className="text-2xl font-extrabold text-teal-950 mt-1 block">{totalViews.toLocaleString('vi-VN')}</span>
                </div>
                <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200">
                  <span className="text-xs font-semibold text-amber-700 block">Lượt yêu thích:</span>
                  <span className="text-2xl font-extrabold text-amber-950 mt-1 block">{totalLikes}</span>
                </div>
                <div className="p-4 rounded-2xl bg-blue-50 border border-blue-200">
                  <span className="text-xs font-semibold text-blue-700 block">Định dạng tài liệu:</span>
                  <span className="text-xs font-bold text-blue-900 mt-2 block">
                    Flipbook • PDF • Comic • Audio • Video
                  </span>
                </div>
              </div>

              {/* Recent activity & Popular materials */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200">
                  <h4 className="font-bold text-xs uppercase tracking-wider text-stone-500 mb-3">
                    Tài liệu được đọc nhiều nhất:
                  </h4>
                  <div className="space-y-2">
                    {[...books]
                      .sort((a, b) => b.views - a.views)
                      .slice(0, 5)
                      .map((b, i) => (
                        <div key={b.id} className="flex items-center justify-between text-xs p-2 bg-white rounded-xl border border-stone-200/80">
                          <span className="font-semibold text-stone-800 truncate max-w-[240px]">
                            {i + 1}. {b.title}
                          </span>
                          <span className="font-bold text-emerald-700">{b.views} lượt</span>
                        </div>
                      ))}
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200">
                  <h4 className="font-bold text-xs uppercase tracking-wider text-stone-500 mb-3">
                    Hoạt động quản trị gần đây:
                  </h4>
                  <div className="space-y-2 text-xs text-stone-600">
                    <div className="p-2 bg-white rounded-xl border border-stone-200/80">
                      ✓ Đã cập nhật Sổ tay Kỹ thuật Trồng trọt & BVTV Xã Liên Châu
                    </div>
                    <div className="p-2 bg-white rounded-xl border border-stone-200/80">
                      ✓ Đã bổ sung 03 sách nói Audio cho Người cao tuổi
                    </div>
                    <div className="p-2 bg-white rounded-xl border border-stone-200/80">
                      ✓ Đã tạo mã QR in ấn cho 24 tài liệu cơ sở
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Tab 2: Books Table & Management (Section 25) */}
          {activeTab === 'books' && (
            <div className="space-y-3">
              <div className="overflow-x-auto border border-stone-200 rounded-2xl">
                <table className="w-full text-left text-xs">
                  <thead className="bg-stone-100 text-stone-600 font-bold border-b border-stone-200">
                    <tr>
                      <th className="p-3">Bìa</th>
                      <th className="p-3">Tên tài liệu</th>
                      <th className="p-3">Tác giả & Năm</th>
                      <th className="p-3">Định dạng</th>
                      <th className="p-3">Lượt đọc</th>
                      <th className="p-3">Trạng thái</th>
                      <th className="p-3 text-right">Thao tác</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {books.map((b) => (
                      <tr key={b.id} className="hover:bg-stone-50/70">
                        <td className="p-2">
                          <img src={b.cover} alt={b.title} className="w-8 h-11 object-cover rounded shadow-2xs" />
                        </td>
                        <td className="p-3 font-semibold text-stone-900 max-w-[220px]">
                          <span className="line-clamp-1">{b.title}</span>
                          <span className="text-[10px] text-stone-400 block">{b.categories.join(', ')}</span>
                        </td>
                        <td className="p-3 text-stone-600">
                          <div>{b.author}</div>
                          <div className="text-[10px] text-stone-400">{b.year}</div>
                        </td>
                        <td className="p-3">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-stone-200 text-stone-800 uppercase">
                            {b.format}
                          </span>
                        </td>
                        <td className="p-3 font-semibold text-stone-700">{b.views}</td>
                        <td className="p-3">
                          {b.isHidden ? (
                            <span className="px-2 py-0.5 rounded bg-stone-200 text-stone-600 text-[10px] font-bold">
                              Đang ẩn
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                              Hiển thị
                            </span>
                          )}
                        </td>
                        <td className="p-3 text-right">
                          <div className="flex items-center justify-end gap-1">
                            <button
                              onClick={() => onToggleHideBook(b.id)}
                              className="p-1.5 hover:bg-stone-200 rounded text-stone-600 cursor-pointer"
                              title={b.isHidden ? 'Hiện tài liệu' : 'Ẩn tài liệu'}
                            >
                              {b.isHidden ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                            </button>
                            <button
                              onClick={() => {
                                setEditingBook(b);
                                setIsAddBookModalOpen(true);
                              }}
                              className="p-1.5 hover:bg-emerald-100 rounded text-emerald-800 cursor-pointer"
                              title="Sửa tài liệu"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => setBookToDelete(b)}
                              className="p-1.5 hover:bg-rose-100 rounded text-rose-600 cursor-pointer"
                              title="Xóa tài liệu"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Tab 3: Category Management (Section 27) */}
          {activeTab === 'categories' && (
            <div className="space-y-4">
              {/* Add category form */}
              <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 flex flex-col sm:flex-row gap-3 items-end">
                <div className="flex-1 w-full">
                  <label className="text-xs font-semibold text-stone-700 block mb-1">Tên danh mục mới:</label>
                  <input
                    type="text"
                    value={newCatName}
                    onChange={(e) => setNewCatName(e.target.value)}
                    placeholder="VD: Kỹ năng khởi nghiệp, Văn hóa truyền thống..."
                    className="w-full py-2 px-3 text-xs bg-white rounded-xl border border-stone-300 outline-hidden focus:border-emerald-600"
                  />
                </div>
                <div className="flex-1 w-full">
                  <label className="text-xs font-semibold text-stone-700 block mb-1">Mô tả danh mục:</label>
                  <input
                    type="text"
                    value={newCatDesc}
                    onChange={(e) => setNewCatDesc(e.target.value)}
                    placeholder="Tài liệu bồi dưỡng..."
                    className="w-full py-2 px-3 text-xs bg-white rounded-xl border border-stone-300 outline-hidden focus:border-emerald-600"
                  />
                </div>
                <button
                  onClick={() => {
                    if (!newCatName.trim()) return;
                    const catId = newCatName.toLowerCase().replace(/[\s/]/g, '-');
                    onSaveCategory({
                      id: catId,
                      name: newCatName.trim(),
                      description: newCatDesc.trim() || newCatName.trim(),
                      iconName: 'BookMarked',
                      subcategories: [],
                    });
                    setNewCatName('');
                    setNewCatDesc('');
                  }}
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold cursor-pointer shrink-0"
                >
                  + Thêm danh mục
                </button>
              </div>

              {/* List of categories */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {categories.map((c) => (
                  <div key={c.id} className="p-3 bg-stone-50 rounded-xl border border-stone-200 flex items-center justify-between">
                    <div>
                      <h4 className="font-bold text-xs text-stone-900">{c.name}</h4>
                      <p className="text-[11px] text-stone-500 line-clamp-1">{c.description}</p>
                    </div>
                    <button
                      onClick={() => onDeleteCategory(c.id)}
                      className="p-1.5 hover:bg-rose-100 text-rose-600 rounded cursor-pointer"
                      title="Xóa danh mục"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Tab 4: Backup / Export JSON (Section 29) */}
          {activeTab === 'backup' && (
            <div className="space-y-6">
              <div className="p-5 rounded-2xl bg-emerald-50 border border-emerald-200">
                <h3 className="font-bold text-sm text-emerald-950 mb-1">
                  Xuất toàn bộ dữ liệu Thư viện (Export JSON)
                </h3>
                <p className="text-xs text-emerald-800 mb-3">
                  Tạo file sao lưu đầy đủ chứa thông tin thư viện, tất cả sách, danh mục và cấu hình độc giả để phục vụ lưu trữ định kỳ.
                </p>
                <button
                  onClick={exportLibraryToJson}
                  className="px-4 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold flex items-center gap-2 cursor-pointer shadow-xs"
                >
                  <Download className="w-4 h-4" />
                  <span>Tải file JSON sao lưu (.json)</span>
                </button>
              </div>

              <div className="p-5 rounded-2xl bg-stone-50 border border-stone-200">
                <h3 className="font-bold text-sm text-stone-900 mb-1">
                  Phục hồi dữ liệu từ file JSON (Import JSON)
                </h3>
                <p className="text-xs text-stone-600 mb-3">
                  Chọn file JSON đã sao lưu từ máy tính để phục hồi dữ liệu kho sách.
                </p>
                <label className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-white text-xs font-bold cursor-pointer">
                  <Upload className="w-4 h-4" />
                  <span>Chọn file JSON để phục hồi</span>
                  <input type="file" accept=".json" onChange={handleImportJsonFile} className="hidden" />
                </label>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Add / Edit Book Modal (Section 25 & 26) */}
      {isAddBookModalOpen && editingBook && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-stone-950/80 backdrop-blur-xs animate-fade-in">
          <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-stone-200 overflow-hidden my-auto max-h-[90vh] flex flex-col">
            <div className="p-4 bg-stone-900 text-white flex items-center justify-between">
              <h3 className="font-bold text-sm">
                {editingBook.title ? 'Chỉnh sửa tài liệu' : 'Thêm tài liệu mới'}
              </h3>
              <button
                onClick={() => setIsAddBookModalOpen(false)}
                className="w-7 h-7 rounded-full bg-stone-800 text-stone-300 flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveBookSubmit} className="p-6 overflow-y-auto space-y-3 text-xs">
              <div>
                <label className="font-bold text-stone-700 block mb-1">Tên sách / tài liệu: *</label>
                <input
                  type="text"
                  required
                  value={editingBook.title || ''}
                  onChange={(e) => setEditingBook({ ...editingBook, title: e.target.value })}
                  className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-stone-700 block mb-1">Tác giả: *</label>
                  <input
                    type="text"
                    required
                    value={editingBook.author || ''}
                    onChange={(e) => setEditingBook({ ...editingBook, author: e.target.value })}
                    className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-xl"
                  />
                </div>
                <div>
                  <label className="font-bold text-stone-700 block mb-1">Nhà xuất bản:</label>
                  <input
                    type="text"
                    value={editingBook.publisher || ''}
                    onChange={(e) => setEditingBook({ ...editingBook, publisher: e.target.value })}
                    className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-xl"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="font-bold text-stone-700 block mb-1">Năm xuất bản:</label>
                  <input
                    type="number"
                    value={editingBook.year || 2026}
                    onChange={(e) => setEditingBook({ ...editingBook, year: parseInt(e.target.value, 10) })}
                    className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-xl"
                  />
                </div>
                <div>
                  <label className="font-bold text-stone-700 block mb-1">Số trang:</label>
                  <input
                    type="number"
                    value={editingBook.pages || 48}
                    onChange={(e) => setEditingBook({ ...editingBook, pages: parseInt(e.target.value, 10) })}
                    className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-xl"
                  />
                </div>
                <div>
                  <label className="font-bold text-stone-700 block mb-1">Định dạng:</label>
                  <select
                    value={editingBook.format || 'flipbook'}
                    onChange={(e) => setEditingBook({ ...editingBook, format: e.target.value as BookFormat })}
                    className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-xl"
                  >
                    <option value="flipbook">Flipbook 3D</option>
                    <option value="pdf">PDF</option>
                    <option value="comic">Truyện tranh</option>
                    <option value="audio">Audio</option>
                    <option value="video">Video</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="font-bold text-stone-700 block mb-1">URL Ảnh bìa:</label>
                <input
                  type="text"
                  value={editingBook.cover || ''}
                  onChange={(e) => setEditingBook({ ...editingBook, cover: e.target.value })}
                  className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-xl"
                />
              </div>

              <div>
                <label className="font-bold text-stone-700 block mb-1">Tóm tắt mô tả nội dung:</label>
                <textarea
                  rows={3}
                  value={editingBook.description || ''}
                  onChange={(e) => setEditingBook({ ...editingBook, description: e.target.value })}
                  className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-stone-700 block mb-1">Bản quyền:</label>
                  <select
                    value={editingBook.copyright || 'Creative Commons'}
                    onChange={(e) => setEditingBook({ ...editingBook, copyright: e.target.value as CopyrightStatus })}
                    className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-xl"
                  >
                    <option value="Creative Commons">Creative Commons</option>
                    <option value="Public Domain">Public Domain</option>
                    <option value="Được cấp phép">Được cấp phép</option>
                    <option value="Nội bộ">Nội bộ</option>
                    <option value="Chỉ đọc">Chỉ đọc</option>
                    <option value="Cho phép tải">Cho phép tải</option>
                  </select>
                </div>
                <div className="flex items-center gap-2 pt-5">
                  <input
                    type="checkbox"
                    id="allowDown"
                    checked={editingBook.allowDownload || false}
                    onChange={(e) => setEditingBook({ ...editingBook, allowDownload: e.target.checked })}
                    className="w-4 h-4 rounded text-emerald-600"
                  />
                  <label htmlFor="allowDown" className="font-semibold text-stone-700">
                    Cho phép bạn đọc tải file về
                  </label>
                </div>
              </div>

              <div className="pt-4 border-t border-stone-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddBookModalOpen(false)}
                  className="px-4 py-2 bg-stone-200 text-stone-800 rounded-xl font-semibold"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold shadow-xs"
                >
                  Lưu tài liệu
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete confirmation modal */}
      {bookToDelete && (
        <div className="fixed inset-0 z-70 flex items-center justify-center p-4 bg-stone-950/80 backdrop-blur-xs animate-fade-in">
          <div className="bg-white rounded-2xl p-6 max-w-sm w-full text-center space-y-3">
            <AlertCircle className="w-10 h-10 text-rose-600 mx-auto" />
            <h4 className="font-bold text-sm text-stone-900">Xác nhận xóa tài liệu</h4>
            <p className="text-xs text-stone-600">
              Bạn có chắc chắn muốn xóa cuốn sách "{bookToDelete.title}" khỏi thư viện?
            </p>
            <div className="flex gap-2 pt-2">
              <button
                onClick={() => setBookToDelete(null)}
                className="flex-1 py-2 bg-stone-200 rounded-xl text-xs font-semibold"
              >
                Hủy
              </button>
              <button
                onClick={() => {
                  onDeleteBook(bookToDelete.id);
                  setBookToDelete(null);
                }}
                className="flex-1 py-2 bg-rose-600 text-white rounded-xl text-xs font-bold"
              >
                Xóa ngay
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
