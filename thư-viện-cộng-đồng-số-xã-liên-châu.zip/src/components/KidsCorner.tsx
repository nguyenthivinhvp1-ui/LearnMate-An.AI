import React, { useState } from 'react';
import { 
  Sparkles, 
  Gamepad2, 
  BookOpen, 
  Trophy, 
  RotateCcw, 
  Star, 
  CheckCircle2, 
  XCircle,
  HelpCircle,
  Video,
  Headphones
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Book } from '../types/library';

interface KidsCornerProps {
  books: Book[];
  onOpenBook: (book: Book) => void;
}

const QUIZ_QUESTIONS = [
  {
    question: 'Khi đi qua ngã tư có đèn tín hiệu giao thông, màu đèn nào cho phép em được đi?',
    options: ['Đèn đỏ', 'Đèn vàng', 'Đèn xanh', 'Đèn tím'],
    correct: 2,
    explain: 'Chính xác! Đèn xanh báo hiệu được phép di chuyển an toàn.',
  },
  {
    question: 'Vì sao chúng ta nên đội mũ bảo hiểm khi ngồi trên xe máy cùng bố mẹ?',
    options: [
      'Để che nắng cho mát',
      'Để bảo vệ an toàn cho vùng đầu khi tham gia giao thông',
      'Để cho đẹp đội hình',
      'Để chụp ảnh kỷ niệm'
    ],
    correct: 1,
    explain: 'Tuyệt vời! Mũ bảo hiểm đạt chuẩn giúp bảo vệ an toàn tối đa cho vùng đầu.',
  },
  {
    question: 'Trong câu chuyện cổ tích, chàng Mai An Tiêm bị đày ra đảo hoang đã gieo trồng được quả gì?',
    options: ['Quả bưởi', 'Quả dưa hấu', 'Quả chuối', 'Quả sầu riêng'],
    correct: 1,
    explain: 'Đúng rồi! Đó là sự tích Quả Dưa Hấu ruột đỏ ngọt lành.',
  },
  {
    question: 'Cây lúa quê hương Liên Châu cần điều gì nhất để trĩu hạt vàng óng?',
    options: [
      'Nước, đất phù sa màu mỡ, ánh nắng và bàn tay cần cù chăm sóc của người nông dân',
      'Nước ngọt có ga',
      'Bánh kẹo',
      'Mưa đá'
    ],
    correct: 0,
    explain: 'Chính xác! Bàn tay lao động cần cù của bà con nông dân và phù sa bãi bồi làm nên mùa vàng.',
  },
  {
    question: 'Bầu trời ban ngày có màu gì khi trời trong xanh quang đãng?',
    options: ['Màu đen', 'Màu xanh da trời', 'Màu cam đậm', 'Màu tím'],
    correct: 1,
    explain: 'Hoan hô! Ánh sáng mặt trời bị các hạt khí tán xạ màu lam làm bầu trời có màu xanh mát.',
  },
];

export const KidsCorner: React.FC<KidsCornerProps> = ({ books, onOpenBook }) => {
  const [quizActive, setQuizActive] = useState(false);
  const [currentQuestionIdx, setCurrentQuestionIdx] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [isAnswered, setIsAnswered] = useState(false);
  const [quizFinished, setQuizFinished] = useState(false);

  // Filter kids collection
  const kidsBooks = books.filter(
    (b) => b.audiences.includes('tre-em') || b.audiences.includes('hoc-sinh') || b.categories.includes('thieu-nhi')
  );

  const handleSelectOption = (idx: number) => {
    if (isAnswered) return;
    setSelectedOption(idx);
    setIsAnswered(true);

    const isCorrect = idx === QUIZ_QUESTIONS[currentQuestionIdx].correct;
    if (isCorrect) {
      setScore((s) => s + 1);
      try {
        confetti({
          particleCount: 50,
          spread: 60,
          origin: { y: 0.8 },
        });
      } catch (e) {}
    }
  };

  const handleNextQuestion = () => {
    if (currentQuestionIdx < QUIZ_QUESTIONS.length - 1) {
      setCurrentQuestionIdx((q) => q + 1);
      setSelectedOption(null);
      setIsAnswered(false);
    } else {
      setQuizFinished(true);
      try {
        confetti({
          particleCount: 120,
          spread: 80,
          origin: { y: 0.6 },
        });
      } catch (e) {}
    }
  };

  const handleRestartQuiz = () => {
    setCurrentQuestionIdx(0);
    setSelectedOption(null);
    setIsAnswered(false);
    setScore(0);
    setQuizFinished(false);
    setQuizActive(true);
  };

  return (
    <section id="goc-tre-em" className="py-12 bg-gradient-to-b from-amber-50/60 via-orange-50/40 to-stone-50 border-t border-b border-amber-200/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-100 text-amber-800 text-xs font-bold uppercase tracking-wider mb-2">
              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
              <span>Thế Giới Tuổi Thơ • Xã Liên Châu</span>
            </div>
            <h2 className="text-2xl sm:text-4xl font-extrabold text-stone-900 tracking-tight">
              🌈 GÓC TRẺ EM & HỌC SINH
            </h2>
            <p className="text-stone-600 text-sm sm:text-base mt-1">
              Truyện tranh, cổ tích, khoa học vui và đố vui trí tuệ giúp các bé vừa học vừa chơi hào hứng!
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setQuizActive(!quizActive);
                if (!quizActive) handleRestartQuiz();
              }}
              className={`px-4 py-2.5 rounded-2xl font-bold text-xs sm:text-sm flex items-center gap-2 shadow-sm transition-all cursor-pointer ${
                quizActive
                  ? 'bg-amber-500 text-stone-950 ring-2 ring-amber-400'
                  : 'bg-gradient-to-r from-amber-500 to-orange-500 text-white hover:from-amber-600 hover:to-orange-600'
              }`}
            >
              <Gamepad2 className="w-4 h-4" />
              <span>{quizActive ? 'Đóng trò chơi đố vui' : '🎮 Chơi đố vui trí tuệ'}</span>
            </button>
          </div>
        </div>

        {/* Interactive Quiz Mini Game (Section 16) */}
        {quizActive && (
          <div className="mb-10 bg-white rounded-3xl p-6 sm:p-8 border-2 border-amber-300 shadow-xl relative overflow-hidden animate-fade-in">
            <div className="absolute top-0 right-0 -mr-10 -mt-10 w-40 h-40 bg-amber-200/40 rounded-full blur-2xl pointer-events-none" />

            {!quizFinished ? (
              <div className="max-w-2xl mx-auto space-y-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-8 h-8 rounded-full bg-amber-100 text-amber-800 font-extrabold text-sm flex items-center justify-center">
                      {currentQuestionIdx + 1}
                    </span>
                    <span className="text-xs font-bold text-stone-500 uppercase tracking-wider">
                      Câu hỏi {currentQuestionIdx + 1} / {QUIZ_QUESTIONS.length}
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 text-xs font-bold text-amber-700 bg-amber-50 px-3 py-1 rounded-full border border-amber-200">
                    <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
                    <span>Điểm: {score}</span>
                  </div>
                </div>

                <h3 className="text-base sm:text-xl font-bold text-stone-900 leading-snug">
                  {QUIZ_QUESTIONS[currentQuestionIdx].question}
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {QUIZ_QUESTIONS[currentQuestionIdx].options.map((option, optIdx) => {
                    const isSelected = selectedOption === optIdx;
                    const isCorrect = optIdx === QUIZ_QUESTIONS[currentQuestionIdx].correct;

                    let btnStyle = 'bg-stone-50 border-stone-200 hover:border-amber-400 text-stone-800';
                    if (isAnswered) {
                      if (isCorrect) {
                        btnStyle = 'bg-emerald-100 border-emerald-500 text-emerald-950 font-bold';
                      } else if (isSelected && !isCorrect) {
                        btnStyle = 'bg-rose-100 border-rose-400 text-rose-900';
                      } else {
                        btnStyle = 'bg-stone-50 border-stone-200 opacity-50';
                      }
                    }

                    return (
                      <button
                        key={optIdx}
                        onClick={() => handleSelectOption(optIdx)}
                        disabled={isAnswered}
                        className={`p-3.5 rounded-2xl border-2 text-left text-xs sm:text-sm transition-all cursor-pointer flex items-start gap-2.5 ${btnStyle}`}
                      >
                        <span className="w-5 h-5 rounded-full bg-white/80 shrink-0 flex items-center justify-center font-bold text-xs shadow-xs">
                          {String.fromCharCode(65 + optIdx)}
                        </span>
                        <span className="flex-1">{option}</span>
                      </button>
                    );
                  })}
                </div>

                {isAnswered && (
                  <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 flex items-center justify-between gap-4 animate-fade-in">
                    <p className="text-xs sm:text-sm font-medium text-amber-900">
                      {QUIZ_QUESTIONS[currentQuestionIdx].explain}
                    </p>
                    <button
                      onClick={handleNextQuestion}
                      className="shrink-0 px-5 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs sm:text-sm cursor-pointer shadow-sm"
                    >
                      {currentQuestionIdx < QUIZ_QUESTIONS.length - 1 ? 'Câu tiếp theo →' : 'Xem kết quả 🏆'}
                    </button>
                  </div>
                )}
              </div>
            ) : (
              /* Quiz Finish Screen */
              <div className="max-w-md mx-auto text-center space-y-4 py-6">
                <div className="w-20 h-20 rounded-full bg-amber-100 text-amber-600 mx-auto flex items-center justify-center shadow-lg animate-bounce">
                  <Trophy className="w-10 h-10" />
                </div>
                <h3 className="text-2xl font-extrabold text-stone-900">
                  Chúc mừng bé đã hoàn thành!
                </h3>
                <p className="text-sm text-stone-600">
                  Bé đạt <strong>{score} / {QUIZ_QUESTIONS.length}</strong> câu trả lời chính xác. Bé thật thông minh và yêu thích đọc sách!
                </p>
                <div className="pt-2 flex items-center justify-center gap-3">
                  <button
                    onClick={handleRestartQuiz}
                    className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-stone-950 font-bold text-xs sm:text-sm flex items-center gap-2 cursor-pointer"
                  >
                    <RotateCcw className="w-4 h-4" />
                    <span>Chơi lại lần nữa</span>
                  </button>
                  <button
                    onClick={() => setQuizActive(false)}
                    className="px-5 py-2.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-800 font-semibold text-xs sm:text-sm cursor-pointer"
                  >
                    Xem sách thiếu nhi
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Kids Books Showcase */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3 sm:gap-4">
          {kidsBooks.slice(0, 6).map((book) => (
            <div
              key={book.id}
              onClick={() => onOpenBook(book)}
              className="group bg-white rounded-2xl p-2.5 border border-amber-200/80 shadow-xs hover:shadow-xl hover:border-amber-400 transition-all cursor-pointer flex flex-col justify-between"
            >
              <div>
                <div className="relative aspect-3/4 rounded-xl overflow-hidden mb-2 bg-stone-100">
                  <img
                    src={book.cover}
                    alt={book.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-1.5 left-1.5">
                    <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-amber-500 text-stone-950 uppercase">
                      {book.format}
                    </span>
                  </div>
                </div>
                <h4 className="font-bold text-xs sm:text-sm text-stone-900 line-clamp-2 leading-snug group-hover:text-amber-700">
                  {book.title}
                </h4>
              </div>
              <div className="mt-2 pt-2 border-t border-stone-100 flex items-center justify-between text-[11px] text-stone-500">
                <span className="truncate max-w-[90px]">{book.author}</span>
                <span className="text-amber-600 font-bold">Xem →</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
