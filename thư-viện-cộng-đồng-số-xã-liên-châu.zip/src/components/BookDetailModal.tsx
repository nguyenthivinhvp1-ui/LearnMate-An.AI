import React, { useState } from 'react';
import { 
  X, 
  BookOpen, 
  Heart, 
  Share2, 
  QrCode, 
  Headphones, 
  BookMarked, 
  FileText, 
  Sparkles,
  Download, 
  Volume2, 
  Calendar, 
  Building, 
  ShieldCheck, 
  Layers, 
  Users, 
  Eye, 
  CheckCircle2,
  ListOrdered,
  ArrowRight
} from 'lucide-react';
import { Book } from '../types/library';

interface BookDetailModalProps {
  book: Book | null;
  isOpen: boolean;
  onClose: () => void;
  isFavorite: boolean;
  onToggleFavorite: (id: string) => void;
  onReadBook: (book: Book, preferMode?: 'pdf' | 'flipbook') => void;
  onPlayAudio: (book: Book) => void;
  onOpenComic: (book: Book) => void;
  onOpenVideo: (book: Book) => void;
  onShare: (book: Book) => void;
  onGenerateQr: (book: Book) => void;
  allBooks: Book[];
}

export const BookDetailModal: React.FC<BookDetailModalProps> = ({
  book,
  isOpen,
  onClose,
  isFavorite,
  onToggleFavorite,
  onReadBook,
  onPlayAudio,
  onOpenComic,
  onOpenVideo,
  onShare,
  onGenerateQr,
  allBooks,
}) => {
  const [activeTab, setActiveTab] = useState<'intro' | 'toc' | 'related'>('intro');
  const [isSpeakingIntro, setIsSpeakingIntro] = useState(false);

  if (!isOpen || !book) return null;

  // Find related books in same category
  const relatedBooks = allBooks
    .filter((b) => b.id !== book.id && b.categories.some((c) => book.categories.includes(c)))
    .slice(0, 4);

  // Text-to-speech for book description (Section 17 support)
  const handleToggleSpeakIntro = () => {
    if (!('speechSynthesis' in window)) {
      alert('Trình duyệt của bạn chưa hỗ trợ giọng đọc Text-to-Speech.');
      return;
    }

    if (isSpeakingIntro) {
      window.speechSynthesis.cancel();
      setIsSpeakingIntro(false);
      return;
    }

    window.speechSynthesis.cancel();
    const textToRead = `${book.title}. Tác giả: ${book.author}. ${book.description}`;
    const utterance = new SpeechSynthesisUtterance(textToRead);
    utterance.lang = 'vi-VN';
    utterance.rate = 0.95;
    utterance.onend = () => setIsSpeakingIntro(false);
    utterance.onerror = () => setIsSpeakingIntro(false);

    window.speechSynthesis.speak(utterance);
    setIsSpeakingIntro(true);
  };

  const handlePrimaryAction = () => {
    if (book.format === 'comic') {
      onOpenComic(book);
    } else if (book.format === 'video') {
      onOpenVideo(book);
    } else if (book.format === 'audio') {
      onPlayAudio(book);
    } else if (book.format === 'flipbook') {
      onReadBook(book, 'flipbook');
    } else {
      onReadBook(book, 'pdf');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-stone-950/70 backdrop-blur-xs overflow-y-auto animate-fade-in">
      <div 
        className="relative w-full max-w-4xl bg-white rounded-3xl shadow-2xl border border-stone-200 overflow-hidden flex flex-col my-auto max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header bar with close button */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-stone-100 bg-stone-50/80">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-600"></span>
            <span className="text-xs font-bold text-stone-500 uppercase tracking-wider">
              Chi tiết tài liệu • Thư viện số Liên Châu
            </span>
          </div>
          <button
            onClick={() => {
              if (isSpeakingIntro) window.speechSynthesis.cancel();
              onClose();
            }}
            className="w-9 h-9 rounded-full bg-stone-200/80 hover:bg-stone-300 text-stone-700 flex items-center justify-center transition-colors cursor-pointer"
            aria-label="Đóng chi tiết"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {/* Main 2-column layout */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
            {/* Left: Book Cover (Col 1-5) */}
            <div className="md:col-span-4 flex flex-col items-center">
              <div className="relative w-48 sm:w-56 aspect-3/4 rounded-2xl overflow-hidden shadow-xl border-4 border-white bg-stone-100 group">
                <img
                  src={book.cover}
                  alt={book.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-2.5 left-2.5">
                  <span className="px-2.5 py-1 rounded-md text-[10px] font-bold bg-stone-900/85 text-white uppercase tracking-wider backdrop-blur-xs">
                    {book.format.toUpperCase()}
                  </span>
                </div>
              </div>

              {/* Copyright status badge (Section 39) */}
              <div className="mt-4 w-full p-2.5 rounded-xl bg-stone-50 border border-stone-200 text-center">
                <span className="text-[11px] font-semibold text-stone-500 block">Tình trạng bản quyền:</span>
                <span className="inline-flex items-center gap-1 text-xs font-bold text-emerald-800 mt-0.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{book.copyright}</span>
                </span>
                {book.allowDownload ? (
                  <span className="block text-[10px] text-emerald-600 mt-0.5">✓ Cho phép tải về học tập</span>
                ) : (
                  <span className="block text-[10px] text-amber-700 mt-0.5">🔒 Đọc trực tuyến theo giấy phép</span>
                )}
              </div>
            </div>

            {/* Right: Book Details & Actions (Col 6-12) */}
            <div className="md:col-span-8 flex flex-col justify-between space-y-4">
              <div>
                <h2 className="text-xl sm:text-2xl font-extrabold text-stone-900 leading-tight">
                  {book.title}
                </h2>
                <p className="text-emerald-800 font-semibold text-sm sm:text-base mt-1">
                  Tác giả: {book.author}
                </p>
              </div>

              {/* Metadata table (Section 9) */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 text-xs bg-stone-50 p-3.5 rounded-2xl border border-stone-200/80">
                <div>
                  <span className="text-stone-400 block font-medium">Nhà xuất bản:</span>
                  <span className="font-semibold text-stone-800 line-clamp-1">{book.publisher}</span>
                </div>
                <div>
                  <span className="text-stone-400 block font-medium">Năm xuất bản:</span>
                  <span className="font-semibold text-stone-800">{book.year}</span>
                </div>
                <div>
                  <span className="text-stone-400 block font-medium">Số trang:</span>
                  <span className="font-semibold text-stone-800">{book.pages} trang</span>
                </div>
                <div>
                  <span className="text-stone-400 block font-medium">Ngôn ngữ:</span>
                  <span className="font-semibold text-stone-800">{book.language}</span>
                </div>
                <div>
                  <span className="text-stone-400 block font-medium">Lượt đọc:</span>
                  <span className="font-semibold text-stone-800">{book.views.toLocaleString('vi-VN')}</span>
                </div>
                <div>
                  <span className="text-stone-400 block font-medium">Yêu thích:</span>
                  <span className="font-semibold text-rose-600">{book.likes} lượt</span>
                </div>
              </div>

              {/* Description preview with Text to Speech */}
              <div className="relative bg-emerald-50/40 p-3 rounded-xl border border-emerald-100">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-bold text-emerald-900">Tóm tắt nội dung:</span>
                  <button
                    onClick={handleToggleSpeakIntro}
                    className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium cursor-pointer transition-colors ${
                      isSpeakingIntro
                        ? 'bg-rose-600 text-white animate-pulse'
                        : 'bg-white hover:bg-emerald-100 text-emerald-800 border border-emerald-300'
                    }`}
                    title="Đọc to phần giới thiệu cho người khiếm thị / người cao tuổi"
                  >
                    <Volume2 className="w-3.5 h-3.5" />
                    <span>{isSpeakingIntro ? 'Dừng đọc' : 'Đọc thành tiếng'}</span>
                  </button>
                </div>
                <p className="text-xs sm:text-sm text-stone-700 leading-relaxed">
                  {book.description}
                </p>
              </div>

              {/* Prominent Action Button: ĐỌC SÁCH NGAY (Section 9) */}
              <div className="pt-2 space-y-2.5">
                <button
                  onClick={handlePrimaryAction}
                  className="w-full py-3.5 px-6 rounded-2xl bg-emerald-700 hover:bg-emerald-800 active:bg-emerald-900 text-white font-bold text-base shadow-lg shadow-emerald-700/25 transition-all flex items-center justify-center gap-2 cursor-pointer hover:scale-[1.01]"
                >
                  <BookOpen className="w-5 h-5" />
                  <span>
                    {book.format === 'comic' ? 'MỞ TRUYỆN TRANH NGAY' :
                     book.format === 'video' ? 'XEM VIDEO TRI THỨC' :
                     book.format === 'audio' ? 'NGHE SÁCH NÓI NGAY' :
                     'ĐỌC SÁCH NGAY'}
                  </span>
                </button>

                {/* Secondary Actions (Section 9) */}
                <div className="flex flex-wrap items-center gap-2">
                  {/* Flipbook Option */}
                  {book.format !== 'video' && book.format !== 'audio' && (
                    <button
                      onClick={() => onReadBook(book, 'flipbook')}
                      className="flex-1 py-2 px-3 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 text-xs font-bold transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <BookMarked className="w-4 h-4 text-amber-700" />
                      <span>Xem Sách Lật 3D</span>
                    </button>
                  )}

                  {/* Standard PDF Option */}
                  {book.format !== 'video' && book.format !== 'audio' && (
                    <button
                      onClick={() => onReadBook(book, 'pdf')}
                      className="flex-1 py-2 px-3 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <FileText className="w-4 h-4 text-stone-600" />
                      <span>Đọc PDF</span>
                    </button>
                  )}

                  {/* Favorite Toggle */}
                  <button
                    onClick={() => onToggleFavorite(book.id)}
                    className={`py-2 px-3.5 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
                      isFavorite 
                        ? 'bg-rose-50 border-rose-300 text-rose-600 font-bold' 
                        : 'bg-white hover:bg-stone-100 border-stone-300 text-stone-700'
                    }`}
                  >
                    <Heart className={`w-4 h-4 ${isFavorite ? 'fill-rose-500 text-rose-500' : ''}`} />
                    <span>{isFavorite ? 'Đã yêu thích' : 'Yêu thích'}</span>
                  </button>

                  {/* QR Code */}
                  <button
                    onClick={() => onGenerateQr(book)}
                    className="py-2 px-3.5 rounded-xl bg-white hover:bg-stone-100 border border-stone-300 text-stone-700 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                    title="Tạo mã QR in ấn hoặc dán poster"
                  >
                    <QrCode className="w-4 h-4 text-stone-700" />
                    <span>Mã QR</span>
                  </button>

                  {/* Share */}
                  <button
                    onClick={() => onShare(book)}
                    className="py-2 px-3.5 rounded-xl bg-white hover:bg-stone-100 border border-stone-300 text-stone-700 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Share2 className="w-4 h-4 text-stone-700" />
                    <span>Chia sẻ</span>
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Bottom Tabs: Giới thiệu, Mục lục, Tài liệu liên quan (Section 9) */}
          <div className="pt-6 border-t border-stone-200">
            <div className="flex items-center gap-2 border-b border-stone-200 pb-2">
              <button
                onClick={() => setActiveTab('intro')}
                className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-colors cursor-pointer ${
                  activeTab === 'intro'
                    ? 'bg-emerald-800 text-white'
                    : 'text-stone-600 hover:bg-stone-100'
                }`}
              >
                Giới thiệu chi tiết
              </button>
              <button
                onClick={() => setActiveTab('toc')}
                className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-colors cursor-pointer ${
                  activeTab === 'toc'
                    ? 'bg-emerald-800 text-white'
                    : 'text-stone-600 hover:bg-stone-100'
                }`}
              >
                Mục lục ({book.chapters?.length || 4} phần)
              </button>
              <button
                onClick={() => setActiveTab('related')}
                className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-colors cursor-pointer ${
                  activeTab === 'related'
                    ? 'bg-emerald-800 text-white'
                    : 'text-stone-600 hover:bg-stone-100'
                }`}
              >
                Tài liệu cùng chủ đề ({relatedBooks.length})
              </button>
            </div>

            {/* Tab 1: Detailed Intro */}
            {activeTab === 'intro' && (
              <div className="pt-4 space-y-3 text-stone-700 text-xs sm:text-sm leading-relaxed">
                <p>
                  Tài liệu <strong>"{book.title}"</strong> được chọn lọc và số hóa phục vụ phong trào học tập suốt đời, xây dựng nông thôn mới thông minh tại xã Liên Châu.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
                    <span className="font-bold text-stone-900 block mb-1">🎯 Đối tượng phục vụ ưu tiên:</span>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {book.audiences.map((aud) => (
                        <span key={aud} className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 text-[11px] font-medium">
                          {aud}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
                    <span className="font-bold text-stone-900 block mb-1">🏷️ Từ khóa tra cứu:</span>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {book.keywords.map((kw) => (
                        <span key={kw} className="px-2 py-0.5 rounded-md bg-stone-200 text-stone-700 text-[11px]">
                          #{kw}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Tab 2: Table of Contents */}
            {activeTab === 'toc' && (
              <div className="pt-4 space-y-2">
                {book.chapters && book.chapters.length > 0 ? (
                  book.chapters.map((ch, idx) => (
                    <div
                      key={ch.id || idx}
                      onClick={handlePrimaryAction}
                      className="p-3 rounded-xl bg-stone-50 hover:bg-emerald-50 border border-stone-200 hover:border-emerald-300 transition-colors flex items-center justify-between cursor-pointer group"
                    >
                      <div className="flex items-center gap-3">
                        <span className="w-6 h-6 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold flex items-center justify-center group-hover:bg-emerald-700 group-hover:text-white transition-colors">
                          {idx + 1}
                        </span>
                        <span className="text-xs sm:text-sm font-semibold text-stone-800 group-hover:text-emerald-900">
                          {ch.title}
                        </span>
                      </div>
                      <span className="text-xs text-stone-400 font-medium group-hover:text-emerald-700">
                        {ch.pageStart ? `Trang ${ch.pageStart}` : ch.duration ? ch.duration : 'Đọc ngay →'}
                      </span>
                    </div>
                  ))
                ) : (
                  <div className="text-xs text-stone-500 italic p-3">
                    Mục lục đầy đủ gồm {book.pages} trang được hiển thị tự động trong trình đọc PDF và sách lật 3D.
                  </div>
                )}
              </div>
            )}

            {/* Tab 3: Related Books */}
            {activeTab === 'related' && (
              <div className="pt-4 grid grid-cols-2 sm:grid-cols-4 gap-3">
                {relatedBooks.map((rb) => (
                  <div
                    key={rb.id}
                    onClick={() => {
                      // Switch to related book
                      onReadBook(rb);
                    }}
                    className="p-2 bg-stone-50 hover:bg-emerald-50/60 rounded-xl border border-stone-200 hover:border-emerald-300 cursor-pointer transition-all group"
                  >
                    <div className="aspect-3/4 rounded-lg overflow-hidden mb-2 bg-stone-200">
                      <img src={rb.cover} alt={rb.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                    </div>
                    <h4 className="text-xs font-bold text-stone-900 line-clamp-1 group-hover:text-emerald-800">
                      {rb.title}
                    </h4>
                    <p className="text-[11px] text-stone-500 line-clamp-1 mt-0.5">{rb.author}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
