import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  ChevronLeft, 
  ChevronRight, 
  ZoomIn, 
  ZoomOut, 
  Maximize2, 
  Minimize2, 
  Moon, 
  Sun, 
  Bookmark, 
  BookmarkCheck, 
  Download, 
  Printer, 
  Search, 
  Volume2, 
  VolumeX,
  RotateCcw,
  BookOpen,
  SlidersHorizontal,
  ListOrdered
} from 'lucide-react';
import { Book } from '../types/library';
import { updateReadingProgress } from '../services/storageService';

interface PdfReaderModalProps {
  book: Book | null;
  isOpen: boolean;
  onClose: () => void;
  initialPage?: number;
}

export const PdfReaderModal: React.FC<PdfReaderModalProps> = ({
  book,
  isOpen,
  onClose,
  initialPage = 1,
}) => {
  const [currentPage, setCurrentPage] = useState(initialPage);
  const [inputPage, setInputPage] = useState(initialPage.toString());
  const [zoomLevel, setZoomLevel] = useState(100);
  const [themeMode, setThemeMode] = useState<'day' | 'sepia' | 'night'>('day');
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [isBookmarked, setIsBookmarked] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [showToc, setShowToc] = useState(false);
  const [fontScale, setFontScale] = useState<'normal' | 'large' | 'xlarge'>('normal');
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (book) {
      setCurrentPage(initialPage);
      setInputPage(initialPage.toString());
    }
  }, [book, initialPage]);

  // Update progress on page turn
  useEffect(() => {
    if (book && isOpen) {
      updateReadingProgress(book.id, currentPage, book.pages);
      setInputPage(currentPage.toString());
    }
  }, [currentPage, book, isOpen]);

  // Clean up speech synthesis on close
  useEffect(() => {
    return () => {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, [isOpen]);

  if (!isOpen || !book) return null;

  const totalPages = book.pages || 64;
  const progressPercent = Math.min(100, Math.round((currentPage / totalPages) * 100));

  // Determine current page content
  const samplePages = book.contentSample || [];
  const currentTextContent = samplePages[(currentPage - 1) % Math.max(1, samplePages.length)] || 
    `Nội dung tài liệu trang ${currentPage}: Kiến thức khoa học và ứng dụng thực tiễn được thẩm định bởi Trung tâm Học tập Cộng đồng Xã Liên Châu.\n\nMục tiêu: Giúp nhân dân tiếp cận tri thức hữu ích, tự tin đổi mới sáng tạo, phát triển kinh tế gia đình và xây dựng đời sống văn hóa mới văn minh, tiến bộ.`;

  const handlePrevPage = () => {
    if (currentPage > 1) {
      setCurrentPage((p) => p - 1);
    }
  };

  const handleNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage((p) => p + 1);
    }
  };

  const handleJumpPage = (e: React.FormEvent) => {
    e.preventDefault();
    const pageNum = parseInt(inputPage, 10);
    if (!isNaN(pageNum) && pageNum >= 1 && pageNum <= totalPages) {
      setCurrentPage(pageNum);
    } else {
      setInputPage(currentPage.toString());
    }
  };

  const handleToggleFullscreen = () => {
    if (!document.fullscreenElement) {
      containerRef.current?.requestFullscreen?.();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen?.();
      setIsFullscreen(false);
    }
  };

  const handleToggleSpeech = () => {
    if (!('speechSynthesis' in window)) {
      alert('Trình duyệt chưa hỗ trợ đọc Text-to-Speech');
      return;
    }

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(currentTextContent);
    utterance.lang = 'vi-VN';
    utterance.rate = 0.95;
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);
    window.speechSynthesis.speak(utterance);
    setIsSpeaking(true);
  };

  const handleDownload = () => {
    if (!book.allowDownload) {
      alert('Tài liệu này được cấp phép đọc trực tuyến trong thư viện, không cho phép tải về máy cá nhân.');
      return;
    }
    // Simulate downloading PDF file
    const content = `TÀI LIỆU: ${book.title}\nTÁC GIẢ: ${book.author}\nTRUNG TÂM HỌC TẬP CỘNG ĐỒNG XÃ LIÊN CHÂU\n\n${currentTextContent}`;
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${book.title.replace(/[\s/]/g, '_')}_LienChau.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div 
      ref={containerRef}
      className={`fixed inset-0 z-50 flex flex-col ${
        themeMode === 'night' 
          ? 'bg-stone-950 text-stone-100' 
          : themeMode === 'sepia' 
          ? 'bg-[#fbf0d9] text-[#433422]' 
          : 'bg-stone-800 text-stone-900'
      }`}
    >
      {/* Top PDF Reader Toolbar (Section 10) */}
      <div className="bg-stone-900 text-white px-3 sm:px-6 py-2.5 flex items-center justify-between border-b border-stone-800 shrink-0 gap-2">
        {/* Book Title & Page indicator */}
        <div className="flex items-center gap-2 sm:gap-3 min-w-0">
          <button
            onClick={() => setShowToc(!showToc)}
            className={`p-1.5 rounded-lg transition-colors cursor-pointer shrink-0 ${
              showToc ? 'bg-emerald-600 text-white' : 'bg-stone-800 hover:bg-stone-700 text-stone-200'
            }`}
            title="Mục lục & Danh sách các trang tài liệu"
          >
            <ListOrdered className="w-4 h-4" />
          </button>
          <BookOpen className="w-5 h-5 text-emerald-400 shrink-0 hidden sm:block" />
          <div className="min-w-0">
            <h3 className="font-bold text-xs sm:text-sm text-stone-100 truncate max-w-[180px] sm:max-w-xs md:max-w-md">
              {book.title}
            </h3>
            <span className="text-[11px] text-stone-400 hidden xs:inline">
              Trang {currentPage} / {totalPages} ({progressPercent}%)
            </span>
          </div>
        </div>

        {/* Center: Pagination controls */}
        <div className="flex items-center gap-1 sm:gap-2">
          <button
            onClick={handlePrevPage}
            disabled={currentPage <= 1}
            className="p-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 disabled:opacity-30 disabled:cursor-not-allowed text-stone-200 transition-colors cursor-pointer"
            title="Trang trước (Phím mũi tên trái)"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          <form onSubmit={handleJumpPage} className="flex items-center gap-1">
            <input
              type="text"
              value={inputPage}
              onChange={(e) => setInputPage(e.target.value)}
              className="w-10 sm:w-12 text-center py-1 bg-stone-800 text-white text-xs font-semibold rounded-md border border-stone-700 focus:border-emerald-500 outline-hidden"
            />
            <span className="text-xs text-stone-400">/ {totalPages}</span>
          </form>

          <button
            onClick={handleNextPage}
            disabled={currentPage >= totalPages}
            className="p-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 disabled:opacity-30 disabled:cursor-not-allowed text-stone-200 transition-colors cursor-pointer"
            title="Trang sau (Phím mũi tên phải)"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* Right tools: Zoom, Themes, Speech, Fullscreen, Close */}
        <div className="flex items-center gap-1 sm:gap-2">
          {/* Zoom controls */}
          <div className="hidden md:flex items-center gap-1 bg-stone-800 px-2 py-1 rounded-lg">
            <button
              onClick={() => setZoomLevel((z) => Math.max(70, z - 15))}
              className="p-1 text-stone-300 hover:text-white"
              title="Thu nhỏ"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="text-[11px] font-semibold text-stone-300 w-10 text-center">{zoomLevel}%</span>
            <button
              onClick={() => setZoomLevel((z) => Math.min(160, z + 15))}
              className="p-1 text-stone-300 hover:text-white"
              title="Phóng to"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Theme switcher: Day / Sepia / Night */}
          <div className="flex items-center bg-stone-800 p-0.5 rounded-lg">
            <button
              onClick={() => setThemeMode('day')}
              className={`p-1.5 rounded text-xs ${themeMode === 'day' ? 'bg-white text-stone-900' : 'text-stone-300 hover:text-white'}`}
              title="Chế độ Ngày (Sáng)"
            >
              <Sun className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setThemeMode('sepia')}
              className={`p-1.5 rounded text-xs ${themeMode === 'sepia' ? 'bg-[#f4ecd8] text-amber-900 font-bold' : 'text-stone-300 hover:text-white'}`}
              title="Chế độ Dịu mắt (Sepia)"
            >
              <span className="text-xs font-bold leading-none">A</span>
            </button>
            <button
              onClick={() => setThemeMode('night')}
              className={`p-1.5 rounded text-xs ${themeMode === 'night' ? 'bg-stone-700 text-yellow-300' : 'text-stone-300 hover:text-white'}`}
              title="Chế độ Ban đêm (Tối)"
            >
              <Moon className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Text-to-speech button (Section 10 & 17) */}
          <button
            onClick={handleToggleSpeech}
            className={`p-1.5 sm:px-2.5 sm:py-1 rounded-lg text-xs font-medium flex items-center gap-1 cursor-pointer transition-colors ${
              isSpeaking
                ? 'bg-rose-600 text-white animate-pulse'
                : 'bg-stone-800 hover:bg-stone-700 text-stone-200'
            }`}
            title="Đọc trang sách này thành tiếng"
          >
            {isSpeaking ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            <span className="hidden lg:inline">{isSpeaking ? 'Dừng đọc' : 'Đọc trang'}</span>
          </button>

          {/* Bookmark */}
          <button
            onClick={() => setIsBookmarked(!isBookmarked)}
            className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
              isBookmarked ? 'bg-amber-500 text-stone-950 font-bold' : 'bg-stone-800 hover:bg-stone-700 text-stone-300'
            }`}
            title={isBookmarked ? 'Đã đánh dấu trang này' : 'Đánh dấu trang này'}
          >
            {isBookmarked ? <BookmarkCheck className="w-4 h-4" /> : <Bookmark className="w-4 h-4" />}
          </button>

          {/* Download if allowed */}
          {book.allowDownload && (
            <button
              onClick={handleDownload}
              className="p-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-200 cursor-pointer hidden sm:block"
              title="Tải tài liệu về máy"
            >
              <Download className="w-4 h-4" />
            </button>
          )}

          {/* Print */}
          <button
            onClick={handlePrint}
            className="p-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-200 cursor-pointer hidden sm:block"
            title="In tài liệu"
          >
            <Printer className="w-4 h-4" />
          </button>

          {/* Fullscreen */}
          <button
            onClick={handleToggleFullscreen}
            className="p-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-200 cursor-pointer hidden xs:block"
            title="Toàn màn hình"
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>

          {/* Close button */}
          <button
            onClick={() => {
              if (isSpeaking) window.speechSynthesis.cancel();
              onClose();
            }}
            className="p-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white cursor-pointer ml-1"
            title="Đóng trình đọc"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Progress Bar (Section 10) */}
      <div className="w-full bg-stone-700 h-1">
        <div 
          className="bg-emerald-500 h-full transition-all duration-300" 
          style={{ width: `${progressPercent}%` }} 
        />
      </div>

      {/* Main Document Reading Canvas/Paper View */}
      <div className="flex-1 overflow-hidden flex relative">
        {/* Table of Contents Side Drawer */}
        {showToc && (
          <div className="w-64 sm:w-80 bg-stone-900 border-r border-stone-800 flex flex-col z-20 shrink-0 animate-fade-in shadow-2xl">
            <div className="p-3 border-b border-stone-800 flex items-center justify-between text-xs text-stone-300 font-bold">
              <span>MỤC LỤC TÀI LIỆU ({totalPages} TRANG)</span>
              <button 
                onClick={() => setShowToc(false)}
                className="text-stone-400 hover:text-white"
              >
                ✕
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-2 space-y-1 text-xs">
              {samplePages.map((pageText, idx) => {
                const pageNum = idx + 1;
                const isSelected = currentPage === pageNum;
                const firstLine = pageText.split('\n')[0]?.trim() || `Trang ${pageNum}`;
                return (
                  <button
                    key={idx}
                    onClick={() => {
                      setCurrentPage(pageNum);
                      setShowToc(false);
                    }}
                    className={`w-full text-left p-2.5 rounded-xl transition-colors cursor-pointer flex items-start gap-2.5 ${
                      isSelected
                        ? 'bg-emerald-700 text-white font-bold'
                        : 'text-stone-300 hover:bg-stone-800 hover:text-white'
                    }`}
                  >
                    <span className="w-5 h-5 rounded-md bg-stone-800 text-stone-300 text-[10px] flex items-center justify-center shrink-0">
                      {pageNum}
                    </span>
                    <span className="line-clamp-2 leading-snug">{firstLine}</span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Paper reading container */}
        <div className="flex-1 overflow-auto p-4 sm:p-8 flex justify-center items-start">
          <div 
            style={{ transform: `scale(${zoomLevel / 100})`, transformOrigin: 'top center' }}
            className={`w-full max-w-3xl min-h-[85vh] p-8 sm:p-14 rounded-2xl shadow-2xl transition-all duration-200 flex flex-col justify-between ${
              themeMode === 'night' 
                ? 'bg-stone-900 border border-stone-800 text-stone-200' 
                : themeMode === 'sepia' 
                ? 'bg-[#f7ebd1] border border-[#e6d8ba] text-[#3d2f1f]' 
                : 'bg-white border border-stone-200 text-stone-900'
            }`}
          >
            {/* Header of document page */}
            <div className="flex items-center justify-between border-b pb-3 mb-6 text-xs text-stone-400 font-medium">
              <span className="truncate max-w-[280px] sm:max-w-md">{book.title}</span>
              <span className="font-bold text-emerald-700">Trang {currentPage} / {totalPages}</span>
            </div>

            {/* Main text content of page */}
            <div className={`flex-1 font-serif leading-relaxed whitespace-pre-line selection:bg-emerald-200 ${
              fontScale === 'large' ? 'text-lg sm:text-xl' : fontScale === 'xlarge' ? 'text-xl sm:text-2xl' : 'text-base sm:text-lg'
            }`}>
              {currentTextContent}
            </div>

            {/* Footer of document page */}
            <div className="mt-10 pt-4 border-t border-stone-200/50 flex items-center justify-between text-xs text-stone-400">
              <span>Thư viện Cộng đồng số Xã Liên Châu</span>
              <span>Bản quyền: {book.copyright}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom quick page navigation bar */}
      <div className="bg-stone-900/90 text-stone-300 px-4 py-2 border-t border-stone-800 flex items-center justify-between text-xs">
        <div className="flex items-center gap-2">
          <span>Tiến độ đọc: <strong>{progressPercent}%</strong></span>
          <span className="text-stone-500">•</span>
          <span>Trang {currentPage} / {totalPages}</span>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={handlePrevPage}
            disabled={currentPage <= 1}
            className="hover:text-emerald-400 disabled:opacity-40 cursor-pointer"
          >
            ← Trang trước
          </button>
          <span className="text-stone-600">|</span>
          <button 
            onClick={handleNextPage}
            disabled={currentPage >= totalPages}
            className="hover:text-emerald-400 disabled:opacity-40 cursor-pointer"
          >
            Trang tiếp →
          </button>
        </div>
      </div>
    </div>
  );
};
