import React from 'react';
import { AudienceGroup } from '../types/library';
import { Users, Check } from 'lucide-react';

interface AudienceGridProps {
  audiences: AudienceGroup[];
  selectedAudience: string | null;
  onSelectAudience: (id: string | null) => void;
}

export const AudienceGrid: React.FC<AudienceGridProps> = ({
  audiences,
  selectedAudience,
  onSelectAudience,
}) => {
  return (
    <section className="py-8 bg-stone-50/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-6 gap-2">
          <div>
            <div className="flex items-center gap-2 text-emerald-800 text-xs font-bold uppercase tracking-wider">
              <Users className="w-4 h-4" />
              <span>Khối truy cập nhanh theo đối tượng</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-stone-900 mt-1">
              Bạn là ai? Chọn góc tri thức dành riêng cho bạn
            </h2>
          </div>
          {selectedAudience && (
            <button
              onClick={() => onSelectAudience(null)}
              className="text-xs text-stone-600 hover:text-emerald-700 font-semibold underline self-start sm:self-auto cursor-pointer"
            >
              Xem tất cả đối tượng
            </button>
          )}
        </div>

        {/* 9 Large Audience Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-9 gap-2.5 sm:gap-3">
          {audiences.map((aud) => {
            const isSelected = selectedAudience === aud.id;
            return (
              <button
                key={aud.id}
                onClick={() => onSelectAudience(isSelected ? null : aud.id)}
                className={`relative group flex flex-col items-center justify-center p-3 sm:p-3.5 rounded-2xl border transition-all text-center cursor-pointer ${
                  isSelected
                    ? 'bg-emerald-800 text-white border-emerald-900 shadow-md scale-102 ring-2 ring-emerald-600'
                    : 'bg-white hover:bg-emerald-50/40 text-stone-800 border-stone-200 hover:border-emerald-300 shadow-xs'
                }`}
                title={aud.description}
              >
                <span className="text-2xl sm:text-3xl mb-1.5 transition-transform group-hover:scale-110">
                  {aud.icon}
                </span>
                <span className={`text-xs sm:text-sm font-bold leading-tight ${isSelected ? 'text-white' : 'text-stone-800 group-hover:text-emerald-800'}`}>
                  {aud.name}
                </span>

                {isSelected && (
                  <span className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-emerald-500 text-white flex items-center justify-center shadow-xs">
                    <Check className="w-3 h-3 stroke-[3]" />
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
};
