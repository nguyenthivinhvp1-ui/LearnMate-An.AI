import React, { useState, useRef } from 'react';
import { 
  X, 
  ChevronLeft, 
  ChevronRight, 
  Maximize2, 
  Minimize2, 
  Sparkles, 
  Layers, 
  ScrollText, 
  BookOpen,
  ArrowLeft,
  ArrowRight
} from 'lucide-react';
import { Book, ComicChapter } from '../types/library';

interface ComicReaderModalProps {
  book: Book | null;
  isOpen: boolean;
  onClose: () => void;
}

export const ComicReaderModal: React.FC<ComicReaderModalProps> = ({
  book,
  isOpen,
  onClose,
}) => {
  const [currentChapterIndex, setCurrentChapterIndex] = useState(0);
  const [readMode, setReadMode] = useState<'vertical' | 'flip'>('vertical');
  const [currentPageIndex, setCurrentPageIndex] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  if (!isOpen || !book) return null;

  const chapters: ComicChapter[] = book.comicChapters || [
    {
      id: 'default-ch-1',
      chapterNumber: 1,
      title: 'Hành trình khám phá đầu tiên',
      pages: [
        {
          pageNumber: 1,
          imageUrl: 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=1000&q=80',
          caption: 'Trang 1: Buổi sáng trên con đường làng rợp bóng cây xanh mát quê hương Liên Châu.',
        },
        {
          pageNumber: 2,
          imageUrl: 'https://images.unsplash.com/photo-1577896851231-70ef18881754?auto=format&fit=crop&w=1000&q=80',
          caption: 'Trang 2: Các bạn nhỏ cùng học bài học an toàn và sẻ chia yêu thương.',
        },
        {
          pageNumber: 3,
          imageUrl: 'https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&w=1000&q=80',
          caption: 'Trang 3: Niềm vui tới trường, rèn luyện chăm chỉ mỗi ngày thêm tiến bộ.',
        },
      ],
    },
    {
      id: 'default-ch-2',
      chapterNumber: 2,
      title: 'Thử thách trí thông minh',
      pages: [
        {
          pageNumber: 4,
          imageUrl: 'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?auto=format&fit=crop&w=1000&q=80',
          caption: 'Trang 4: Cùng nhau vượt qua câu đố hóc búa của thầy đồ già.',
        },
      ],
    },
  ];

  const currentChapter = chapters[currentChapterIndex] || chapters[0];
  const pages = currentChapter.pages;

  const handleNextPage = () => {
    if (currentPageIndex < pages.length - 1) {
      setCurrentPageIndex((p) => p + 1);
    } else if (currentChapterIndex < chapters.length - 1) {
      setCurrentChapterIndex((c) => c + 1);
      setCurrentPageIndex(0);
    }
  };

  const handlePrevPage = () => {
    if (currentPageIndex > 0) {
      setCurrentPageIndex((p) => p - 1);
    } else if (currentChapterIndex > 0) {
      setCurrentChapterIndex((c) => c - 1);
      const prevPages = chapters[currentChapterIndex - 1].pages;
      setCurrentPageIndex(prevPages.length - 1);
    }
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      containerRef.current?.requestFullscreen?.();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen?.();
      setIsFullscreen(false);
    }
  };

  return (
    <div 
      ref={containerRef}
      className="fixed inset-0 z-50 flex flex-col bg-stone-950 text-stone-100 select-none animate-fade-in"
    >
      {/* Header bar */}
      <div className="bg-stone-900 px-4 sm:px-6 py-2.5 flex items-center justify-between border-b border-stone-800 gap-2 shrink-0">
        <div className="flex items-center gap-2 min-w-0">
          <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-purple-600 text-white uppercase tracking-wider flex items-center gap-1">
            <Sparkles className="w-3 h-3" /> THẾ GIỚI TRUYỆN TRANH
          </span>
          <h3 className="font-bold text-xs sm:text-sm text-stone-200 truncate max-w-[200px] sm:max-w-md">
            {book.title}
          </h3>
        </div>

        {/* Center: Chapter selector */}
        <div className="flex items-center gap-2">
          <select
            value={currentChapterIndex}
            onChange={(e) => {
              setCurrentChapterIndex(parseInt(e.target.value, 10));
              setCurrentPageIndex(0);
            }}
            className="bg-stone-800 text-stone-200 border border-stone-700 text-xs py-1.5 px-3 rounded-lg outline-hidden focus:border-purple-500 cursor-pointer font-medium"
          >
            {chapters.map((ch, idx) => (
              <option key={ch.id} value={idx}>
                Chương {ch.chapterNumber}: {ch.title}
              </option>
            ))}
          </select>

          {/* Reading mode toggle: Cuộn dọc vs Lật trang (Section 12) */}
          <div className="hidden sm:flex items-center bg-stone-800 p-0.5 rounded-lg border border-stone-700">
            <button
              onClick={() => setReadMode('vertical')}
              className={`px-2.5 py-1 text-xs font-semibold rounded flex items-center gap-1 cursor-pointer transition-colors ${
                readMode === 'vertical' ? 'bg-purple-600 text-white' : 'text-stone-300 hover:text-white'
              }`}
              title="Chế độ cuộn dọc như webtoon"
            >
              <ScrollText className="w-3.5 h-3.5" />
              <span>Cuộn dọc</span>
            </button>
            <button
              onClick={() => setReadMode('flip')}
              className={`px-2.5 py-1 text-xs font-semibold rounded flex items-center gap-1 cursor-pointer transition-colors ${
                readMode === 'flip' ? 'bg-purple-600 text-white' : 'text-stone-300 hover:text-white'
              }`}
              title="Chế độ lật từng trang"
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Lật trang</span>
            </button>
          </div>
        </div>

        {/* Right actions */}
        <div className="flex items-center gap-2">
          <button
            onClick={toggleFullscreen}
            className="p-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-200 cursor-pointer hidden xs:block"
            title="Toàn màn hình"
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white cursor-pointer ml-1"
            title="Đóng truyện tranh"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Comic Content Area */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-6 flex justify-center bg-stone-900/60">
        {readMode === 'vertical' ? (
          /* Vertical scroll mode (webtoon style) */
          <div className="w-full max-w-2xl space-y-4">
            <div className="text-center py-2 bg-purple-950/40 rounded-xl border border-purple-800/40 text-purple-300 text-xs font-semibold">
              Chương {currentChapter.chapterNumber}: {currentChapter.title}
            </div>

            {pages.map((p, idx) => (
              <div key={idx} className="bg-stone-900 rounded-2xl overflow-hidden border border-stone-800 shadow-xl">
                <img
                  src={p.imageUrl}
                  alt={`Trang ${p.pageNumber}`}
                  className="w-full h-auto object-cover max-h-[85vh]"
                />
                {p.caption && (
                  <div className="p-3 bg-stone-950 text-xs text-stone-300 font-medium border-t border-stone-800 text-center">
                    {p.caption}
                  </div>
                )}
              </div>
            ))}

            {/* Next Chapter Navigation button */}
            {currentChapterIndex < chapters.length - 1 && (
              <div className="text-center pt-6 pb-12">
                <button
                  onClick={() => {
                    setCurrentChapterIndex((c) => c + 1);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="px-6 py-3 rounded-2xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-sm shadow-lg cursor-pointer inline-flex items-center gap-2"
                >
                  <span>Đọc tiếp Chương {currentChapterIndex + 2}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        ) : (
          /* Page by page flip mode */
          <div className="relative w-full max-w-3xl flex flex-col items-center justify-center">
            <div className="relative max-w-xl w-full bg-stone-900 rounded-2xl overflow-hidden border border-stone-800 shadow-2xl">
              <img
                src={pages[currentPageIndex]?.imageUrl}
                alt={`Trang ${pages[currentPageIndex]?.pageNumber}`}
                className="w-full h-auto max-h-[75vh] object-contain mx-auto"
              />
              <div className="p-3 bg-stone-950 text-xs text-stone-300 font-medium border-t border-stone-800 text-center">
                {pages[currentPageIndex]?.caption || `Trang ${currentPageIndex + 1} / ${pages.length}`}
              </div>
            </div>

            {/* Prev / Next controls */}
            <div className="flex items-center gap-4 mt-4">
              <button
                onClick={handlePrevPage}
                disabled={currentPageIndex === 0 && currentChapterIndex === 0}
                className="px-4 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 disabled:opacity-30 text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>Trang trước</span>
              </button>

              <span className="text-xs text-stone-400 font-medium">
                {currentPageIndex + 1} / {pages.length}
              </span>

              <button
                onClick={handleNextPage}
                className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
              >
                <span>Trang tiếp</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
