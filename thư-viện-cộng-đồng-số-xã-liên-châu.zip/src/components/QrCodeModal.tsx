import React, { useEffect, useState } from 'react';
import { X, QrCode, Download, Printer, BookOpen, ExternalLink, Copy, Check } from 'lucide-react';
import QRCode from 'qrcode';
import { Book } from '../types/library';

interface QrCodeModalProps {
  book: Book | null;
  isOpen: boolean;
  onClose: () => void;
}

export const QrCodeModal: React.FC<QrCodeModalProps> = ({ book, isOpen, onClose }) => {
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (book && isOpen) {
      const bookDirectUrl = `${window.location.origin}?book=${book.id}`;
      QRCode.toDataURL(bookDirectUrl, {
        width: 320,
        margin: 2,
        color: {
          dark: '#064e3b', // Deep emerald
          light: '#ffffff',
        },
      })
        .then((url) => setQrDataUrl(url))
        .catch((err) => console.error('QR generation error:', err));
    }
  }, [book, isOpen]);

  if (!isOpen || !book) return null;

  const bookDirectUrl = `${window.location.origin}?book=${book.id}`;

  const handleDownload = () => {
    if (!qrDataUrl) return;
    const a = document.createElement('a');
    a.href = qrDataUrl;
    a.download = `QR_ThuvienLienChau_${book.id}.png`;
    a.click();
  };

  const handlePrint = () => {
    window.print();
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(bookDirectUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/75 backdrop-blur-xs animate-fade-in">
      <div 
        className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl border border-stone-200 overflow-hidden flex flex-col my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-stone-100 bg-stone-50">
          <div className="flex items-center gap-2">
            <QrCode className="w-5 h-5 text-emerald-700" />
            <span className="text-sm font-bold text-stone-900 uppercase">
              Mã QR Đọc Sách Số
            </span>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-stone-200 hover:bg-stone-300 text-stone-700 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Printable Card Area (Section 21) */}
        <div className="p-6 flex flex-col items-center text-center bg-stone-50/40">
          <div className="w-full p-6 bg-white rounded-2xl border-2 border-emerald-600/30 shadow-md flex flex-col items-center printable-card">
            {/* Branding Header */}
            <div className="flex items-center gap-2 mb-2">
              <div className="w-6 h-6 rounded-md bg-emerald-700 text-white flex items-center justify-center">
                <BookOpen className="w-3.5 h-3.5" />
              </div>
              <span className="text-[11px] font-black tracking-wider text-emerald-800 uppercase">
                THƯ VIỆN SỐ XÃ LIÊN CHÂU
              </span>
            </div>

            <p className="text-[10px] text-stone-500 mb-3">Trung tâm Học tập Cộng đồng Xã Liên Châu</p>

            {/* QR Code Canvas */}
            <div className="w-52 h-52 bg-white p-2 rounded-xl shadow-inner border border-stone-200 flex items-center justify-center mb-3">
              {qrDataUrl ? (
                <img src={qrDataUrl} alt="QR Code" className="w-full h-full object-contain" />
              ) : (
                <div className="text-xs text-stone-400">Đang tạo mã QR...</div>
              )}
            </div>

            {/* Book Info */}
            <h4 className="font-extrabold text-stone-900 text-sm sm:text-base leading-tight line-clamp-2">
              {book.title}
            </h4>
            <p className="text-xs text-stone-500 mt-1">Tác giả: {book.author}</p>
            <span className="inline-block mt-2 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
              Quét mã để đọc trực tuyến trên điện thoại
            </span>
          </div>

          <p className="text-[11px] text-stone-500 mt-4 leading-normal">
            💡 Thẻ QR này dùng để in và dán tại <strong>Nhà văn hóa thôn, Bảng tin xã, Trường học</strong> để bà con dễ dàng quét đọc!
          </p>
        </div>

        {/* Action Buttons: Tải QR, In QR, Sao chép link (Section 21) */}
        <div className="p-4 border-t border-stone-100 bg-stone-50 flex items-center justify-between gap-2">
          <button
            onClick={handleCopyLink}
            className="flex-1 py-2 px-3 rounded-xl bg-white hover:bg-stone-100 border border-stone-300 text-stone-700 text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Đã chép link' : 'Chép link'}</span>
          </button>

          <button
            onClick={handleDownload}
            className="flex-1 py-2 px-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Tải ảnh QR</span>
          </button>

          <button
            onClick={handlePrint}
            className="flex-1 py-2 px-3 rounded-xl bg-stone-900 hover:bg-stone-800 text-white text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>In thẻ QR</span>
          </button>
        </div>
      </div>
    </div>
  );
};
