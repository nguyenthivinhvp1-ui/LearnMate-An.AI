import React from 'react';
import { 
  BookOpen, 
  Heart, 
  Share2, 
  QrCode, 
  Eye, 
  FileText, 
  Headphones, 
  Video, 
  Sparkles,
  BookMarked
} from 'lucide-react';
import { Book, BookFormat } from '../types/library';

interface BookCardProps {
  book: Book;
  isFavorite: boolean;
  onOpenDetail: (book: Book) => void;
  onReadNow: (book: Book) => void;
  onToggleFavorite: (bookId: string) => void;
  onShare: (book: Book) => void;
  onGenerateQr: (book: Book) => void;
}

export const BookCard: React.FC<BookCardProps> = ({
  book,
  isFavorite,
  onOpenDetail,
  onReadNow,
  onToggleFavorite,
  onShare,
  onGenerateQr,
}) => {
  // Format badge rendering
  const renderFormatBadge = (format: BookFormat) => {
    switch (format) {
      case 'flipbook':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-amber-500 text-stone-950 uppercase tracking-wider shadow-xs">
            <BookMarked className="w-3 h-3" /> FLIPBOOK 3D
          </span>
        );
      case 'pdf':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-rose-600 text-white uppercase tracking-wider shadow-xs">
            <FileText className="w-3 h-3" /> PDF
          </span>
        );
      case 'comic':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-purple-600 text-white uppercase tracking-wider shadow-xs">
            <Sparkles className="w-3 h-3" /> TRUYỆN TRANH
          </span>
        );
      case 'audio':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-blue-600 text-white uppercase tracking-wider shadow-xs">
            <Headphones className="w-3 h-3" /> AUDIO
          </span>
        );
      case 'video':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-red-600 text-white uppercase tracking-wider shadow-xs">
            <Video className="w-3 h-3" /> VIDEO
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-emerald-600 text-white uppercase tracking-wider shadow-xs">
            <BookOpen className="w-3 h-3" /> EBOOK
          </span>
        );
    }
  };

  const readActionText = () => {
    if (book.format === 'audio') return 'Nghe ngay';
    if (book.format === 'video') return 'Xem video';
    if (book.format === 'comic') return 'Đọc truyện';
    return 'Đọc ngay';
  };

  return (
    <div className="group relative bg-white rounded-2xl border border-stone-200/90 shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col overflow-hidden hover:-translate-y-1">
      {/* Cover Image Container */}
      <div 
        onClick={() => onOpenDetail(book)}
        className="relative aspect-3/4 sm:aspect-4/5 overflow-hidden bg-stone-100 cursor-pointer"
      >
        <img
          src={book.cover}
          alt={book.title}
          loading="lazy"
          className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
          onError={(e) => {
            // Fallback cover
            (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=600&q=80';
          }}
        />

        {/* Gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-stone-950/80 via-transparent to-transparent opacity-60 group-hover:opacity-40 transition-opacity" />

        {/* Top Badges */}
        <div className="absolute top-2.5 left-2.5 right-2.5 flex items-center justify-between gap-1 z-10">
          {renderFormatBadge(book.format)}
          <span className="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-stone-900/75 text-stone-200 backdrop-blur-xs">
            {book.pages} trang
          </span>
        </div>

        {/* Quick Read Overlay Icon on Hover */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity z-10 pointer-events-none">
          <span className="px-3.5 py-1.5 rounded-full bg-emerald-600/90 text-white text-xs font-bold shadow-lg backdrop-blur-xs flex items-center gap-1.5">
            <BookOpen className="w-3.5 h-3.5" />
            <span>Mở xem chi tiết</span>
          </span>
        </div>

        {/* Bottom stats overlay on image */}
        <div className="absolute bottom-2 left-2.5 right-2.5 flex items-center justify-between text-[11px] text-stone-200 font-medium z-10">
          <div className="flex items-center gap-1 drop-shadow-sm">
            <Eye className="w-3 h-3 text-emerald-400" />
            <span>{book.views.toLocaleString('vi-VN')}</span>
          </div>
          <div className="flex items-center gap-1 drop-shadow-sm">
            <Heart className={`w-3 h-3 ${isFavorite ? 'fill-rose-500 text-rose-500' : 'text-stone-300'}`} />
            <span>{book.likes}</span>
          </div>
        </div>
      </div>

      {/* Book Information */}
      <div className="p-3.5 sm:p-4 flex-1 flex flex-col justify-between">
        <div>
          {/* Categories tag & year */}
          <div className="flex items-center justify-between gap-1 text-[11px] text-stone-500 mb-1">
            <span className="font-semibold text-emerald-700 truncate max-w-[150px]">
              {book.categories[0] || 'Văn hóa'}
            </span>
            <span className="text-stone-400">{book.year}</span>
          </div>

          {/* Title */}
          <h3 
            onClick={() => onOpenDetail(book)}
            className="font-bold text-stone-900 text-sm sm:text-base line-clamp-2 leading-snug group-hover:text-emerald-800 transition-colors cursor-pointer"
            title={book.title}
          >
            {book.title}
          </h3>

          {/* Author */}
          <p className="text-xs text-stone-500 line-clamp-1 mt-1 font-normal">
            {book.author}
          </p>
        </div>

        {/* Buttons section (Section 8) */}
        <div className="pt-3 mt-3 border-t border-stone-100 flex flex-col gap-2">
          {/* Main Action: Đọc ngay */}
          <button
            onClick={() => onReadNow(book)}
            className="w-full py-2 px-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 active:bg-emerald-900 text-white text-xs sm:text-sm font-semibold transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>{readActionText()}</span>
          </button>

          {/* Secondary Action buttons: Yêu thích, Chia sẻ, QR Code */}
          <div className="grid grid-cols-3 gap-1 text-stone-600">
            {/* Heart Favorite button */}
            <button
              onClick={() => onToggleFavorite(book.id)}
              className={`py-1.5 px-2 rounded-lg border text-xs font-medium flex items-center justify-center gap-1 transition-colors cursor-pointer ${
                isFavorite 
                  ? 'bg-rose-50 border-rose-200 text-rose-600 font-bold' 
                  : 'bg-stone-50 border-stone-200/80 hover:bg-stone-100 text-stone-600'
              }`}
              title="Lưu vào sách yêu thích"
            >
              <Heart className={`w-3.5 h-3.5 ${isFavorite ? 'fill-rose-500 text-rose-500' : ''}`} />
              <span className="text-[11px]">{isFavorite ? 'Đã thích' : 'Thích'}</span>
            </button>

            {/* Share button */}
            <button
              onClick={() => onShare(book)}
              className="py-1.5 px-2 rounded-lg border border-stone-200/80 bg-stone-50 hover:bg-stone-100 text-stone-600 text-xs font-medium flex items-center justify-center gap-1 transition-colors cursor-pointer"
              title="Chia sẻ tài liệu"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span className="text-[11px]">Chia sẻ</span>
            </button>

            {/* QR Code button */}
            <button
              onClick={() => onGenerateQr(book)}
              className="py-1.5 px-2 rounded-lg border border-stone-200/80 bg-stone-50 hover:bg-stone-100 text-stone-600 text-xs font-medium flex items-center justify-center gap-1 transition-colors cursor-pointer"
              title="Tạo mã QR in ấn hoặc dán bảng tin"
            >
              <QrCode className="w-3.5 h-3.5 text-stone-700" />
              <span className="text-[11px]">Mã QR</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
