import React, { useState } from 'react';
import { Calendar, MapPin, Users, ArrowRight, X, Sparkles, BookOpen } from 'lucide-react';
import { CommunityActivity } from '../types/library';

interface ActivitiesSectionProps {
  activities: CommunityActivity[];
}

export const ActivitiesSection: React.FC<ActivitiesSectionProps> = ({ activities }) => {
  const [selectedActivity, setSelectedActivity] = useState<CommunityActivity | null>(null);

  return (
    <section id="hoat-dong" className="py-12 bg-white border-t border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold uppercase tracking-wider mb-2">
              <Calendar className="w-3.5 h-3.5 text-emerald-700" />
              <span>Sự kiện & Phong trào</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-stone-900 tracking-tight">
              HOẠT ĐỘNG VĂN HÓA ĐỌC CỘNG ĐỒNG
            </h2>
            <p className="text-stone-600 text-sm sm:text-base mt-1">
              Các phong trào ngày hội sách, tuần lễ học tập suốt đời và trao tặng tủ sách thôn xóm xã Liên Châu.
            </p>
          </div>
        </div>

        {/* 4 Activities Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {activities.map((act) => (
            <div
              key={act.id}
              onClick={() => setSelectedActivity(act)}
              className="group bg-stone-50 hover:bg-white rounded-3xl border border-stone-200 hover:border-emerald-400 overflow-hidden shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col cursor-pointer"
            >
              <div className="relative aspect-16/10 overflow-hidden bg-stone-200">
                <img
                  src={act.image}
                  alt={act.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute top-2.5 left-2.5 px-2.5 py-1 rounded-lg bg-stone-900/80 text-white text-[11px] font-semibold backdrop-blur-xs flex items-center gap-1">
                  <Calendar className="w-3 h-3 text-emerald-400" />
                  <span>{new Date(act.date).toLocaleDateString('vi-VN')}</span>
                </div>
              </div>

              <div className="p-4 flex-1 flex flex-col justify-between">
                <div>
                  <h3 className="font-bold text-sm sm:text-base text-stone-900 group-hover:text-emerald-800 transition-colors line-clamp-2 leading-snug">
                    {act.title}
                  </h3>
                  <p className="text-xs text-stone-500 mt-2 line-clamp-2 leading-relaxed">
                    {act.summary}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-stone-200 flex items-center justify-between text-xs font-semibold text-emerald-700">
                  <span className="flex items-center gap-1 text-[11px] text-stone-500">
                    <MapPin className="w-3.5 h-3.5 text-stone-400" />
                    <span className="truncate max-w-[130px]">{act.location}</span>
                  </span>
                  <span className="flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                    Chi tiết <ArrowRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Activity Details Modal */}
      {selectedActivity && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/75 backdrop-blur-xs animate-fade-in">
          <div 
            className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-stone-200 overflow-hidden flex flex-col my-auto max-h-[90vh]"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="relative aspect-16/9 bg-stone-900">
              <img src={selectedActivity.image} alt={selectedActivity.title} className="w-full h-full object-cover" />
              <button
                onClick={() => setSelectedActivity(null)}
                className="absolute top-4 right-4 w-9 h-9 rounded-full bg-stone-900/80 hover:bg-stone-900 text-white flex items-center justify-center cursor-pointer transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-4">
              <div className="flex items-center gap-2 text-xs text-stone-500">
                <Calendar className="w-3.5 h-3.5 text-emerald-600" />
                <span>Ngày diễn ra: {new Date(selectedActivity.date).toLocaleDateString('vi-VN')}</span>
                <span>•</span>
                <MapPin className="w-3.5 h-3.5 text-rose-500" />
                <span>{selectedActivity.location}</span>
              </div>

              <h3 className="text-xl font-extrabold text-stone-900 leading-snug">
                {selectedActivity.title}
              </h3>

              <div className="p-3 bg-emerald-50 rounded-xl text-xs font-semibold text-emerald-900">
                Đơn vị tổ chức: {selectedActivity.organizer}
              </div>

              <div className="text-xs sm:text-sm text-stone-700 leading-relaxed whitespace-pre-line space-y-2">
                {selectedActivity.content}
              </div>

              <div className="pt-4 border-t border-stone-100 flex justify-end">
                <button
                  onClick={() => setSelectedActivity(null)}
                  className="px-5 py-2.5 rounded-xl bg-stone-900 hover:bg-stone-800 text-white font-semibold text-xs cursor-pointer"
                >
                  Đóng bài viết
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
