import React from 'react';
import { X, Video, ExternalLink, Calendar, Users, ShieldCheck, BookOpen } from 'lucide-react';
import { Book } from '../types/library';

interface VideoModalProps {
  book: Book | null;
  isOpen: boolean;
  onClose: () => void;
}

export const VideoModal: React.FC<VideoModalProps> = ({ book, isOpen, onClose }) => {
  if (!isOpen || !book) return null;

  // Check if YouTube URL or direct MP4
  const videoUrl = book.video || 'https://www.youtube.com/embed/dQw4w9WgXcQ';
  const isYoutube = videoUrl.includes('youtube.com') || videoUrl.includes('youtu.be');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-stone-950/85 backdrop-blur-xs animate-fade-in">
      <div 
        className="relative w-full max-w-4xl bg-stone-900 rounded-3xl shadow-2xl border border-stone-800 overflow-hidden flex flex-col my-auto max-h-[95vh] text-stone-100"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-stone-800 bg-stone-950/80">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-600 animate-pulse"></span>
            <span className="text-xs font-bold text-rose-400 uppercase tracking-wider flex items-center gap-1">
              <Video className="w-4 h-4" /> Video Tri Thức • Thư Viện Liên Châu
            </span>
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-stone-800 hover:bg-stone-700 text-stone-300 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Video Player Area */}
        <div className="relative aspect-16/9 bg-black w-full overflow-hidden">
          {isYoutube ? (
            <iframe
              src={videoUrl}
              title={book.title}
              className="w-full h-full border-0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          ) : (
            <video
              src={videoUrl}
              controls
              className="w-full h-full object-contain"
              poster={book.cover}
            />
          )}
        </div>

        {/* Video Info Body */}
        <div className="p-6 overflow-y-auto space-y-4">
          <div>
            <h2 className="text-lg sm:text-xl font-bold text-white leading-tight">
              {book.title}
            </h2>
            <p className="text-emerald-400 text-xs sm:text-sm mt-1">
              Đơn vị phát hành: {book.publisher} • Tác giả: {book.author} ({book.year})
            </p>
          </div>

          <p className="text-xs sm:text-sm text-stone-300 leading-relaxed bg-stone-800/60 p-4 rounded-2xl border border-stone-700/60">
            {book.description}
          </p>

          {/* Chapters of the video */}
          {book.chapters && book.chapters.length > 0 && (
            <div>
              <h4 className="text-xs font-bold text-stone-400 uppercase tracking-wider mb-2">
                Các phân đoạn video:
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                {book.chapters.map((ch, idx) => (
                  <div key={idx} className="p-2.5 rounded-xl bg-stone-800 border border-stone-700 text-xs">
                    <span className="font-bold text-emerald-400 block">{ch.duration || `Phần ${idx + 1}`}</span>
                    <span className="text-stone-300 text-[11px] line-clamp-1">{ch.title}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
