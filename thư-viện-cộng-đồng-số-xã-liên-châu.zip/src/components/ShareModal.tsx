import React, { useState } from 'react';
import { X, Copy, Check, Share2, Facebook, Mail, QrCode } from 'lucide-react';
import { Book } from '../types/library';

interface ShareModalProps {
  book: Book | null;
  isOpen: boolean;
  onClose: () => void;
  onOpenQr: (book: Book) => void;
}

export const ShareModal: React.FC<ShareModalProps> = ({
  book,
  isOpen,
  onClose,
  onOpenQr,
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen || !book) return null;

  const shareUrl = `${window.location.origin}?book=${book.id}`;
  const shareTitle = `Đọc sách: ${book.title} trên Thư Viện Cộng Đồng Số Xã Liên Châu`;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleFacebookShare = () => {
    window.open(
      `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`,
      '_blank',
      'width=600,height=450'
    );
  };

  const handleEmailShare = () => {
    window.location.href = `mailto:?subject=${encodeURIComponent(
      shareTitle
    )}&body=${encodeURIComponent(
      `Chào bạn, tôi muốn giới thiệu cuốn sách rất hay "${book.title}" trên Thư viện cộng đồng số xã Liên Châu:\n${shareUrl}`
    )}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/75 backdrop-blur-xs animate-fade-in">
      <div 
        className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl border border-stone-200 overflow-hidden flex flex-col my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-stone-100 bg-stone-50">
          <div className="flex items-center gap-2">
            <Share2 className="w-5 h-5 text-emerald-700" />
            <span className="text-sm font-bold text-stone-900 uppercase">
              Chia sẻ tài liệu
            </span>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-stone-200 hover:bg-stone-300 text-stone-700 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4">
          <div className="flex items-center gap-3 p-3 bg-stone-50 rounded-2xl border border-stone-200">
            <img src={book.cover} alt={book.title} className="w-12 h-16 object-cover rounded-lg shrink-0 shadow-xs" />
            <div className="min-w-0">
              <h4 className="font-bold text-sm text-stone-900 truncate">{book.title}</h4>
              <p className="text-xs text-stone-500 truncate">{book.author}</p>
              <span className="text-[11px] text-emerald-700 font-semibold">{book.publisher}</span>
            </div>
          </div>

          {/* Copy Link Input */}
          <div>
            <label className="text-xs font-semibold text-stone-600 block mb-1.5">
              Liên kết trực tiếp tới cuốn sách:
            </label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                readOnly
                value={shareUrl}
                className="flex-1 py-2 px-3 text-xs bg-stone-100 border border-stone-200 rounded-xl text-stone-700 outline-hidden select-all"
              />
              <button
                onClick={handleCopyLink}
                className="px-3.5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold transition-colors flex items-center gap-1 cursor-pointer shrink-0"
              >
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Đã chép' : 'Sao chép'}</span>
              </button>
            </div>
          </div>

          {/* Social buttons */}
          <div className="pt-2">
            <span className="text-xs font-semibold text-stone-600 block mb-2">
              Hoặc chia sẻ qua mạng xã hội:
            </span>
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={handleFacebookShare}
                className="py-2.5 px-3 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <Facebook className="w-4 h-4 fill-blue-700" />
                <span>Facebook</span>
              </button>

              <button
                onClick={handleEmailShare}
                className="py-2.5 px-3 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 border border-stone-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <Mail className="w-4 h-4 text-stone-600" />
                <span>Email</span>
              </button>

              <button
                onClick={() => {
                  onClose();
                  onOpenQr(book);
                }}
                className="py-2.5 px-3 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <QrCode className="w-4 h-4 text-emerald-700" />
                <span>Tạo QR</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
