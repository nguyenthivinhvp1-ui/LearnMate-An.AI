export type BookFormat = 'pdf' | 'flipbook' | 'comic' | 'audio' | 'video' | 'ebook';

export type CopyrightStatus = 
  | 'Public Domain'
  | 'Creative Commons'
  | 'Được cấp phép'
  | 'Nội bộ'
  | 'Chỉ đọc'
  | 'Cho phép tải';

export interface BookChapter {
  id: string;
  title: string;
  pageStart?: number;
  duration?: string; // For audio
  audioUrl?: string; // Specific audio for chapter
  content?: string; // Text content for reader
}

export interface ComicPage {
  pageNumber: number;
  imageUrl: string;
  caption?: string;
}

export interface ComicChapter {
  id: string;
  chapterNumber: number;
  title: string;
  pages: ComicPage[];
}

export interface Book {
  id: string;
  title: string;
  author: string;
  publisher: string;
  year: number;
  categories: string[]; // Category IDs
  audiences: string[];  // Audience IDs
  description: string;
  cover: string;
  format: BookFormat;
  file?: string;        // PDF link or document path
  audio?: string;       // Audio URL or demo audio stream
  video?: string;       // YouTube or MP4 URL
  pages: number;
  keywords: string[];
  views: number;
  likes: number;
  featured?: boolean;
  copyright: CopyrightStatus;
  allowDownload: boolean;
  language: string;
  isbn?: string;
  chapters?: BookChapter[];
  comicChapters?: ComicChapter[];
  contentSample?: string[]; // Sample pages for instant reading in Flipbook/PDF
  addedAt: string;
  isHidden?: boolean;
}

export interface Category {
  id: string;
  name: string;
  description: string;
  iconName: string;
  subcategories: string[];
}

export interface AudienceGroup {
  id: string;
  name: string;
  icon: string;
  color: string;
  description: string;
}

export interface CommunityActivity {
  id: string;
  title: string;
  date: string;
  image: string;
  summary: string;
  content: string;
  location: string;
  organizer: string;
}

export interface ReadingHistoryItem {
  bookId: string;
  lastReadPage: number;
  progressPercent: number;
  lastReadTime: string;
  totalTimeSpentMinutes: number;
}

export interface LibraryUserData {
  favorites: string[]; // book IDs
  readingHistory: ReadingHistoryItem[];
  finishedBooks: string[];
  bookmarks: Array<{ bookId: string; page: number; note: string; createdAt: string }>;
  wantToRead: string[];
  likedBooks: string[];
}
