import React, { useState, useEffect, useMemo } from 'react';
import { 
  BookOpen, 
  Search, 
  Filter, 
  SlidersHorizontal, 
  X, 
  Sparkles, 
  ChevronRight, 
  RotateCcw, 
  HelpCircle, 
  Check, 
  Flame, 
  TrendingUp, 
  Heart, 
  ArrowUp,
  Library,
  BookMarked
} from 'lucide-react';

import { Book, Category, AudienceGroup, LibraryUserData, CommunityActivity } from './types/library';
import { 
  getStoredBooks, 
  saveBooks, 
  getStoredCategories, 
  saveCategories, 
  getStoredAudiences, 
  getStoredUserData, 
  saveUserData, 
  recordBookView, 
  toggleFavoriteBook,
  getSeniorMode,
  setSeniorMode as saveSeniorMode
} from './services/storageService';
import { INITIAL_ACTIVITIES } from './data/initialData';

// Component imports
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { AudienceGrid } from './components/AudienceGrid';
import { BookCard } from './components/BookCard';
import { BookDetailModal } from './components/BookDetailModal';
import { PdfReaderModal } from './components/PdfReaderModal';
import { FlipbookReaderModal } from './components/FlipbookReaderModal';
import { ComicReaderModal } from './components/ComicReaderModal';
import { AudioPlayerBar } from './components/AudioPlayerBar';
import { VideoModal } from './components/VideoModal';
import { KidsCorner } from './components/KidsCorner';
import { SeniorModeBanner } from './components/SeniorModeBanner';
import { MyLibraryModal } from './components/MyLibraryModal';
import { AdminModal } from './components/AdminModal';
import { QrCodeModal } from './components/QrCodeModal';
import { ShareModal } from './components/ShareModal';
import { ActivitiesSection } from './components/ActivitiesSection';
import { LibrarianChatbot } from './components/LibrarianChatbot';
import { Footer } from './components/Footer';

export default function App() {
  // Data state
  const [books, setBooks] = useState<Book[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [audiences, setAudiences] = useState<AudienceGroup[]>([]);
  const [userData, setUserData] = useState<LibraryUserData>({
    favorites: [],
    readingHistory: [],
    finishedBooks: [],
    bookmarks: [],
    wantToRead: [],
    likedBooks: [],
  });

  // Filter & Search states
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedAudience, setSelectedAudience] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedFormat, setSelectedFormat] = useState<string | null>(null);
  const [sortBy, setSortBy] = useState<'newest' | 'popular' | 'likes'>('popular');

  // Senior Mode (Section 17)
  const [isSeniorMode, setIsSeniorMode] = useState<boolean>(false);

  // Modals state
  const [detailBook, setDetailBook] = useState<Book | null>(null);
  const [pdfBook, setPdfBook] = useState<Book | null>(null);
  const [pdfInitialPage, setPdfInitialPage] = useState<number>(1);
  const [flipbookBook, setFlipbookBook] = useState<Book | null>(null);
  const [comicBook, setComicBook] = useState<Book | null>(null);
  const [videoBook, setVideoBook] = useState<Book | null>(null);
  const [activeAudioBook, setActiveAudioBook] = useState<Book | null>(null);
  const [isMyLibraryOpen, setIsMyLibraryOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [qrBook, setQrBook] = useState<Book | null>(null);
  const [shareBook, setShareBook] = useState<Book | null>(null);

  // Toast notification
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Load initial data
  const loadData = () => {
    setBooks(getStoredBooks());
    setCategories(getStoredCategories());
    setAudiences(getStoredAudiences());
    setUserData(getStoredUserData());
    setIsSeniorMode(getSeniorMode());
  };

  useEffect(() => {
    loadData();

    // Check query params for direct book linking (e.g. ?book=book-001)
    const params = new URLSearchParams(window.location.search);
    const bookParam = params.get('book');
    if (bookParam) {
      const allB = getStoredBooks();
      const target = allB.find((b) => b.id === bookParam);
      if (target) {
        setDetailBook(target);
      }
    }
  }, []);

  const handleToggleSeniorMode = () => {
    const nextVal = !isSeniorMode;
    setIsSeniorMode(nextVal);
    saveSeniorMode(nextVal);
    showToast(nextVal ? 'Đã bật Chế độ Dễ đọc cho Người cao tuổi' : 'Đã chuyển về chế độ hiển thị chuẩn');
  };

  const handleToggleFavorite = (bookId: string) => {
    const isNowFav = toggleFavoriteBook(bookId);
    setUserData(getStoredUserData());
    showToast(isNowFav ? 'Đã thêm sách vào mục Yêu thích' : 'Đã xóa sách khỏi mục Yêu thích');
  };

  const handleOpenDetail = (book: Book) => {
    recordBookView(book.id);
    setBooks(getStoredBooks());
    setDetailBook(book);
  };

  const handleReadNow = (book: Book, preferMode?: 'pdf' | 'flipbook') => {
    recordBookView(book.id);
    setBooks(getStoredBooks());

    if (book.format === 'audio') {
      setActiveAudioBook(book);
      showToast(`Đang phát sách nói: ${book.title}`);
    } else if (book.format === 'video') {
      setVideoBook(book);
    } else if (book.format === 'comic') {
      setComicBook(book);
    } else if (preferMode === 'pdf' || book.format === 'pdf') {
      setPdfBook(book);
      setPdfInitialPage(1);
    } else {
      setFlipbookBook(book);
    }
  };

  const handleContinueReading = (book: Book, page = 1) => {
    setDetailBook(null);
    setIsMyLibraryOpen(false);
    if (book.format === 'flipbook') {
      setFlipbookBook(book);
    } else {
      setPdfBook(book);
      setPdfInitialPage(page);
    }
  };

  // Filter & Search computation
  const filteredBooks = useMemo(() => {
    return books.filter((book) => {
      if (book.isHidden) return false;

      // Search match
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchTitle = book.title.toLowerCase().includes(q);
        const matchAuthor = book.author.toLowerCase().includes(q);
        const matchKeywords = book.keywords.some((kw) => kw.toLowerCase().includes(q));
        const matchDesc = book.description.toLowerCase().includes(q);
        const matchPublisher = book.publisher.toLowerCase().includes(q);
        if (!matchTitle && !matchAuthor && !matchKeywords && !matchDesc && !matchPublisher) {
          return false;
        }
      }

      // Audience match
      if (selectedAudience && !book.audiences.includes(selectedAudience)) {
        return false;
      }

      // Category match
      if (selectedCategory && !book.categories.includes(selectedCategory)) {
        return false;
      }

      // Format match
      if (selectedFormat && book.format !== selectedFormat) {
        return false;
      }

      return true;
    }).sort((a, b) => {
      if (sortBy === 'popular') return (b.views || 0) - (a.views || 0);
      if (sortBy === 'likes') return (b.likes || 0) - (a.likes || 0);
      return new Date(b.addedAt).getTime() - new Date(a.addedAt).getTime();
    });
  }, [books, searchQuery, selectedAudience, selectedCategory, selectedFormat, sortBy]);

  const handleClearFilters = () => {
    setSearchQuery('');
    setSelectedAudience(null);
    setSelectedCategory(null);
    setSelectedFormat(null);
    setSortBy('popular');
  };

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Admin Book actions
  const handleSaveBook = (updatedBook: Book) => {
    const current = getStoredBooks();
    const idx = current.findIndex((b) => b.id === updatedBook.id);
    if (idx !== -1) {
      current[idx] = updatedBook;
    } else {
      current.unshift(updatedBook);
    }
    saveBooks(current);
    loadData();
    showToast('Đã lưu tài liệu thành công!');
  };

  const handleDeleteBook = (bookId: string) => {
    const current = getStoredBooks().filter((b) => b.id !== bookId);
    saveBooks(current);
    loadData();
    showToast('Đã xóa tài liệu khỏi thư viện');
  };

  const handleToggleHideBook = (bookId: string) => {
    const current = getStoredBooks().map((b) => {
      if (b.id === bookId) return { ...b, isHidden: !b.isHidden };
      return b;
    });
    saveBooks(current);
    loadData();
  };

  const handleSaveCategory = (cat: Category) => {
    const current = getStoredCategories();
    current.push(cat);
    saveCategories(current);
    loadData();
    showToast(`Đã thêm danh mục: ${cat.name}`);
  };

  const handleDeleteCategory = (catId: string) => {
    const current = getStoredCategories().filter((c) => c.id !== catId);
    saveCategories(current);
    loadData();
    showToast('Đã xóa danh mục');
  };

  const isFiltering = !!(searchQuery || selectedAudience || selectedCategory || selectedFormat);

  return (
    <div className={`min-h-screen flex flex-col font-sans transition-all ${
      isSeniorMode ? 'text-lg contrast-125 bg-amber-50/30' : 'bg-stone-50 text-stone-800'
    }`}>
      {/* Toast Notification (Section 42) */}
      {toastMessage && (
        <div className="fixed bottom-20 right-6 z-60 bg-stone-900 text-white px-5 py-3 rounded-2xl shadow-2xl border border-stone-700 flex items-center gap-2.5 text-xs sm:text-sm font-semibold animate-slide-up">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Senior Mode Banner (Section 17) */}
      <SeniorModeBanner isEnabled={isSeniorMode} onToggle={handleToggleSeniorMode} />

      {/* Header (Section 3 & 4) */}
      <Header
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        isSeniorMode={isSeniorMode}
        onToggleSeniorMode={handleToggleSeniorMode}
        onOpenMyLibrary={() => setIsMyLibraryOpen(true)}
        onOpenAdmin={() => setIsAdminOpen(true)}
        onOpenChat={() => setIsChatOpen(true)}
        onSelectCategory={setSelectedCategory}
        onSelectAudience={setSelectedAudience}
        onScrollToSection={scrollToSection}
        userData={userData}
        activeFilterFormat={selectedFormat}
        onSelectFormat={setSelectedFormat}
      />

      {/* Hero Banner (Section 5) */}
      <Hero
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onExploreClick={() => scrollToSection('kho-sach')}
        onReadNowClick={() => {
          if (books[0]) handleReadNow(books[0]);
        }}
        onCategoriesClick={() => scrollToSection('danh-muc-sach')}
        onGuideClick={() => scrollToSection('huong-dan')}
        books={books}
      />

      {/* Fast Audience Access Blocks (Section 6 & 28) */}
      <AudienceGrid
        audiences={audiences}
        selectedAudience={selectedAudience}
        onSelectAudience={(id) => {
          setSelectedAudience(id);
          scrollToSection('kho-sach');
        }}
      />

      {/* Main Books Catalog Section (Section 7 & 8 & 18) */}
      <main id="kho-sach" className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 w-full space-y-8">
        {/* Category Pill Navigation (Section 7) */}
        <div id="danh-muc-sach" className="space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-xl sm:text-3xl font-extrabold text-stone-900 tracking-tight flex items-center gap-2">
                <BookMarked className="w-6 h-6 text-emerald-700" />
                <span>KHO SÁCH & TÀI LIỆU ĐIỆN TỬ</span>
              </h2>
              <p className="text-xs sm:text-sm text-stone-500 mt-0.5">
                Hiển thị {filteredBooks.length} tài liệu phù hợp trong kho lưu trữ số Liên Châu
              </p>
            </div>

            {/* Sort & Filter controls */}
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs text-stone-500 font-semibold flex items-center gap-1">
                <Filter className="w-3.5 h-3.5" /> Sắp xếp:
              </span>
              <button
                onClick={() => setSortBy('popular')}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold cursor-pointer transition-colors ${
                  sortBy === 'popular'
                    ? 'bg-emerald-700 text-white shadow-xs'
                    : 'bg-stone-100 hover:bg-stone-200 text-stone-700'
                }`}
              >
                🔥 Đọc nhiều nhất
              </button>
              <button
                onClick={() => setSortBy('newest')}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold cursor-pointer transition-colors ${
                  sortBy === 'newest'
                    ? 'bg-emerald-700 text-white shadow-xs'
                    : 'bg-stone-100 hover:bg-stone-200 text-stone-700'
                }`}
              >
                ✨ Sách mới
              </button>
              <button
                onClick={() => setSortBy('likes')}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold cursor-pointer transition-colors ${
                  sortBy === 'likes'
                    ? 'bg-emerald-700 text-white shadow-xs'
                    : 'bg-stone-100 hover:bg-stone-200 text-stone-700'
                }`}
              >
                ❤️ Yêu thích nhiều
              </button>

              {isFiltering && (
                <button
                  onClick={handleClearFilters}
                  className="px-3 py-1.5 rounded-xl bg-rose-50 text-rose-700 border border-rose-200 text-xs font-bold hover:bg-rose-100 transition-colors cursor-pointer flex items-center gap-1"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>XÓA BỘ LỌC</span>
                </button>
              )}
            </div>
          </div>

          {/* Categories Horizontal Tabs (Section 7) */}
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-2 text-xs">
            <button
              onClick={() => setSelectedCategory(null)}
              className={`px-3.5 py-2 rounded-xl font-bold transition-all cursor-pointer whitespace-nowrap shadow-2xs ${
                selectedCategory === null
                  ? 'bg-stone-900 text-white'
                  : 'bg-white hover:bg-stone-100 text-stone-700 border border-stone-200'
              }`}
            >
              Tất cả danh mục ({books.length})
            </button>
            {categories.map((cat) => {
              const isSelected = selectedCategory === cat.id;
              const countInCat = books.filter((b) => b.categories.includes(cat.id)).length;
              return (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(isSelected ? null : cat.id)}
                  className={`px-3.5 py-2 rounded-xl font-medium transition-all cursor-pointer whitespace-nowrap shadow-2xs flex items-center gap-1.5 ${
                    isSelected
                      ? 'bg-emerald-700 text-white font-bold'
                      : 'bg-white hover:bg-emerald-50/80 text-stone-700 border border-stone-200 hover:border-emerald-300'
                  }`}
                  title={cat.description}
                >
                  <span>{cat.name}</span>
                  <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                    isSelected ? 'bg-emerald-900 text-emerald-200' : 'bg-stone-100 text-stone-500'
                  }`}>
                    {countInCat}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Active Filters Summary Bar */}
        {isFiltering && (
          <div className="p-3 bg-emerald-50/70 border border-emerald-200 rounded-2xl flex flex-wrap items-center justify-between gap-2 text-xs text-emerald-900">
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-bold">Đang lọc theo:</span>
              {searchQuery && (
                <span className="px-2 py-0.5 bg-white rounded-lg border border-emerald-300 font-medium">
                  Từ khóa: "{searchQuery}"
                </span>
              )}
              {selectedAudience && (
                <span className="px-2 py-0.5 bg-white rounded-lg border border-emerald-300 font-medium">
                  Đối tượng: {audiences.find((a) => a.id === selectedAudience)?.name}
                </span>
              )}
              {selectedCategory && (
                <span className="px-2 py-0.5 bg-white rounded-lg border border-emerald-300 font-medium">
                  Danh mục: {categories.find((c) => c.id === selectedCategory)?.name}
                </span>
              )}
              {selectedFormat && (
                <span className="px-2 py-0.5 bg-white rounded-lg border border-emerald-300 font-medium uppercase">
                  Định dạng: {selectedFormat}
                </span>
              )}
            </div>
            <button
              onClick={handleClearFilters}
              className="text-xs font-bold text-rose-600 hover:underline cursor-pointer"
            >
              Xóa tất cả bộ lọc ×
            </button>
          </div>
        )}

        {/* Book Cards Grid (Section 8) */}
        {filteredBooks.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 sm:gap-6">
            {filteredBooks.map((book) => (
              <BookCard
                key={book.id}
                book={book}
                isFavorite={userData.favorites.includes(book.id)}
                onOpenDetail={handleOpenDetail}
                onReadNow={handleReadNow}
                onToggleFavorite={handleToggleFavorite}
                onShare={setShareBook}
                onGenerateQr={setQrBook}
              />
            ))}
          </div>
        ) : (
          /* Empty State (Section 42) */
          <div className="text-center py-16 px-4 bg-white rounded-3xl border border-stone-200/80 shadow-xs max-w-xl mx-auto space-y-4">
            <div className="w-16 h-16 rounded-full bg-stone-100 text-stone-400 mx-auto flex items-center justify-center">
              <Search className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-bold text-stone-900">
              Chưa tìm thấy tài liệu phù hợp
            </h3>
            <p className="text-xs sm:text-sm text-stone-500 max-w-md mx-auto">
              Hãy thử tìm với từ khóa khác hoặc xóa bộ lọc để khám phá toàn bộ hơn 2.500+ đầu sách trong thư viện số xã Liên Châu.
            </p>
            <button
              onClick={handleClearFilters}
              className="px-5 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs cursor-pointer shadow-xs"
            >
              Xem tất cả tài liệu
            </button>
          </div>
        )}
      </main>

      {/* Kids Corner Section (Section 16) */}
      <KidsCorner books={books} onOpenBook={handleOpenDetail} />

      {/* Lifelong Learning Portal (Section 15) */}
      <section id="hoc-tap-suot-doi" className="py-12 bg-white border-b border-stone-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 gap-4">
            <div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-teal-100 text-teal-800 text-xs font-bold uppercase tracking-wider mb-2">
                <Sparkles className="w-3.5 h-3.5 text-teal-700" />
                <span>Trung tâm Học tập Cộng đồng Xã Liên Châu</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-stone-900 tracking-tight">
                🌱 GÓC HỌC TẬP SUỐT ĐỜI
              </h2>
              <p className="text-stone-600 text-sm sm:text-base mt-1">
                "Học ở trường, học ở sách báo, học lẫn nhau và học suốt đời" — Tri thức nâng tầm cuộc sống nông thôn mới.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div 
              onClick={() => {
                setSearchQuery('vneid');
                scrollToSection('kho-sach');
              }}
              className="p-5 rounded-2xl bg-gradient-to-br from-indigo-50 to-blue-50 border border-indigo-200/80 hover:border-indigo-400 transition-all cursor-pointer group shadow-xs"
            >
              <span className="text-3xl mb-2 block">💻</span>
              <h4 className="font-bold text-stone-900 text-base group-hover:text-indigo-800 transition-colors">
                Kỹ năng số & VNeID
              </h4>
              <p className="text-xs text-stone-600 mt-1 leading-relaxed">
                Hướng dẫn nộp hồ sơ trực tuyến, thanh toán hóa đơn điện thoại, bảo vệ tài khoản ngân hàng.
              </p>
              <span className="text-xs font-bold text-indigo-700 mt-3 inline-block group-hover:translate-x-1 transition-transform">
                Xem tài liệu →
              </span>
            </div>

            <div 
              onClick={() => {
                setSearchQuery('trồng trọt');
                scrollToSection('kho-sach');
              }}
              className="p-5 rounded-2xl bg-gradient-to-br from-lime-50 to-emerald-50 border border-lime-200/80 hover:border-lime-400 transition-all cursor-pointer group shadow-xs"
            >
              <span className="text-3xl mb-2 block">🌾</span>
              <h4 className="font-bold text-stone-900 text-base group-hover:text-emerald-800 transition-colors">
                Kỹ thuật Nông nghiệp Xanh
              </h4>
              <p className="text-xs text-stone-600 mt-1 leading-relaxed">
                Ủ phân hữu cơ, canh tác sinh học VietGAP, xây dựng chuỗi giá trị nông sản OCOP Liên Châu.
              </p>
              <span className="text-xs font-bold text-emerald-700 mt-3 inline-block group-hover:translate-x-1 transition-transform">
                Xem tài liệu →
              </span>
            </div>

            <div 
              onClick={() => {
                setSearchQuery('huyết áp');
                scrollToSection('kho-sach');
              }}
              className="p-5 rounded-2xl bg-gradient-to-br from-rose-50 to-amber-50 border border-rose-200/80 hover:border-rose-400 transition-all cursor-pointer group shadow-xs"
            >
              <span className="text-3xl mb-2 block">❤️</span>
              <h4 className="font-bold text-stone-900 text-base group-hover:text-rose-800 transition-colors">
                Sức khỏe & Dưỡng sinh
              </h4>
              <p className="text-xs text-stone-600 mt-1 leading-relaxed">
                Sổ tay ổn định huyết áp, dinh dưỡng 1000 ngày đầu đời cho trẻ, bài tập kinh lạc buổi sáng.
              </p>
              <span className="text-xs font-bold text-rose-700 mt-3 inline-block group-hover:translate-x-1 transition-transform">
                Xem tài liệu →
              </span>
            </div>

            <div 
              onClick={() => {
                setSearchQuery('lừa đảo');
                scrollToSection('kho-sach');
              }}
              className="p-5 rounded-2xl bg-gradient-to-br from-amber-50 to-stone-100 border border-amber-200/80 hover:border-amber-400 transition-all cursor-pointer group shadow-xs"
            >
              <span className="text-3xl mb-2 block">🛡️</span>
              <h4 className="font-bold text-stone-900 text-base group-hover:text-amber-800 transition-colors">
                Pháp luật & An toàn mạng
              </h4>
              <p className="text-xs text-stone-600 mt-1 leading-relaxed">
                Luật Đất đai mới, phòng chống cuộc gọi lừa đảo, an toàn giao thông và phòng cháy chữa cháy.
              </p>
              <span className="text-xs font-bold text-amber-800 mt-3 inline-block group-hover:translate-x-1 transition-transform">
                Xem tài liệu →
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Community Activities Section (Section 23) */}
      <ActivitiesSection activities={INITIAL_ACTIVITIES} />

      {/* Interactive Usage Guide (Section 5 & 46) */}
      <section id="huong-dan" className="py-12 bg-stone-100 border-t border-stone-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-8">
            <h2 className="text-2xl sm:text-3xl font-extrabold text-stone-900 tracking-tight">
              HƯỚNG DẪN SỬ DỤNG THƯ VIỆN SỐ
            </h2>
            <p className="text-xs sm:text-sm text-stone-600 mt-1">
              Các bước đơn giản để bất kỳ ai cũng có thể đọc sách, nghe sách nói và lan tỏa tri thức
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="p-5 bg-white rounded-2xl border border-stone-200 shadow-xs flex flex-col items-center text-center">
              <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-800 font-extrabold text-lg flex items-center justify-center mb-3">
                1
              </div>
              <h4 className="font-bold text-stone-900 text-sm mb-1">Tìm kiếm & Chọn sách</h4>
              <p className="text-xs text-stone-500 leading-relaxed">
                Nhập tên sách, chủ đề hoặc bấm chọn một trong 9 nhóm đối tượng để hệ thống lọc ngay sách phù hợp.
              </p>
            </div>

            <div className="p-5 bg-white rounded-2xl border border-stone-200 shadow-xs flex flex-col items-center text-center">
              <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-800 font-extrabold text-lg flex items-center justify-center mb-3">
                2
              </div>
              <h4 className="font-bold text-stone-900 text-sm mb-1">Đọc trực tiếp trên web</h4>
              <p className="text-xs text-stone-500 leading-relaxed">
                Chọn chế độ đọc PDF hoặc lật sách 3D sống động với âm thanh lật trang tự nhiên, không cần tải về máy.
              </p>
            </div>

            <div className="p-5 bg-white rounded-2xl border border-stone-200 shadow-xs flex flex-col items-center text-center">
              <div className="w-12 h-12 rounded-2xl bg-blue-100 text-blue-800 font-extrabold text-lg flex items-center justify-center mb-3">
                3
              </div>
              <h4 className="font-bold text-stone-900 text-sm mb-1">Nghe sách & Chế độ Dễ đọc</h4>
              <p className="text-xs text-stone-500 leading-relaxed">
                Người cao tuổi bật "Chế độ Dễ đọc" để chữ to hơn và bấm nút "Đọc thành tiếng" để nghe bài học thuận tiện.
              </p>
            </div>

            <div className="p-5 bg-white rounded-2xl border border-stone-200 shadow-xs flex flex-col items-center text-center">
              <div className="w-12 h-12 rounded-2xl bg-purple-100 text-purple-800 font-extrabold text-lg flex items-center justify-center mb-3">
                4
              </div>
              <h4 className="font-bold text-stone-900 text-sm mb-1">Tạo QR Code & Chia sẻ</h4>
              <p className="text-xs text-stone-500 leading-relaxed">
                Bấm "Tạo QR" để in thẻ mã vạch dán tại Nhà văn hóa thôn, trường học cho bạn bè, người thân cùng quét đọc.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Institutional Footer (Section 40) */}
      <Footer 
        onScrollToSection={scrollToSection} 
        onOpenAdmin={() => setIsAdminOpen(true)} 
      />

      {/* Floating Audio Player Bar (Section 13) */}
      <AudioPlayerBar
        book={activeAudioBook}
        isOpen={!!activeAudioBook}
        onClose={() => setActiveAudioBook(null)}
        onOpenDetail={handleOpenDetail}
      />

      {/* Modals */}
      <BookDetailModal
        book={detailBook}
        isOpen={!!detailBook}
        onClose={() => setDetailBook(null)}
        isFavorite={detailBook ? userData.favorites.includes(detailBook.id) : false}
        onToggleFavorite={handleToggleFavorite}
        onReadBook={handleReadNow}
        onPlayAudio={(b) => {
          setDetailBook(null);
          setActiveAudioBook(b);
          showToast(`Đang phát sách nói: ${b.title}`);
        }}
        onOpenComic={(b) => {
          setDetailBook(null);
          setComicBook(b);
        }}
        onOpenVideo={(b) => {
          setDetailBook(null);
          setVideoBook(b);
        }}
        onShare={(b) => setShareBook(b)}
        onGenerateQr={(b) => setQrBook(b)}
        allBooks={books}
      />

      <PdfReaderModal
        book={pdfBook}
        isOpen={!!pdfBook}
        onClose={() => setPdfBook(null)}
        initialPage={pdfInitialPage}
      />

      <FlipbookReaderModal
        book={flipbookBook}
        isOpen={!!flipbookBook}
        onClose={() => setFlipbookBook(null)}
        onSwitchToPdf={() => {
          const b = flipbookBook;
          setFlipbookBook(null);
          if (b) setPdfBook(b);
        }}
        onShare={(b) => setShareBook(b)}
      />

      <ComicReaderModal
        book={comicBook}
        isOpen={!!comicBook}
        onClose={() => setComicBook(null)}
      />

      <VideoModal
        book={videoBook}
        isOpen={!!videoBook}
        onClose={() => setVideoBook(null)}
      />

      <MyLibraryModal
        isOpen={isMyLibraryOpen}
        onClose={() => setIsMyLibraryOpen(false)}
        userData={userData}
        allBooks={books}
        onReadBook={handleContinueReading}
        onRemoveFavorite={handleToggleFavorite}
        onClearHistory={() => {
          const current = getStoredUserData();
          current.readingHistory = [];
          saveUserData(current);
          setUserData(current);
          showToast('Đã xóa sạch nhật ký đọc');
        }}
      />

      <AdminModal
        isOpen={isAdminOpen}
        onClose={() => setIsAdminOpen(false)}
        books={books}
        categories={categories}
        audiences={audiences}
        onSaveBook={handleSaveBook}
        onDeleteBook={handleDeleteBook}
        onToggleHideBook={handleToggleHideBook}
        onSaveCategory={handleSaveCategory}
        onDeleteCategory={handleDeleteCategory}
        onReloadData={loadData}
      />

      <QrCodeModal
        book={qrBook}
        isOpen={!!qrBook}
        onClose={() => setQrBook(null)}
      />

      <ShareModal
        book={shareBook}
        isOpen={!!shareBook}
        onClose={() => setShareBook(null)}
        onOpenQr={(b) => setQrBook(b)}
      />

      <LibrarianChatbot
        isOpen={isChatOpen}
        onClose={() => setIsChatOpen(false)}
        books={books}
        onOpenBook={(b) => {
          setIsChatOpen(false);
          handleOpenDetail(b);
        }}
      />
    </div>
  );
}
